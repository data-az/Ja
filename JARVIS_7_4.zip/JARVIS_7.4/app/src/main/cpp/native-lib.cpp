// native-lib: проверка подписи APK и расшифровка ассетов (голоса, index.json).
// Всё, что касается ключа, живёт здесь. Python-скрипт encrypt_assets.py читает BASE_KEY отсюда же.

#include <cstdint>
#include <cstddef>
#include <cstring>
#include <vector>

// ============================================================================
// Константы
// ============================================================================

// Базовый 32-байтный ключ ассетов. Менять только вместе с перешифровкой (сборка делает это сама).
static const uint8_t BASE_KEY[32] = {
    0xfb, 0xe0, 0x36, 0x3b, 0x10, 0x93, 0x80, 0x79, 0xba, 0x6f, 0x51, 0xb2, 0xf1, 0x68, 0xef, 0xc6, 0x70, 0x13, 0xff, 0xcd, 0x11, 0xdb, 0xf9, 0xe5, 0x7c, 0xf3, 0xd2, 0x53, 0x14, 0xca, 0x66, 0xc7
};

// SHA-256 сертификата подписи release-ключа (64 hex-символа, строчными, без двоеточий).
// >>> ВСТАВЬТЕ СЮДА ХЕШ из workflow generate_key.yml (шаг SHA256 в secrets.txt) <<<
// Пока стоит заглушка из нулей: приложение соберётся, но звук будет мусором, пока хеш не вставлен.
static const char EXPECTED_SHA256[] =
    "0000000000000000000000000000000000000000000000000000000000000000";

// Ключ, который реально используется для расшифровки. Заполняется в initSecurity().
// Пока не инициализирован, нули: расшифровка даёт мусор, без явных ошибок.
static uint8_t g_key[32] = {0};

// ============================================================================
// SHA-256 (автономная реализация, FIPS 180-4)
// ============================================================================

namespace sha {

static const uint32_t K[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2};

static inline uint32_t rotr(uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }

static void block(uint32_t h[8], const uint8_t* p) {
    uint32_t w[64];
    for (int i = 0; i < 16; i++) {
        w[i] = (uint32_t)p[4 * i] << 24 | (uint32_t)p[4 * i + 1] << 16 |
               (uint32_t)p[4 * i + 2] << 8 | (uint32_t)p[4 * i + 3];
    }
    for (int i = 16; i < 64; i++) {
        uint32_t s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ (w[i - 15] >> 3);
        uint32_t s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ (w[i - 2] >> 10);
        w[i] = w[i - 16] + s0 + w[i - 7] + s1;
    }
    uint32_t a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
    for (int i = 0; i < 64; i++) {
        uint32_t S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        uint32_t ch = (e & f) ^ (~e & g);
        uint32_t t1 = hh + S1 + ch + K[i] + w[i];
        uint32_t S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
        uint32_t t2 = S0 + maj;
        hh = g; g = f; f = e; e = d + t1;
        d = c; c = b; b = a; a = t1 + t2;
    }
    h[0] += a; h[1] += b; h[2] += c; h[3] += d;
    h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
}

static void digest(const uint8_t* data, size_t len, uint8_t out[32]) {
    uint32_t h[8] = {0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
                     0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19};
    size_t full = len / 64 * 64;
    for (size_t i = 0; i < full; i += 64) block(h, data + i);

    uint8_t tail[128] = {0};
    size_t rem = len - full;
    memcpy(tail, data + full, rem);
    tail[rem] = 0x80;
    size_t tlen = (rem + 1 + 8 <= 64) ? 64 : 128;
    uint64_t bits = (uint64_t)len * 8;
    for (int i = 0; i < 8; i++) tail[tlen - 1 - i] = (uint8_t)(bits >> (8 * i));
    for (size_t i = 0; i < tlen; i += 64) block(h, tail + i);

    for (int i = 0; i < 8; i++) {
        out[4 * i] = (uint8_t)(h[i] >> 24);
        out[4 * i + 1] = (uint8_t)(h[i] >> 16);
        out[4 * i + 2] = (uint8_t)(h[i] >> 8);
        out[4 * i + 3] = (uint8_t)h[i];
    }
}

}  // namespace sha

// ============================================================================
// Ключ и поток XOR (тот же алгоритм, что в encrypt_assets.py)
// ============================================================================

// key[i] = BASE[i] ^ current[i] ^ expected[i]. При честной подписи current == expected, ключ = BASE.
static void derive_key(const uint8_t current[32], const uint8_t expected[32]) {
    for (int i = 0; i < 32; i++) g_key[i] = BASE_KEY[i] ^ current[i] ^ expected[i];
}

static bool hex_to_bytes(const char* hex, uint8_t out[32]) {
    if (strlen(hex) != 64) return false;
    for (int i = 0; i < 32; i++) {
        unsigned v = 0;
        for (int j = 0; j < 2; j++) {
            char c = hex[2 * i + j];
            unsigned d;
            if (c >= '0' && c <= '9') d = c - '0';
            else if (c >= 'a' && c <= 'f') d = c - 'a' + 10;
            else if (c >= 'A' && c <= 'F') d = c - 'A' + 10;
            else return false;
            v = v * 16 + d;
        }
        out[i] = (uint8_t)v;
    }
    return true;
}

// Байт i зашифрован как src[i] ^ (key[i % 32] ^ ((i * 31) & 0xFF)), где i — позиция в файле.
static void xor_stream(const uint8_t* src, uint8_t* dst, size_t len, size_t start) {
    for (size_t i = 0; i < len; i++) {
        size_t pos = start + i;
        uint8_t k = g_key[pos % 32] ^ (uint8_t)((pos * 31) & 0xFF);
        dst[i] = src[i] ^ k;
    }
}

#ifndef JARVIS_HOST_TEST
#include <jni.h>
// ============================================================================
// JNI (ВНИМАНИЕ: этот блок не проверен компилятором — в контейнере нет Android NDK)
// ============================================================================

// Достаёт байты сертификата текущего APK. Возвращает false при любой ошибке.
static bool read_cert_bytes(JNIEnv* env, jobject context, std::vector<uint8_t>& out) {
    auto bail = [&]() {
        if (env->ExceptionCheck()) env->ExceptionClear();
        return false;
    };

    jclass ctxCls = env->GetObjectClass(context);
    jmethodID mGetPM = env->GetMethodID(ctxCls, "getPackageManager", "()Landroid/content/pm/PackageManager;");
    jmethodID mGetName = env->GetMethodID(ctxCls, "getPackageName", "()Ljava/lang/String;");
    if (!mGetPM || !mGetName) return bail();
    jobject pm = env->CallObjectMethod(context, mGetPM);
    jstring pkg = (jstring)env->CallObjectMethod(context, mGetName);
    if (!pm || !pkg) return bail();

    jclass verCls = env->FindClass("android/os/Build");
    if (!verCls) return bail();
    jint sdk = env->GetStaticIntField(verCls, env->GetStaticFieldID(verCls, "SDK_INT", "I"));

    // GET_SIGNING_CERTIFICATES = 0x08000000 (API 28+), GET_SIGNATURES = 0x40 (старые)
    jint flags = sdk >= 28 ? 0x08000000 : 0x40;
    jclass pmCls = env->GetObjectClass(pm);
    jmethodID mInfo = env->GetMethodID(pmCls, "getPackageInfo", "(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;");
    if (!mInfo) return bail();
    jobject info = env->CallObjectMethod(pm, mInfo, pkg, flags);
    if (!info) return bail();

    jclass piCls = env->GetObjectClass(info);
    jobjectArray sigs = nullptr;
    if (sdk >= 28) {
        jfieldID fSigningInfo = env->GetFieldID(piCls, "signingInfo", "Landroid/content/pm/SigningInfo;");
        jobject signingInfo = env->GetObjectField(info, fSigningInfo);
        if (!signingInfo) return bail();
        jclass siCls = env->GetObjectClass(signingInfo);
        jmethodID mSigners = env->GetMethodID(siCls, "getApkContentsSigners", "()[Landroid/content/pm/Signature;");
        if (!mSigners) return bail();
        sigs = (jobjectArray)env->CallObjectMethod(signingInfo, mSigners);
    } else {
        jfieldID fSigs = env->GetFieldID(piCls, "signatures", "[Landroid/content/pm/Signature;");
        sigs = (jobjectArray)env->GetObjectField(info, fSigs);
    }
    if (!sigs || env->GetArrayLength(sigs) == 0) return bail();

    jobject sig0 = env->GetObjectArrayElement(sigs, 0);
    if (!sig0) return bail();
    jclass sigCls = env->GetObjectClass(sig0);
    jmethodID mBytes = env->GetMethodID(sigCls, "toByteArray", "()[B");
    if (!mBytes) return bail();
    jbyteArray bytes = (jbyteArray)env->CallObjectMethod(sig0, mBytes);
    if (!bytes) return bail();

    jsize n = env->GetArrayLength(bytes);
    out.resize((size_t)n);
    env->GetByteArrayRegion(bytes, 0, n, reinterpret_cast<jbyte*>(out.data()));
    return !env->ExceptionCheck();
}

extern "C" JNIEXPORT void JNICALL
Java_com_AX_NativeSecurity_initSecurity(JNIEnv* env, jclass, jobject context) {
    uint8_t expected[32];
    if (!hex_to_bytes(EXPECTED_SHA256, expected)) return;  // тихо: ключ останется нулевым

    std::vector<uint8_t> cert;
    if (!read_cert_bytes(env, context, cert)) return;  // тихо: мусор вместо ошибки

    uint8_t current[32];
    sha::digest(cert.data(), cert.size(), current);
    derive_key(current, expected);
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_AX_NativeSecurity_decryptBytesNative(JNIEnv* env, jclass, jbyteArray data) {
    jsize n = env->GetArrayLength(data);
    std::vector<uint8_t> src((size_t)n), dst((size_t)n);
    env->GetByteArrayRegion(data, 0, n, reinterpret_cast<jbyte*>(src.data()));
    xor_stream(src.data(), dst.data(), (size_t)n, 0);
    jbyteArray out = env->NewByteArray(n);
    env->SetByteArrayRegion(out, 0, n, reinterpret_cast<const jbyte*>(dst.data()));
    return out;
}
#endif  // JARVIS_HOST_TEST
