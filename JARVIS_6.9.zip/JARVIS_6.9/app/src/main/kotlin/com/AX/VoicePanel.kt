package com.AX

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import java.io.File
import kotlin.math.roundToInt

/**
 * Блок в Настройки → «Звук и распознавание»:
 *  - РАСПОЗНАВАНИЕ: фраза активации (Джарвис / Мита / Инженер / своя);
 *  - ОЗВУЧКА: голос ответа (выбирается отдельно от фразы) и запись своего голоса;
 *  - СЦЕНАРИИ: редактор своего языка JarvisScript.
 */
object VoicePanel {

    private const val MAX_RECORD_MS = 10_000 // SoundPool не держит длиннее ~11 с
    private const val MIN_RECORD_MS = 500L
    private const val MIN_FILE_BYTES = 1500L

    private val main = Handler(Looper.getMainLooper())
    private var recorder: MediaRecorder? = null
    private var recordingId: String? = null
    private var recordingFile: File? = null
    private var recordingStarted = 0L
    private var startRunnable: Runnable? = null
    private var player: MediaPlayer? = null

    fun build(act: Activity, requestMic: () -> Unit): LinearLayout {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        val textColor = ContextCompat.getColor(act, R.color.text)
        val dimColor = ContextCompat.getColor(act, R.color.dim)
        val accent = ContextCompat.getColor(act, R.color.accent)

        Voices.ensureDefaults(act)
        val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }

        fun section(title: String): LinearLayout {
            root.addView(TextView(act).apply {
                text = title
                setTextColor(accent)
                textSize = 12f
                setPadding(px(4), px(24), px(4), px(8))
            })
            return LinearLayout(act).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(px(16), px(4), px(16), px(12))
            }.also { root.addView(it) }
        }

        fun chipRow(
            options: List<String>,
            label: (String) -> String,
            selected: () -> String,
            onPick: (String) -> Unit,
        ): LinearLayout {
            val views = linkedMapOf<String, TextView>()
            fun paint() = views.forEach { (key, view) ->
                val on = selected() == key
                view.setTextColor(if (on) accent else textColor)
                view.typeface = if (on) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
            val row = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
            for (key in options) {
                val view = TextView(act).apply {
                    text = label(key)
                    textSize = 12f
                    maxLines = 1
                    gravity = Gravity.CENTER
                    setBackgroundResource(R.drawable.chip)
                    setPadding(px(2), px(10), px(2), px(10))
                    isClickable = true
                    isFocusable = true
                    setOnClickListener {
                        onPick(key)
                        paint()
                    }
                }
                views[key] = view
                row.addView(view, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = px(6)
                })
            }
            paint()
            return row
        }

        // ================= РАСПОЗНАВАНИЕ =================
        val recognition = section("РАСПОЗНАВАНИЕ")
        recognition.addView(caption(act, "Фраза активации: на какое слово реагирует приложение", dimColor, ::px))

        val customInput = EditText(act).apply {
            hint = "Своя фраза, например: пятница"
            setHintTextColor(dimColor)
            setTextColor(textColor)
            textSize = 14f
            setSingleLine(true)
            setText(Prefs.wakeCustom)
            visibility = if (Prefs.wakePhrase == Voices.WAKE_CUSTOM) View.VISIBLE else View.GONE
            doAfterTextChanged { Prefs.wakeCustom = it?.toString().orEmpty() }
            setOnFocusChangeListener { _, focused -> if (!focused) JarvisListenService.refresh(act) }
        }
        recognition.addView(chipRow(Voices.wakePhrases, Voices::wakeChipTitle, { Prefs.wakePhrase }) {
            Prefs.wakePhrase = it
            customInput.visibility = if (it == Voices.WAKE_CUSTOM) View.VISIBLE else View.GONE
            if (it == Voices.WAKE_CUSTOM && Prefs.wakeCustom.isBlank()) {
                Toast.makeText(act, "Введите свою фразу ниже", Toast.LENGTH_SHORT).show()
            }
            JarvisListenService.refresh(act)
        })
        recognition.addView(customInput)
        recognition.addView(caption(
            act,
            "Фраза и голос независимы: можно будить словом «Мита», а отвечать голосом Джарвиса.",
            dimColor, ::px
        ))

        // ================= ОЗВУЧКА =================
        val voice = section("ОЗВУЧКА")
        voice.addView(caption(act, "Голос: чем отвечает приложение", dimColor, ::px))
        voice.addView(chipRow(
            listOf(Voices.JARVIS, Voices.ENGINEER, Voices.MITA, Voices.CUSTOM),
            Voices::title,
            { Prefs.voice },
        ) {
            Prefs.voice = it
            SoundPlayer.current?.playKind(VoiceKind.ACK, it)
        })
        voice.addView(caption(
            act,
            "Открытие приложений и браузера озвучивается всегда. Изменения настроек озвучиваются с шансом, который задаётся ниже.",
            dimColor, ::px
        ))
        val chanceLabel = caption(act, "Шанс озвучки настроек: ${Prefs.settingsChance}%", textColor, ::px)
        voice.addView(chanceLabel)
        voice.addView(android.widget.SeekBar(act).apply {
            max = 100
            progress = Prefs.settingsChance
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        Prefs.settingsChance = p
                        chanceLabel.text = "Шанс озвучки настроек: $p%"
                    }
                }
                override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
                override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {}
            })
        })
        voice.addView(chip(act, "Записать свой голос", textColor, ::px) { showRecorder(act, requestMic) }, params(::px))
        voice.addView(chip(act, "Удалить свой голос", textColor, ::px) {
            Voices.clearCustom(act)
            SoundPlayer.current?.reset()
            Toast.makeText(act, "Свой голос удалён", Toast.LENGTH_SHORT).show()
        }, params(::px))

        // ================= СЦЕНАРИИ =================
        val scripts = section("СВОЙ ЯЗЫК · JARVISSCRIPT")
        scripts.addView(caption(
            act,
            "Короткие программы на русском: переменные, условия, циклы, функции и вызов обычных команд. " +
                "Запуск голосом: «запусти сценарий».",
            dimColor, ::px
        ))
        scripts.addView(chip(act, "Открыть редактор сценариев", accent, ::px) { showScriptEditor(act) }, params(::px))
        return root
    }

    private fun caption(act: Activity, message: String, color: Int, px: (Int) -> Int): TextView =
        TextView(act).apply {
            text = message
            setTextColor(color)
            textSize = 12f
            setPadding(0, px(8), 0, px(4))
        }

    private fun params(px: (Int) -> Int) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.WRAP_CONTENT,
        LinearLayout.LayoutParams.WRAP_CONTENT,
    ).apply { topMargin = px(8) }

    private fun chip(act: Activity, label: String, textColor: Int, px: (Int) -> Int, onClick: () -> Unit): TextView =
        TextView(act).apply {
            text = label
            setTextColor(textColor)
            textSize = 13f
            setBackgroundResource(R.drawable.chip)
            setPadding(px(14), px(10), px(14), px(10))
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }

    // ================= Окно записи: список фраз =================

    private fun showRecorder(act: Activity, requestMic: () -> Unit) {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        val list = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(8), px(16), px(8))
        }
        val scroll = ScrollView(act).apply { addView(list) }

        fun redraw() {
            list.removeAllViews()
            for (entry in Voices.entries(act)) list.addView(entryRow(act, entry, requestMic) { redraw() }, params(::px))
            list.addView(
                chip(act, "+ Ещё фраза", ContextCompat.getColor(act, R.color.accent), ::px) {
                    askNewPhrase(act) { redraw() }
                },
                params(::px)
            )
        }

        redraw()
        val dialog = AlertDialog.Builder(act)
            .setTitle("Свой голос")
            .setView(scroll)
            .setPositiveButton("Готово", null)
            .create()
        dialog.setOnDismissListener {
            stopRecording(act) {}
            player?.release()
            player = null
        }
        dialog.show()
    }

    private fun entryRow(
        act: Activity,
        entry: Voices.Entry,
        requestMic: () -> Unit,
        refresh: () -> Unit,
    ): LinearLayout {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        val textColor = ContextCompat.getColor(act, R.color.text)
        val dimColor = ContextCompat.getColor(act, R.color.dim)
        val accent = ContextCompat.getColor(act, R.color.accent)
        val file = Voices.customFile(act, entry.id)
        val isRecording = recordingId == entry.id
        val isPreparing = isRecording && recorder == null

        val row = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        row.addView(TextView(act).apply {
            val state = when {
                isPreparing -> "подготовка…"
                isRecording -> "● идёт запись (до ${MAX_RECORD_MS / 1000} с)"
                file.exists() -> "записано"
                else -> "не записано"
            }
            text = "«${entry.label}» · ${entry.kind.title} · $state"
            setTextColor(if (isRecording) accent else textColor)
            textSize = 14f
        })
        val buttons = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT
        buttons.addView(chip(act, if (isRecording) "■ Стоп" else "● Запись", textColor, ::px) {
            if (isRecording) {
                stopRecording(act, refresh)
            } else {
                val granted = ContextCompat.checkSelfPermission(act, Manifest.permission.RECORD_AUDIO) ==
                    PackageManager.PERMISSION_GRANTED
                if (!granted) {
                    Toast.makeText(act, "Разрешите микрофон и нажмите «Запись» ещё раз", Toast.LENGTH_LONG).show()
                    requestMic()
                } else {
                    beginRecording(act, entry.id, refresh)
                }
            }
        }, LinearLayout.LayoutParams(wrap, wrap).apply { marginEnd = px(6) })
        buttons.addView(chip(act, "▶", textColor, ::px) {
            if (file.exists()) playFile(act, file) else Toast.makeText(act, "Эта фраза ещё не записана", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(wrap, wrap).apply { marginEnd = px(6) })
        buttons.addView(chip(act, "✕", dimColor, ::px) {
            if (recordingId == entry.id) stopRecording(act) {}
            Voices.removeEntry(act, entry.id)
            SoundPlayer.current?.reset()
            refresh()
        }, LinearLayout.LayoutParams(wrap, wrap))
        row.addView(buttons, params(::px))
        return row
    }

    private fun askNewPhrase(act: Activity, onAdded: () -> Unit) {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        val input = EditText(act).apply { hint = "Текст фразы, например: открытие браузера" }
        val kinds = VoiceKind.values()
        val spinner = Spinner(act).apply {
            adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, kinds.map { it.title })
        }
        val form = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(8), px(16), px(8))
            addView(input)
            addView(spinner)
        }
        AlertDialog.Builder(act)
            .setTitle("Новая фраза")
            .setView(form)
            .setPositiveButton("Добавить") { _, _ ->
                val typed = input.text.toString().trim()
                if (typed.isNotEmpty()) {
                    Voices.addEntry(act, typed, kinds[spinner.selectedItemPosition])
                    onAdded()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // ================= Запись и проигрывание =================
    //
    // Почему раньше запись не сохранялась: микрофон держал распознаватель фразы активации,
    // и MediaRecorder либо не стартовал, либо писал тишину. Теперь на время записи
    // слушалка ставится на паузу, а файл пишется сразу в папку голоса и проверяется.

    @Suppress("DEPRECATION")
    private fun newRecorder(act: Activity): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(act) else MediaRecorder()

    private fun beginRecording(act: Activity, id: String, refresh: () -> Unit) {
        stopRecording(act) {}
        WakeLoop.pause() // отпускаем микрофон
        recordingId = id
        refresh()
        val task = Runnable { startNow(act, id, refresh) }
        startRunnable = task
        main.postDelayed(task, 400) // даём распознавателю время освободить микрофон
    }

    private fun startNow(act: Activity, id: String, refresh: () -> Unit) {
        startRunnable = null
        if (recordingId != id) return // отменили, пока ждали
        val dir = Voices.customFile(act, id).parentFile
        val file = File(dir, "$id.tmp").apply { delete() }
        val rec = newRecorder(act)
        try {
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioSamplingRate(44100)
            rec.setAudioChannels(1)
            rec.setAudioEncodingBitRate(96000)
            rec.setMaxDuration(MAX_RECORD_MS)
            rec.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) {
                    main.post { if (recordingId == id) stopRecording(act) { refresh() } }
                }
            }
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            rec.start()
            recorder = rec
            recordingFile = file
            recordingStarted = SystemClock.elapsedRealtime()
        } catch (e: Exception) {
            try { rec.release() } catch (_: Exception) {}
            file.delete()
            recordingId = null
            WakeLoop.resume()
            AppLog.sound("ERR", "Запись не началась: ${e.message}", "запись не началась")
            Toast.makeText(act, "Не удалось начать запись: проверьте разрешение микрофона", Toast.LENGTH_LONG).show()
        }
        refresh()
    }

    /** Останавливает запись и сохраняет её файлом фразы. Слишком короткую или пустую запись отбрасываем. */
    private fun stopRecording(act: Activity, done: () -> Unit) {
        startRunnable?.let { main.removeCallbacks(it) }
        startRunnable = null
        val rec = recorder
        val id = recordingId
        val file = recordingFile
        val started = recordingStarted
        recorder = null
        recordingId = null
        recordingFile = null
        if (rec == null) {
            if (id != null) WakeLoop.resume() // ждали старт и отменили
            return done()
        }
        var stopped = false
        try {
            rec.stop()
            stopped = true
        } catch (e: RuntimeException) {
            // слишком короткая запись
        } finally {
            try { rec.release() } catch (_: Exception) {}
        }
        WakeLoop.resume()

        val tooShort = SystemClock.elapsedRealtime() - started < MIN_RECORD_MS
        if (!stopped || id == null || file == null || tooShort || file.length() < MIN_FILE_BYTES) {
            file?.delete()
            Toast.makeText(act, "Запись слишком короткая, попробуйте ещё раз", Toast.LENGTH_SHORT).show()
            return done()
        }
        val target = Voices.customFile(act, id)
        target.delete()
        val saved = file.renameTo(target) || try {
            file.copyTo(target, overwrite = true)
            file.delete()
            true
        } catch (e: Exception) {
            false
        }
        if (saved) {
            SoundPlayer.current?.reset()
            AppLog.sound("INFO", "Фраза записана: ${target.name} (${target.length()} байт)", null)
            playFile(act, target) // сразу проигрываем: слышно, что записалось
            val hint = if (Prefs.voice == Voices.CUSTOM) "Фраза записана" else
                "Фраза записана. Чтобы она звучала, выберите голос «Свой голос»"
            Toast.makeText(act, hint, Toast.LENGTH_LONG).show()
        } else {
            file.delete()
            AppLog.sound("ERR", "Файл записи не сохранён: $target", "запись не сохранена")
            Toast.makeText(act, "Не удалось сохранить запись", Toast.LENGTH_LONG).show()
        }
        done()
    }

    private fun playFile(act: Activity, file: File) {
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                prepare()
                start()
            }
        } catch (e: Exception) {
            Toast.makeText(act, "Не удалось проиграть запись", Toast.LENGTH_SHORT).show()
        }
    }

    // ================= Редактор JarvisScript =================

    private fun showScriptEditor(act: Activity) {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        val textColor = ContextCompat.getColor(act, R.color.text)
        val dimColor = ContextCompat.getColor(act, R.color.dim)
        val accent = ContextCompat.getColor(act, R.color.accent)

        val input = EditText(act).apply {
            setText(Prefs.scriptText.ifBlank { JarvisScript.EXAMPLE })
            typeface = Typeface.MONOSPACE
            textSize = 13f
            setTextColor(textColor)
            gravity = Gravity.TOP or Gravity.START
            minLines = 8
            maxLines = 14
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            setBackgroundResource(R.drawable.input)
            setPadding(px(10), px(10), px(10), px(10))
        }
        val output = TextView(act).apply {
            text = "Вывод появится здесь"
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(dimColor)
            setPadding(px(4), px(4), px(4), px(4))
        }
        val outScroll = ScrollView(act).apply { addView(output) }

        val buttons = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        val wrap = LinearLayout.LayoutParams.WRAP_CONTENT
        fun btnParams() = LinearLayout.LayoutParams(wrap, wrap).apply { marginEnd = px(6) }

        buttons.addView(chip(act, "▶ Запустить", accent, ::px) {
            val src = input.text.toString()
            Prefs.scriptText = src
            output.setTextColor(textColor)
            output.text = ""
            Thread {
                val err = ScriptRunner.runSource(act, src) { line ->
                    act.runOnUiThread { output.append(line + "\n") }
                }
                act.runOnUiThread {
                    if (err != null) {
                        output.setTextColor(ContextCompat.getColor(act, R.color.accent))
                        output.append("✕ $err\n")
                    } else {
                        output.append("✓ готово\n")
                    }
                }
            }.start()
        }, btnParams())
        buttons.addView(chip(act, "■", textColor, ::px) { ScriptRunner.stop() }, btnParams())
        buttons.addView(chip(act, "Пример", textColor, ::px) { input.setText(JarvisScript.EXAMPLE) }, btnParams())
        buttons.addView(chip(act, "?", textColor, ::px) { showScriptHelp(act) }, btnParams())

        val body = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(8), px(16), px(8))
            addView(input)
            addView(buttons, params(::px))
            addView(outScroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(120)).apply {
                topMargin = px(8)
            })
        }
        val dialog = AlertDialog.Builder(act)
            .setTitle("Сценарии JarvisScript")
            .setView(ScrollView(act).apply { addView(body) })
            .setPositiveButton("Закрыть", null)
            .create()
        dialog.setOnDismissListener {
            Prefs.scriptText = input.text.toString()
            ScriptRunner.stop()
        }
        dialog.show()
    }

    private fun showScriptHelp(act: Activity) {
        val help = """
            Комментарий: # текст

            пусть имя = "Тони"   (или просто имя = 5)
            сказать "Привет, " + имя
            выполнить "открой браузер"
            ждать 2   (секунды)

            если громкость > 50 { ... } иначе { ... }
            пока x < 10 { x = x + 1 }
            повторить 3 раз { ... }

            функция квадрат(x) { вернуть x * x }
            стоп   (завершить сценарий)

            Операторы: + - * / %  == != < > <= >=  и  или  не
            Значения: числа, "строки", да, нет
            Готовые: громкость, время, час, минута
            Функции: длина(т), число(т), текст(х), округлить(х),
            случайное(от, до), верхний(т), нижний(т), содержит(т, часть)

            Голосом: «запусти сценарий».
        """.trimIndent()
        AlertDialog.Builder(act)
            .setTitle("Справка по языку")
            .setMessage(help)
            .setPositiveButton("Понятно", null)
            .show()
    }
}
