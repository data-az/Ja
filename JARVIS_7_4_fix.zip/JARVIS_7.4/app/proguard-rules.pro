# Add project-specific ProGuard/R8 keep rules here.
# These are applied on top of the bundled defaults (proguard-android-optimize.txt) when the
# build type has minifyEnabled = true.
#
# Keep a class that is referenced only by reflection / from XML, e.g.:
# -keep class com.example.SomeClass { *; }
#
# Preserve line numbers for readable crash stack traces, then hide the original file name:
# -keepattributes SourceFile,LineNumberTable
# -renamesourcefileattribute SourceFile

# Vosk: библиотека вызывает нативный код через JNA и reflection, R8 не должен их трогать.
-keep class org.vosk.** { *; }
-keep class com.sun.jna.** { *; }
-dontwarn java.awt.**

# JNI: нативные методы объявлены в NativeSecurity и вызываются из native-lib по имени.
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class com.AX.NativeSecurity { *; }
-keep class com.AX.JarvisApp { *; }
