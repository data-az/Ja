cmake_minimum_required(VERSION 3.22.1)
project(native_lib LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_library(native-lib SHARED native-lib.cpp)

# Скрываем всё, кроме JNI-функций (JNIEXPORT): внутренние имена не видны в .so
target_compile_options(native-lib PRIVATE -O2 -fvisibility=hidden -fvisibility-inlines-hidden)
target_link_options(native-lib PRIVATE -s)
