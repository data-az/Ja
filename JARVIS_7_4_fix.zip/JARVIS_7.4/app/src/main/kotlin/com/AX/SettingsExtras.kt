package com.AX

import android.app.Activity
import android.content.Intent
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

/** Выбор приложения из всех приложений с экраном запуска (включая системные). */
object AppPicker {

    class Entry(val label: String, val pkg: String)

    fun launchable(act: Activity): List<Entry> {
        val pm = act.packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Entry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    /** [onPicked] получает выбранное приложение или null, если выбран пункт «Сбросить выбор». */
    fun show(act: Activity, title: String, allowClear: Boolean, onPicked: (Entry?) -> Unit) {
        val apps = launchable(act)
        val items = ArrayList<String>()
        val entries = ArrayList<Entry?>()
        if (allowClear) {
            items.add("— Сбросить выбор —")
            entries.add(null)
        }
        for (app in apps) {
            items.add(app.label)
            entries.add(app)
        }
        AlertDialog.Builder(act)
            .setTitle(title)
            .setItems(items.toTypedArray()) { _, which -> onPicked(entries[which]) }
            .setNegativeButton("Отмена", null)
            .show()
    }
}

/** Блок в Настройках → Команды: какое приложение открывать для «включи музыку / видео / фото». */
object CategoryPanel {

    fun build(act: Activity): LinearLayout {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        val textColor = ContextCompat.getColor(act, R.color.text)
        val dimColor = ContextCompat.getColor(act, R.color.dim)
        val borderColor = ContextCompat.getColor(act, R.color.border)

        val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        val values = HashMap<String, TextView>()

        fun render(cat: String) {
            val app = if (Prefs.categoryPkg(cat).isEmpty()) "не выбрано" else Prefs.categoryLabel(cat)
            values[cat]?.text = app
        }

        MusicCommands.CATEGORY_WORDS.keys.forEachIndexed { i, cat ->
            if (i > 0) {
                root.addView(
                    View(act).apply { setBackgroundColor(borderColor) },
                    LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(1))
                        .apply { marginStart = px(16) }
                )
            }
            val title = TextView(act).apply {
                text = MusicCommands.CATEGORY_TITLES[cat] ?: cat
                setTextColor(textColor)
                textSize = 15f
            }
            val value = TextView(act).apply {
                setTextColor(dimColor)
                textSize = 13f
                gravity = Gravity.END
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            values[cat] = value
            val arrow = TextView(act).apply {
                text = "›"
                setTextColor(dimColor)
                textSize = 20f
                setPadding(px(8), 0, 0, 0)
            }
            val row = LinearLayout(act).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(px(16), px(14), px(12), px(14))
                isClickable = true
                isFocusable = true
                setBackgroundResource(android.R.drawable.list_selector_background)
                setOnClickListener {
                    AppPicker.show(act, "Приложение: ${MusicCommands.CATEGORY_TITLES[cat]}", allowClear = true) { entry ->
                        if (entry == null) Prefs.clearCategoryApp(cat)
                        else Prefs.setCategoryApp(cat, entry.pkg, entry.label)
                        render(cat)
                    }
                }
            }
            row.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(value, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(arrow)
            root.addView(row, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            render(cat)
        }

        root.addView(TextView(act).apply {
            text = "«включи музыку / видео / фото» откроет выбранное приложение. " +
                "«открой …» по-прежнему ищет приложение по названию."
            setTextColor(dimColor)
            textSize = 12f
            setPadding(px(16), px(12), px(16), px(14))
        })
        return root
    }
}
