package com.AX

import android.content.Context

/**
 * Мост к нативной библиотеке native-lib (app/src/main/cpp/native-lib.cpp).
 * Проверка подписи и расшифровка ассетов. Если библиотека не загрузилась, decrypt() вернёт null.
 */
object NativeSecurity {

    private val loaded: Boolean = try {
        System.loadLibrary("native-lib")
        true
    } catch (e: UnsatisfiedLinkError) {
        AppLog.sound("ERR", "Нативная библиотека не загружена: ${e.message}", "звук недоступен")
        false
    }

    @JvmStatic
    private external fun initSecurity(context: Context)

    @JvmStatic
    private external fun decryptBytesNative(data: ByteArray): ByteArray

    /** Вызывать один раз при старте процесса (из JarvisApp.onCreate). */
    fun init(context: Context) {
        if (loaded) initSecurity(context)
    }

    /** Расшифровывает целиком (index.jdat или фраза). null, если библиотека недоступна. */
    fun decrypt(data: ByteArray): ByteArray? = if (loaded) decryptBytesNative(data) else null
}
