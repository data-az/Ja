package com.AX

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * После перезагрузки телефона поднимает службу прослушивания, если слово «Джарвис» или шарик были включены.
 * Пользователь не обязан открывать приложение заново. Поведение зависит от версии Android и модели телефона.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED && action != Intent.ACTION_LOCKED_BOOT_COMPLETED) return
        Prefs.init(context)
        if (!Prefs.wakeWord && !Prefs.orbOn) return
        try {
            JarvisListenService.refresh(context)
        } catch (e: Exception) {
            // Система может не разрешить запуск службы из фона: приложение поднимет её при открытии.
        }
    }
}
