package com.AX

import android.app.Activity
import android.net.Uri
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import java.io.File
import java.io.IOException
import kotlin.math.roundToInt

/**
 * Блок внутри карточки «Быстрое распознавание»: статус модели, «Выбрать архив модели»
 * (пользователь сам указывает zip в системном окне) и «Загрузить модель» с Яндекс Диска.
 */
object OfflineModelPanel {

    /** Куда писать статус. Системное окно выбора возвращает результат позже, поэтому держим ссылку здесь. */
    private var sayStatus: ((String) -> Unit)? = null

    fun build(act: Activity, onPick: () -> Unit): LinearLayout {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        val textColor = ContextCompat.getColor(act, R.color.text)
        val dimColor = ContextCompat.getColor(act, R.color.dim)

        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), 0, px(16), px(16))
        }
        val status = TextView(act).apply {
            setTextColor(dimColor)
            textSize = 12f
            setPadding(0, px(4), 0, px(4))
            setText(if (VoskModel.installedDir(act) != null) "Модель на телефоне" else "Модель не найдена")
        }
        val say: (String) -> Unit = { msg -> act.runOnUiThread { status.setText(msg) } }
        sayStatus = say

        fun button(label: String, onClick: () -> Unit): TextView = TextView(act).apply {
            setText(label)
            setTextColor(textColor)
            textSize = 13f
            setBackgroundResource(R.drawable.chip)
            setPadding(px(14), px(10), px(14), px(10))
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }

        fun params() = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply { topMargin = px(8) }

        box.addView(status)
        box.addView(button("Выбрать архив модели") { onPick() }, params())
        box.addView(button("Загрузить модель (с облака)") { downloadModel(act, say) }, params())
        return box
    }

    /** Архив, который пользователь выбрал в системном окне: копируем в приложение, распаковываем, загружаем. */
    fun importArchive(act: Activity, uri: Uri) {
        val say = sayStatus ?: return
        say("Копирую выбранный архив…")
        Thread {
            try {
                val dir = File(act.filesDir, "vosk").apply { mkdirs() }
                val tmp = File(dir, "picked.zip")
                val input = act.contentResolver.openInputStream(uri)
                    ?: throw IOException("файл недоступен")
                input.use { src -> tmp.outputStream().use { dst -> src.copyTo(dst) } }
                say("Распаковываю…")
                val ok = VoskModel.unpack(act, tmp)
                tmp.delete()
                if (ok) {
                    loadEngine(act, say, "Модель установлена")
                } else {
                    say("В архиве нет папок am и graph. Выберите архив модели Vosk")
                }
            } catch (e: Exception) {
                say("Не удалось открыть архив: ${e.message}")
            }
        }.start()
    }

    private fun downloadModel(act: Activity, say: (String) -> Unit) {
        say("Подключаюсь к облаку…")
        Thread {
            try {
                val zip = VoskModel.download(act) { say(it) }
                say("Скачано, распаковываю…")
                val ok = VoskModel.unpack(act, zip)
                zip.delete()
                if (ok) {
                    loadEngine(act, say, "Модель скачана")
                } else {
                    say("Не удалось распаковать архив")
                }
            } catch (e: Exception) {
                say("Не удалось скачать: ${e.message}")
            }
        }.start()
    }

    private fun loadEngine(act: Activity, say: (String) -> Unit, prefix: String) {
        if (VoskEngine.ready) {
            say("$prefix. Уже в памяти")
            return
        }
        VoskEngine.load(act) { ok, msg ->
            say(if (ok) "$prefix. $msg" else msg)
            if (ok) WakeLoop.reset(act)
        }
    }
}
