// Минимальная заглушка jni.h ТОЛЬКО для проверки синтаксиса и типов native-lib.cpp без NDK.
// Не для запуска. Реальный jni.h приходит с Android NDK.
#pragma once
#include <cstdint>
typedef uint8_t jboolean; typedef int8_t jbyte; typedef int32_t jint; typedef int32_t jsize; typedef int64_t jlong;
struct _jobject {}; typedef _jobject* jobject;
typedef jobject jclass; typedef jobject jstring; typedef jobject jobjectArray; typedef jobject jbyteArray;
struct _jmethodID; typedef _jmethodID* jmethodID;
struct _jfieldID; typedef _jfieldID* jfieldID;
#define JNIEXPORT
#define JNICALL
#define JNI_ABORT 2
struct JNIEnv_ {
    jclass FindClass(const char*);
    jclass GetObjectClass(jobject);
    jmethodID GetMethodID(jclass, const char*, const char*);
    jfieldID GetFieldID(jclass, const char*, const char*);
    jfieldID GetStaticFieldID(jclass, const char*, const char*);
    jint GetStaticIntField(jclass, jfieldID);
    jobject GetObjectField(jobject, jfieldID);
    jobject CallObjectMethod(jobject, jmethodID, ...);
    jsize GetArrayLength(jobject);
    jobject GetObjectArrayElement(jobjectArray, jsize);
    void GetByteArrayRegion(jbyteArray, jsize, jsize, jbyte*);
    void SetByteArrayRegion(jbyteArray, jsize, jsize, const jbyte*);
    jbyteArray NewByteArray(jsize);
    jbyte* GetByteArrayElements(jbyteArray, jboolean*);
    void ReleaseByteArrayElements(jbyteArray, jbyte*, jint);
    jboolean ExceptionCheck();
    void ExceptionClear();
};
typedef JNIEnv_ JNIEnv;
