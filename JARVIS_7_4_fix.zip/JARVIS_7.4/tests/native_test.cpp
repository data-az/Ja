// Хост-тест криптоядра (без JNI). Сборка: g++ -O2 -DJARVIS_HOST_TEST tests/native_test.cpp -o /tmp/nt
#define JARVIS_HOST_TEST
#include "../app/src/main/cpp/native-lib.cpp"
#include <cstdio>
#include <fstream>
#include <iterator>
#include <string>

static std::vector<uint8_t> readf(const char* p) {
    std::ifstream f(p, std::ios::binary);
    return std::vector<uint8_t>((std::istreambuf_iterator<char>(f)), {});
}

int main(int argc, char** argv) {
    std::string mode = argv[1];
    if (mode == "hash") {                       // hash <file>: печатает SHA-256
        auto d = readf(argv[2]);
        uint8_t out[32]; sha::digest(d.data(), d.size(), out);
        for (auto b : out) printf("%02x", b);
        printf("\n");
    } else if (mode == "decrypt") {             // decrypt <in> <out>: честная подпись (current==expected)
        uint8_t zero[32] = {0};
        derive_key(zero, zero);
        auto d = readf(argv[2]);
        std::vector<uint8_t> o(d.size());
        xor_stream(d.data(), o.data(), d.size(), 0);
        std::ofstream(argv[3], std::ios::binary).write((const char*)o.data(), o.size());
    } else if (mode == "tamper") {              // tamper <in> <out>: подпись чужая -> должен быть мусор
        uint8_t cur[32], exp_[32] = {0};
        memset(cur, 0xAB, 32);
        derive_key(cur, exp_);
        auto d = readf(argv[2]);
        std::vector<uint8_t> o(d.size());
        xor_stream(d.data(), o.data(), d.size(), 0);
        std::ofstream(argv[3], std::ios::binary).write((const char*)o.data(), o.size());
    }
    return 0;
}
