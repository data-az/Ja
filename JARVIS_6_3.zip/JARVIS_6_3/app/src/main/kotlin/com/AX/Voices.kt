package com.AX

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import kotlin.random.Random

/** Тип действия, под который выбирается фраза голоса. */
enum class VoiceKind(val title: String) {
    WAKE("слово активации"),
    ACK("задача"),
    APP("приложение"),
    APP_NOT_FOUND("приложение не найдено"),
    WEB("браузер / сайт"),
    SETTINGS("настройки"),
    VIEW("вид меню"),
    EDITOR("редактор"),
    COMMANDS("команды"),
    MUSIC("музыка"),
    FOLDER("папка"),
    VOLUME("громкость"),
    ORB("шарик"),
    OTHER_AI("другие ИИ"),
    ERROR("ошибка"),
    CAMERA("камера"),
    GALLERY("галерея"),
    MESSAGE("сообщение"),
    CALL("звонок");

    companion object {
        /** Какой звук нужен для команды. Порядок важен: более конкретные правила идут выше. */
        fun fromCommand(text: String): VoiceKind {
            val t = text.lowercase()
            return when {
                Regex("браузер|сайт|интернет|хром|chrome|брав|brave|опера|opera|яндекс|yandex|firefox|файрфокс|фаерфокс|edge|google|гугл|ютуб|youtube").containsMatchIn(t) -> WEB
                Regex("редактор").containsMatchIn(t) -> EDITOR
                Regex("шарик").containsMatchIn(t) -> ORB
                Regex("громк").containsMatchIn(t) -> VOLUME
                Regex("папк").containsMatchIn(t) -> FOLDER
                Regex("музык|песн|трек|играй").containsMatchIn(t) -> MUSIC
                Regex("команд").containsMatchIn(t) -> COMMANDS
                Regex("вид|меню|тем[ауы]|внешн").containsMatchIn(t) -> VIEW
                Regex("камер").containsMatchIn(t) -> CAMERA
                Regex("галере|снимк|фото").containsMatchIn(t) -> GALLERY
                Regex("звон").containsMatchIn(t) -> CALL
                Regex("сообщ").containsMatchIn(t) -> MESSAGE
                Regex("открой|открыть|запусти|включи|старт").containsMatchIn(t) -> APP
                else -> ACK
            }
        }
    }
}

/** Голоса ассистента: встроенные (assets/voices) и свой, записанный пользователем. */
object Voices {
    const val JARVIS = "jarvis"
    const val ENGINEER = "engineer"
    const val MITA = "mita"
    const val CUSTOM = "custom"

    /** Шанс, что Джарвис прокомментирует изменение настройки. */
    const val SETTINGS_COMMENT_CHANCE = 0.3f

    /** Голос, который ответил на слово активации в этой сессии. Пусто — берём голос из настроек. */
    @Volatile
    var wakeVoice: String? = null

    fun title(voice: String): String = when (voice) {
        JARVIS -> "Джарвис"
        ENGINEER -> "Инженер"
        MITA -> "Мита"
        else -> "Свой голос"
    }

    /** Голос, которым сейчас отвечает ассистент. */
    fun currentVoice(): String = wakeVoice ?: Prefs.voice

    // ---- Слова активации: каждое слово включается отдельно и отвечает своим голосом ----

    private val wordPatterns = listOf(
        JARVIS to "джарвис|жарвис",
        MITA to "мита",
        ENGINEER to "инженер",
    )

    private fun enabledVoices(): List<String> = buildList {
        if (Prefs.wakeJarvisWord) add(JARVIS)
        if (Prefs.wakeMita) add(MITA)
        if (Prefs.wakeEngineer) add(ENGINEER)
    }.ifEmpty { listOf(JARVIS) }

    /** Регулярка для всех включённых слов. Если ни одно не включено — только «Джарвис». */
    fun wakeRegex(): Regex {
        val parts = enabledVoices().map { v ->
            "(?:" + wordPatterns.first { it.first == v }.second + ")\\w*"
        }
        return Regex(parts.joinToString("|"))
    }

    /** Каким голосом отвечает найденное слово активации. */
    fun voiceForWake(word: String): String =
        wordPatterns.firstOrNull { Regex(it.second).containsMatchIn(word) }?.first ?: JARVIS

    /** Разбор фразы: слово активации в начале задаёт голос; [bare] — слово сказано без команды. */
    class WakeSplit(val voice: String?, val rest: String, val bare: Boolean)

    fun splitWake(text: String): WakeSplit {
        val trimmed = text.trim()
        val low = trimmed.lowercase()
        val m = wakeRegex().find(low)
        if (m == null || m.range.first != 0) return WakeSplit(null, trimmed, false)
        val rest = low.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?')
        return WakeSplit(voiceForWake(m.value), rest, rest.isEmpty())
    }

    /** Комментарий к изменению настроек: звучит не всегда. */
    fun commentsSettings(): Boolean = Random.nextFloat() < SETTINGS_COMMENT_CHANCE

    // ---- Встроенные голоса из assets/voices ----

    /** Один звук для проигрывания: либо файл из assets, либо свой m4a. */
    class Source(val key: String, val asset: String?, val file: File?)

    @Volatile
    private var index: Map<String, Map<String, List<String>>>? = null

    private fun builtIn(ctx: Context): Map<String, Map<String, List<String>>> {
        index?.let { return it }
        val parsed = HashMap<String, Map<String, List<String>>>()
        try {
            val root = JSONObject(ctx.assets.open("voices/index.json").bufferedReader(Charsets.UTF_8).use { it.readText() })
            for (voice in root.keys()) {
                val kinds = root.getJSONObject(voice)
                val map = HashMap<String, List<String>>()
                for (kind in kinds.keys()) {
                    val arr = kinds.getJSONArray(kind)
                    map[kind] = (0 until arr.length()).map { "voices/" + arr.getString(it) }
                }
                parsed[voice] = map
            }
        } catch (e: Exception) {
            AppLog.sound("ERR", "Не прочитан список голосов: ${e.message}", "голоса не загружены")
        }
        index = parsed
        return parsed
    }

    // ---- Свой голос: список фраз (текст, тип действия, файл) ----

    data class Entry(val id: String, val label: String, val kind: VoiceKind)

    private fun customJson(ctx: Context) = File(ctx.filesDir, "voices/custom.json")

    fun customFile(ctx: Context, id: String): File =
        File(ctx.filesDir, "voices/custom").apply { mkdirs() }.let { File(it, "$id.m4a") }

    fun entries(ctx: Context): List<Entry> {
        val f = customJson(ctx)
        if (!f.exists()) return emptyList()
        return try {
            val arr = JSONArray(f.readText(Charsets.UTF_8))
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Entry(o.getString("id"), o.getString("label"), VoiceKind.valueOf(o.getString("kind")))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(ctx: Context, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(JSONObject().put("id", e.id).put("label", e.label).put("kind", e.kind.name))
        }
        customJson(ctx).apply { parentFile?.mkdirs() }.writeText(arr.toString(), Charsets.UTF_8)
    }

    /** Добавляет фразу и возвращает её. Файла записи пока нет. */
    fun addEntry(ctx: Context, label: String, kind: VoiceKind): Entry {
        val e = Entry(UUID.randomUUID().toString().take(8), label.trim(), kind)
        save(ctx, entries(ctx) + e)
        return e
    }

    fun removeEntry(ctx: Context, id: String) {
        customFile(ctx, id).delete()
        save(ctx, entries(ctx).filterNot { it.id == id })
    }

    /** Первый раз предлагаем четыре фразы из примера пользователя. */
    fun ensureDefaults(ctx: Context) {
        if (customJson(ctx).exists()) return
        save(
            ctx,
            listOf(
                Entry("browser", "открытие браузера", VoiceKind.WEB),
                Entry("app", "приложение", VoiceKind.APP),
                Entry("settings", "настройки", VoiceKind.SETTINGS),
                Entry("view", "вид меню", VoiceKind.VIEW),
            )
        )
    }

    fun hasCustom(ctx: Context): Boolean = entries(ctx).any { customFile(ctx, it.id).exists() }

    /** Удаляет все записи своего голоса. */
    fun clearCustom(ctx: Context) {
        entries(ctx).forEach { customFile(ctx, it.id).delete() }
        customJson(ctx).delete()
    }

    // ---- Что проигрывать для голоса и типа действия ----

    /**
     * Все варианты для голоса и типа. Если у голоса нет своей фразы для этого типа —
     * берём «задачу» (ACK): так у Джарвиса нет «слова активации», но ответ всё равно звучит.
     */
    fun sources(ctx: Context, voice: String, kind: VoiceKind, strict: Boolean = false): List<Source> {
        if (voice == CUSTOM) {
            val mine = entries(ctx).filter { it.kind == kind && customFile(ctx, it.id).exists() }
                .ifEmpty {
                    if (strict) emptyList()
                    else entries(ctx).filter { it.kind == VoiceKind.ACK && customFile(ctx, it.id).exists() }
                }
            return mine.map { Source("custom:${it.id}", null, customFile(ctx, it.id)) }
        }
        val kinds = builtIn(ctx)[voice] ?: return emptyList()
        // strict: без запасной фразы, иначе «приложение не найдено» прозвучит как «задача»
        val list = kinds[kind.name] ?: if (strict) emptyList() else kinds[VoiceKind.ACK.name].orEmpty()
        return list.map { Source("$voice:$it", it, null) }
    }
}
