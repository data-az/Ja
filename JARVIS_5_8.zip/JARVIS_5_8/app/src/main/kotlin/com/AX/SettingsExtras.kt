package com.AX

import android.app.Activity
import android.content.Intent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

/** Выбор приложения из всех приложений с экраном запуска (включая системные). */
object AppPicker {

    class Entry(val label: String, val pkg: String)

    fun launchable(act: Activity): List<Entry> {
        val pm = act.packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Entry(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    /** [onPicked] получает выбранное приложение или null, если выбран пункт «Сбросить выбор». */
    fun show(act: Activity, title: String, allowClear: Boolean, onPicked: (Entry?) -> Unit) {
        val apps = launchable(act)
        val items = ArrayList<String>()
        val entries = ArrayList<Entry?>()
        if (allowClear) {
            items.add("— Сбросить выбор —")
            entries.add(null)
        }
        for (app in apps) {
            items.add(app.label)
            entries.add(app)
        }
        AlertDialog.Builder(act)
            .setTitle(title)
            .setItems(items.toTypedArray()) { _, which -> onPicked(entries[which]) }
            .setNegativeButton("Отмена", null)
            .show()
    }
}

/** Блок в Настройках → Команды: какое приложение открывать для «включи музыку / видео / фото». */
object CategoryPanel {

    fun build(act: Activity): LinearLayout {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        val text = ContextCompat.getColor(act, R.color.text)
        val dim = ContextCompat.getColor(act, R.color.dim)

        val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        root.addView(TextView(act).apply {
            text = "ВКЛЮЧИ: ПРИЛОЖЕНИЯ"
            setTextColor(ContextCompat.getColor(act, R.color.accent))
            textSize = 12f
            setPadding(px(4), px(24), px(4), px(8))
        })

        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(4), px(16), px(4))
        }
        val rows = HashMap<String, TextView>()

        fun render(cat: String) {
            val title = MusicCommands.CATEGORY_TITLES[cat] ?: cat
            val app = if (Prefs.categoryPkg(cat).isEmpty()) "не выбрано" else Prefs.categoryLabel(cat)
            rows[cat]?.text = "$title: $app"
        }

        for (cat in MusicCommands.CATEGORY_WORDS.keys) {
            val row = TextView(act).apply {
                setTextColor(text)
                textSize = 14f
                setPadding(0, px(12), 0, px(12))
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    AppPicker.show(act, "Приложение: ${MusicCommands.CATEGORY_TITLES[cat]}", allowClear = true) { entry ->
                        if (entry == null) Prefs.clearCategoryApp(cat)
                        else Prefs.setCategoryApp(cat, entry.pkg, entry.label)
                        render(cat)
                    }
                }
            }
            rows[cat] = row
            box.addView(row)
            render(cat)
        }

        box.addView(TextView(act).apply {
            text = "«включи музыку / видео / фото» откроет выбранное приложение. " +
                "«открой …» по-прежнему ищет приложение по названию."
            setTextColor(dim)
            textSize = 12f
            setPadding(0, px(8), 0, px(8))
        })
        root.addView(box)
        return root
    }
}
