package com.AX

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.IOException
import java.util.zip.ZipInputStream

/**
 * Импорт паков голосов RuVoice (zip с pack.json и моделями .pte/.ptl).
 * Копия хранится в Джарвисе: RuVoice не включает паки в бэкап Android,
 * и после переустановки их можно поставить заново из этой копии.
 */
object VoicePacks {
    private const val DIR = "voicepacks"

    fun dir(ctx: Context): File = File(ctx.filesDir, DIR).apply { mkdirs() }

    /** Проверяет архив и копирует его. Блокирующий — вызывать вне UI-потока. Возвращает текст для экрана. */
    fun importZip(ctx: Context, uri: Uri): String {
        val name = displayName(ctx, uri) ?: "ruvoice-pack.zip"
        if (!name.lowercase().endsWith(".zip")) return "Нужен zip-архив пака, получен файл: $name"
        val tmp = File(dir(ctx), "import.tmp")
        return try {
            val input = ctx.contentResolver.openInputStream(uri) ?: return "Файл не открывается"
            input.use { src -> tmp.outputStream().use { src.copyTo(it) } }

            val entries = listEntries(tmp)
            val hasPack = entries.any { it.equals("pack.json", ignoreCase = true) }
            val hasModel = entries.any { it.endsWith(".pte", true) || it.endsWith(".ptl", true) }
            if (!hasPack || !hasModel) {
                tmp.delete()
                return "Это не пак RuVoice: нужны pack.json и модели .pte/.ptl. В архиве: ${entries.joinToString()}"
            }

            val dst = File(dir(ctx), name)
            if (dst.exists()) dst.delete()
            if (!tmp.renameTo(dst)) throw IOException("не удалось сохранить $name")
            val mb = dst.length() / 1024 / 1024
            AppLog.sound("OK", "Пак голосов сохранён: ${dst.absolutePath} ($mb МБ)", "пак сохранён")
            "Пак «$name» принят ($mb МБ). Голоса появятся в RuVoice после установки файла: " +
                "меню RuVoice → «Дополнительные голоса» → «Установить из файла»."
        } catch (e: Exception) {
            tmp.delete()
            AppLog.sound("ERR", "Импорт пака: ${e.javaClass.simpleName}: ${e.message}", "импорт пака не удался")
            "Не удалось импортировать: ${e.message}"
        }
    }

    /** Имена файлов в zip (без папок). */
    private fun listEntries(f: File): List<String> =
        ZipInputStream(f.inputStream().buffered()).use { z ->
            generateSequence { z.nextEntry }
                .map { it.name.substringAfterLast('/') }
                .filter { it.isNotEmpty() }
                .toList()
        }

    private fun displayName(ctx: Context, uri: Uri): String? = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }
}
