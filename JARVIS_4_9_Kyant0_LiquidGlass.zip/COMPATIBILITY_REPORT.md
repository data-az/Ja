# JARVIS 4.9 — отчёт о совместимости (статическая проверка)

## Liquid Glass migration
Cloudy удалён из зависимостей и исходников. Его dock API заменён на оригинальный Kyant0 Backdrop 2.0.1. Остальные зависимости и `minSdk = 26` сохранены.

Сборка Gradle в среде проверки не запускалась (нет сети/SDK). Проверены метаданные версий, требования библиотек и код.

## Найденные проблемы и исправления
| # | Проблема | Исправление |
|---|----------|-------------|
| 1 | activity-compose 1.9.2 при Compose 1.12 (BOM 2026.08.00): рассинхрон activity/core/lifecycle | 1.13.0 |
| 2 | onnxruntime-android 1.17.1: .so не рассчитаны на 16 КБ страницы (Android 15+, targetSdk 37) | 1.22.0 (нативная поддержка 16 КБ) |
| 3 | Liquid Glass dock использовал Cloudy и его API | заменён на Kyant0 Backdrop 2.0.1; зависимость Cloudy удалена |
| 4 | material 1.9.0 / appcompat 1.6.1 / core-ktx 1.10.1 / coroutines 1.7.3 перекрывались транзитивно более новыми | 1.13.0 / 1.7.1 / 1.19.0 / 1.10.2 |
| 5 | `onBackPressed()` не вызывается при targetSdk 36+ (предиктивный «назад») — кнопка «назад» в подстраницах настроек сломана | OnBackPressedCallback + enableOnBackInvokedCallback |
| 6 | ComposeView по умолчанию поглощает window insets: View-страницы не получали отступы статус-бара и IME | AbstractComposeView.consumeWindowInsets = false (import androidx.compose.foundation.layout.consumeWindowInsets) |
| 7 | Workflow: Build Tools не ставились явно | добавлен build-tools;36.0.0, timeout 45 мин |
| 8 | Документы расходились (AGP 9.1.0 vs 9.1.1, Gradle 9.3.1 vs 9.5, android.yml vs build-apk.yml) | выровнены |

## Проверено и оставлено как есть
AGP 9.1.1 ↔ Gradle 9.5.0 (мин. 9.3.1) · AGP 9.1.1 ↔ compileSdk/targetSdk 37 · Kotlin 2.4.0 ↔ Gradle 9.5.0 · KGP 2.4.0 ↔ Compose plugin 2.4.0 ·
Compose 1.12 ↔ AGP ≥ 9.1.1 · BOM ↔ material3 1.4.0 · builtInKotlin=false / newDsl=false ↔ внешний kotlin.android · JDK 17 ↔ AGP/Kotlin ·
Kyant0 Backdrop 2.0.1 API (rememberLayerBackdrop/layerBackdrop/drawBackdrop) используется в JarvisComposeHost · R.* ссылки на ресурсы (битых нет) ·
удалённые API Kotlin 2.x (toLowerCase, appendln, sumBy…) — не используются.

## Не проверено (нужен реальный запуск)
Компиляция Kotlin и визуальная работа Kyant0 Backdrop поверх AndroidView не запускались в этой среде; требуется проверить Gradle-сборку и экран на устройстве. Линза включается только на API 33+.
