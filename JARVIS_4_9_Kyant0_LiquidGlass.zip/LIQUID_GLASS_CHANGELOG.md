# JARVIS 4.9 — Kyant0 Liquid Glass update

Изменены только два файла приложения:

1. `app/build.gradle.kts` — удалена зависимость Cloudy и добавлена `io.github.kyant0:backdrop:2.0.1`. Все остальные зависимости, версии плагинов, `compileSdk`, `targetSdk` и `minSdk` сохранены.
2. `app/src/main/kotlin/com/AX/JarvisComposeHost.kt` — старый Cloudy dock заменён на `rememberLayerBackdrop` / `layerBackdrop` / `drawBackdrop`. Навигация, callback-ы, иконки, анимация выбранного пункта и haptics сохранены.

## Android API

- `minSdk = 26` оставлен без изменений, чтобы не отрезать старые устройства.
- Kyant0 Backdrop blur/color-filter эффекты требуют Android 12 (API 31)+. На API ниже 31 библиотека отключает эти эффекты.
- Оптическая AGSL-лиза `lens()` включается только на Android 13 (API 33)+.

Следовательно, на Android 11 приложение остаётся совместимым, но настоящий blur/refraction Liquid Glass недоступен из-за ограничений платформы.

## Проверка

Исходный архив не содержит Gradle Wrapper, а среда подготовки не имеет доступного Gradle/Android SDK и сетевого доступа к Maven Central. Поэтому APK-сборка здесь не запускалась. Проект подготовлен статически; после открытия в Android Studio нужно выполнить Gradle Sync и `:app:assembleDebug`.
