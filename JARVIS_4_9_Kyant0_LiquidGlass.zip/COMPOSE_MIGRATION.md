# JARVIS 4.9 — Jetpack Compose / Kyant0 Backdrop integration

## Liquid Glass dock

- Replaced the former Cloudy-based dock rendering with Kyant0 Backdrop (`io.github.kyant0:backdrop:2.0.1`).
- The existing Android View screens, navigation callbacks, icons, selection animation, haptics, and layout remain in place.
- The legacy screen is captured with `rememberLayerBackdrop()` / `Modifier.layerBackdrop(backdrop)`.
- The Compose dock uses `Modifier.drawBackdrop(...)` with `vibrancy()`, `blur(16.dp)`, and `lens(...)` in that order.
- The AGSL lens is enabled only on Android 13+ (API 33); on Android 8–12 the dock retains the backdrop vibrancy/blur treatment.

## Dependency changes

Removed:

```kotlin
implementation("com.github.skydoves:cloudy:0.7.1")
```

Added:

```kotlin
implementation("io.github.kyant0:backdrop:2.0.1")
```

No other app dependencies, Kotlin/AGP versions, SDK levels, or Android resources were intentionally changed. The project's existing `minSdk = 26` is preserved.

Reference: https://github.com/Kyant0/AndroidLiquidGlass
