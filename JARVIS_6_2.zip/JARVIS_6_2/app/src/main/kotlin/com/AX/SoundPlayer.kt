package com.AX

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.util.Collections

/**
 * Проигрывает фразы голоса. Звуки грузятся по требованию (холодный старт не страдает):
 * первый показ фразы грузит её и играет сразу после загрузки.
 *
 * Открытие приложения и браузера озвучивается всегда. Изменение настроек —
 * с шансом [Voices.SETTINGS_COMMENT_CHANCE] (см. [comment]).
 */
class SoundPlayer(private val context: Context) {

    private var pool: SoundPool = makePool()
    private val ids = HashMap<String, Int>()
    private val loaded: MutableSet<Int> = Collections.synchronizedSet(HashSet<Int>())
    private val waiting = HashMap<Int, Float>()
    private val playing: MutableSet<Int> = Collections.synchronizedSet(HashSet<Int>())
    private var lastKey: String? = null

    @Volatile
    private var released = false

    init {
        current = this
    }

    private fun makePool(): SoundPool {
        val p = SoundPool.Builder()
            .setMaxStreams(2)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
        p.setOnLoadCompleteListener { _, sampleId, status ->
            synchronized(this) {
                if (status == 0) {
                    loaded.add(sampleId)
                    val v = waiting.remove(sampleId)
                    if (v != null) play(sampleId, v)
                } else {
                    waiting.remove(sampleId)
                    AppLog.sound("ERR", "Фраза не загрузилась, статус $status", "фраза не загрузилась")
                }
            }
        }
        return p
    }

    /**
     * Играет случайную фразу голоса для типа действия. Возвращает поток (0, если пока не играет:
     * например, фраза ещё грузится и сыграет сразу после загрузки).
     */
    @Synchronized
    fun playKind(kind: VoiceKind, voice: String = Voices.currentVoice()): Int {
        if (released) return 0
        val list = Voices.sources(context, voice, kind)
        if (list.isEmpty()) {
            AppLog.sound("INFO", "У голоса «${Voices.title(voice)}» нет фраз для «${kind.title}»", null)
            return 0
        }
        val candidates = list.filter { it.key != lastKey }.ifEmpty { list }
        val pick = candidates.random()
        lastKey = pick.key
        val v = Prefs.soundVolume
        val id = ids[pick.key] ?: load(pick)
        if (id == 0) return 0
        AppLog.sound("INFO", "Голос ${Voices.title(voice)}: «${kind.title}» (громкость ${"%.2f".format(java.util.Locale.US, v)})", null)
        return if (loaded.contains(id)) play(id, v) else { waiting[id] = v; 0 }
    }

    /** Комментарий к действию с шансом [Voices.SETTINGS_COMMENT_CHANCE]. */
    @Synchronized
    fun comment(kind: VoiceKind, voice: String = Voices.currentVoice()): Int =
        if (Voices.commentsSettings()) playKind(kind, voice) else 0

    private fun play(id: Int, v: Float): Int {
        val stream = pool.play(id, v, v, 1, 0, 1f)
        if (stream != 0) playing.add(stream)
        return stream
    }

    private fun load(src: Voices.Source): Int {
        val id = try {
            val asset = src.asset
            if (asset != null) {
                context.assets.openFd(asset).use { pool.load(it, 1) }
            } else {
                pool.load(src.file!!.absolutePath, 1)
            }
        } catch (e: Exception) {
            AppLog.sound("ERR", "Не открыт файл фразы ${src.key}: ${e.message}", "фраза не открыта")
            0
        }
        if (id != 0) ids[src.key] = id
        return id
    }

    /** Сбрасывает загруженные фразы, например после записи или удаления своего голоса. */
    @Synchronized
    fun reset() {
        if (released) return
        pool.release()
        ids.clear()
        loaded.clear()
        waiting.clear()
        synchronized(playing) { playing.clear() }
        lastKey = null
        pool = makePool()
    }

    fun stop(streamId: Int) {
        if (!released && streamId != 0) pool.stop(streamId)
    }

    /** Обрывает все фразы, которые сейчас играют (перебивание голосом). */
    fun stopAll() {
        if (released) return
        synchronized(playing) {
            playing.forEach { pool.stop(it) }
            playing.clear()
        }
    }

    fun release() {
        released = true
        pool.release()
    }

    companion object {
        /** Последний созданный проигрыватель: нужен, чтобы перебивание работало из любого места. */
        @Volatile
        var current: SoundPlayer? = null

        fun stopCurrent() {
            current?.stopAll()
        }
    }
}
