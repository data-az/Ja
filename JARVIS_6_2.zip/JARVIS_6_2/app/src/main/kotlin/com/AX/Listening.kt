package com.AX

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlin.math.abs

/** Выключает системный «пик» при начале записи. Работает на время нажатия, потом возвращает звук. */
object Quiet {
    private val main = Handler(Looper.getMainLooper())

    fun beepOff(ctx: Context) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val muted = mutableListOf<Int>()
        for (s in intArrayOf(AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION)) {
            try {
                if (!am.isStreamMute(s)) {
                    am.adjustStreamVolume(s, AudioManager.ADJUST_MUTE, 0)
                    muted.add(s)
                }
            } catch (e: SecurityException) {
                // Нет права менять громкость этого потока: оставляем как есть.
            }
        }
        main.postDelayed({
            for (s in muted) {
                try {
                    am.adjustStreamVolume(s, AudioManager.ADJUST_UNMUTE, 0)
                } catch (e: SecurityException) {
                    // ignore
                }
            }
        }, 900L)
    }
}

/**
 * Слово «Джарвис» и команды после него. Весь цикл распознавания идёт на главном потоке,
 * как и требует SpeechRecognizer. Управляется настройками: [sync], [pause], [resume], [listenOnce].
 */
object WakeLoop {
    private val main = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var rec: SpeechRecognizer? = null
    private var active = false          // слушаем слово активации
    private var paused = false          // микрофон занят экраном приложения
    private var awaitingCommand = false // слово уже услышано, ждём команду
    private var oneShot = false         // нажат шарик: одна команда без слова
    /** Слова активации берём из настроек: «Джарвис», «Мита», «Инженер» — каждое включается отдельно. */
    private fun wakeWord(): Regex = Voices.wakeRegex()

    /** Запускает или останавливает цикл по настройкам. Вызывается при каждом изменении. */
    fun sync(ctx: Context) {
        main.post {
            app = ctx.applicationContext
            val want = Prefs.wakeWord && (Prefs.bgListen || JarvisListenService.appVisible)
            if (want && !active) {
                active = true
                ensureRec(ctx.applicationContext)
                listen()
            } else if (!want && active) {
                stopLoop()
            }
        }
    }

    /** Экран берёт микрофон себе (кнопка микрофона): цикл ставим на паузу. */
    fun pause() {
        // Синхронно: иначе новая фраза кнопки микрофона может остановиться отложенной остановкой.
        VoskEngine.stop()
        main.post {
            paused = true
            rec?.cancel()
        }
    }

    fun resume() = main.post {
        paused = false
        if (active) listen()
    }

    /** Нажат шарик: слушаем одну команду без слова «Джарвис». */
    fun listenOnce(ctx: Context) = main.post {
        app = ctx.applicationContext
        oneShot = true
        Quiet.beepOff(ctx.applicationContext)
        ensureRec(ctx.applicationContext)
        rec?.cancel()
        if (!paused) listen()
    }

    private fun ensureRec(ctx: Context) {
        if (rec != null || !SpeechRecognizer.isRecognitionAvailable(ctx)) return
        rec = OfflineSpeech.create(ctx).also { it.setRecognitionListener(listener) }
    }

    /** Пересоздаёт распознаватель, например после переключения офлайн-режима. */
    fun reset(ctx: Context) = main.post {
        VoskEngine.stop()
        rec?.destroy()
        rec = null
        if (active) {
            app = ctx.applicationContext
            ensureRec(ctx.applicationContext)
            listen()
        }
    }

    private fun stopLoop() {
        active = false
        awaitingCommand = false
        VoskEngine.stop()
        rec?.cancel()
    }

    /** Офлайн включён и модель Vosk загружена: слушаем через неё, а не через системный распознаватель. */
    private fun useVosk(): Boolean = Prefs.offline && VoskEngine.ready

    private fun startVosk(ctx: Context) {
        if (VoskEngine.running) return
        VoskEngine.start(
            oneShot = false,
            onText = { text -> handleText(ctx, text) },
            onFail = { msg ->
                AppLog.add("ERR", msg)
                relistenLater(1000)
            },
        )
    }

    private fun listen() {
        val ctx = app ?: return
        if (paused) return
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            AppLog.add("ERR", "Нет микрофона: слово «Джарвис» не слушаю")
            stopLoop()
            return
        }
        if (useVosk()) {
            startVosk(ctx)
            return
        }
        val r = rec ?: return
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, Prefs.offline)
        })
    }

    private fun relisten() {
        main.postDelayed({ if (active && !paused) listen() }, 250)
    }

    private fun relistenLater(ms: Long) {
        main.postDelayed({ if (active && !paused) listen() }, ms)
    }

    /** Сбой сервиса распознавания: пересоздаём распознаватель и продолжаем слушать. */
    private fun recreate() {
        rec?.destroy()
        rec = null
        val ctx = app ?: return
        ensureRec(ctx.applicationContext)
        relistenLater(1000)
    }

    private fun runCommand(ctx: Context, text: String) {
        Thread {
            val r = try {
                Commands.run(ctx, text)
            } catch (e: Throwable) {
                Reply(false, "Ошибка: ${e.message}")
            }
            AppLog.cmd(if (r.ok) "OK" else "ERR", "Голосом: «$text» → ${r.text}")
            main.post { Toast.makeText(ctx, r.text, Toast.LENGTH_SHORT).show() }
        }.start()
    }

    /** Одна распознанная фраза: команда, слово «Джарвис» или пустой результат. Общая для Android и Vosk. */
    private fun handleText(ctx: Context, raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) {
            oneShot = false
            awaitingCommand = false
            afterResult()
            return
        }
        val low = text.lowercase()
        when {
            oneShot || awaitingCommand -> {
                oneShot = false
                awaitingCommand = false
                runCommand(ctx, low)
                afterResult()
            }
            else -> {
                val m = wakeWord().find(low)
                if (m == null) {
                    afterResult()
                } else {
                    // Отвечаем голосом того слова, которое назвали: «Мита» — голосом Миты.
                    val voice = Voices.voiceForWake(m.value)
                    Voices.wakeVoice = voice
                    SoundPlayer.current?.playKind(VoiceKind.WAKE, voice)
                    // «Джарвис, открой телеграм» — команда в той же фразе; иначе ждём её отдельно.
                    val rest = low.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?')
                    if (rest.isNotEmpty()) {
                        runCommand(ctx, rest)
                    } else {
                        awaitingCommand = true
                        main.post { Toast.makeText(ctx, "Слушаю", Toast.LENGTH_SHORT).show() }
                    }
                    afterResult()
                }
            }
        }
    }

    /** Android-распознаватель после фразы надо перезапустить; Vosk слушает непрерывно. */
    private fun afterResult() {
        if (!useVosk()) relisten()
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}

        override fun onBeginningOfSpeech() {
            // Перебивание: пользователь заговорил — звуки Джарвиса смолкают.
            if (Prefs.bargeIn) SoundPlayer.stopCurrent()
            Orb.setListening(true)
        }

        override fun onRmsChanged(rmsdB: Float) {
            Orb.setLevel(rmsdB)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            oneShot = false
            awaitingCommand = false
            Orb.setListening(false)
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    stopLoop()
                    return
                }
                // Распознаватель занят (его держит другое приложение): не долбим его, ждём дольше.
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    if (!paused) relistenLater(1500)
                    return
                }
                // Сбой сервиса распознавания: пересоздаём распознаватель.
                SpeechRecognizer.ERROR_CLIENT, SpeechRecognizer.ERROR_SERVER -> {
                    main.post { recreate() }
                    return
                }
            }
            if (!paused) relisten()
        }

        override fun onResults(results: Bundle?) {
            Orb.setListening(false)
            val ctx = app ?: return
            handleText(ctx, results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty())
        }
    }
}

/**
 * Шарик поверх экрана в стиле реактора JARVIS (тот же [ReactorView]).
 * Его можно перетаскивать; нажатие без сдвига запускает прослушивание команды.
 */
object Orb {
    private var view: ReactorView? = null

    fun show(ctx: Context) {
        if (view != null || !Settings.canDrawOverlays(ctx)) return
        val dm = ctx.resources.displayMetrics
        val size = (64 * dm.density).toInt()
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(
            size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (Prefs.orbX >= 0) Prefs.orbX else dm.widthPixels - size - (16 * dm.density).toInt()
            y = if (Prefs.orbY >= 0) Prefs.orbY else dm.heightPixels / 2
        }
        val v = ReactorView(ctx)
        val slop = 8 * dm.density
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!moved && (abs(dx) > slop || abs(dy) > slop)) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        wm.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        Prefs.orbX = lp.x
                        Prefs.orbY = lp.y
                    } else {
                        v.performClick()
                    }
                    true
                }
                else -> false
            }
        }
        v.setOnClickListener { WakeLoop.listenOnce(ctx) }
        wm.addView(v, lp)
        view = v
    }

    fun hide(ctx: Context) {
        val v = view ?: return
        (ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        view = null
    }

    fun setListening(on: Boolean) {
        view?.listening = on
    }

    fun setLevel(rmsDb: Float) {
        view?.setLevel(rmsDb)
    }
}

/**
 * Служба переднего плана: держит микрофон и шарик, когда приложение не открыто.
 * Запускается только если включено слово «Джарвис» или шарик.
 */
class JarvisListenService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        val channel = NotificationChannel(CHANNEL, "Прослушивание", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        try {
            ServiceCompat.startForeground(
                this, NOTE_ID, notification(),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE else 0
            )
        } catch (e: Exception) {
            // Нет разрешения на микрофон для службы переднего плана: работаем без неё.
            AppLog.add("ERR", "Служба прослушивания не запущена: ${e.message}")
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (Prefs.orbOn) Orb.show(this) else Orb.hide(this)
        WakeLoop.sync(this)
        return START_STICKY
    }

    override fun onDestroy() {
        Orb.hide(this)
        WakeLoop.sync(this)
        super.onDestroy()
    }

    private fun notification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val text = when {
            Prefs.wakeWord && Prefs.bgListen -> "Слушаю слово «Джарвис» и вне приложения"
            Prefs.wakeWord -> "Слушаю слово «Джарвис», когда приложение открыто"
            else -> "Шарик на экране: нажмите, чтобы говорить"
        }
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("JARVIS AZ")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    companion object {
        private const val NOTE_ID = 77
        private const val CHANNEL = "jarvis_listen"

        /** Открыто ли приложение сейчас: в фоне слово «Джарвис» слушаем, только если это разрешено. */
        @Volatile
        var appVisible = false

        fun setVisible(ctx: Context, visible: Boolean) {
            appVisible = visible
            WakeLoop.sync(ctx)
        }

        /** Поднимает службу, если нужна, и останавливает, если не нужна. */
        fun refresh(ctx: Context) {
            val intent = Intent(ctx, JarvisListenService::class.java)
            if (Prefs.wakeWord || Prefs.orbOn) {
                try {
                    ContextCompat.startForegroundService(ctx, intent)
                } catch (e: Exception) {
                    AppLog.add("ERR", "Не удалось запустить прослушивание: ${e.message}")
                }
            } else {
                ctx.stopService(intent)
                WakeLoop.sync(ctx)
            }
        }
    }
}
