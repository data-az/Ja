package com.AX

import android.Manifest
import android.app.Activity
import android.graphics.Typeface
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import java.io.File
import kotlin.math.roundToInt

/**
 * Блок «Голос» в Настройках → Звук и распознавание:
 * выбор голоса, слова активации (каждое отвечает своим голосом) и запись своего голоса
 * списком фраз: «открытие браузера», «приложение», «настройки», «вид меню» и «Ещё фраза».
 */
object VoicePanel {

    private var recorder: MediaRecorder? = null
    private var recordingId: String? = null
    private var recordingTmp: File? = null
    private var player: MediaPlayer? = null

    fun build(act: Activity, requestMic: () -> Unit): LinearLayout {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        val textColor = ContextCompat.getColor(act, R.color.text)
        val dimColor = ContextCompat.getColor(act, R.color.dim)
        val accent = ContextCompat.getColor(act, R.color.accent)

        Voices.ensureDefaults(act)
        val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        root.addView(TextView(act).apply {
            setText("ГОЛОС")
            setTextColor(accent)
            textSize = 12f
            setPadding(px(4), px(24), px(4), px(8))
        })
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(4), px(16), px(12))
        }
        root.addView(box)

        // ---- Выбор голоса по умолчанию ----
        val chipViews = linkedMapOf<String, TextView>()
        fun paintChips() {
            chipViews.forEach { (voice, view) ->
                val selected = Prefs.voice == voice
                view.setTextColor(if (selected) accent else textColor)
                view.typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            }
        }
        val voiceRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        for (voice in listOf(Voices.JARVIS, Voices.ENGINEER, Voices.MITA, Voices.CUSTOM)) {
            val view = TextView(act).apply {
                setText(Voices.title(voice))
                textSize = 13f
                gravity = Gravity.CENTER
                setBackgroundResource(R.drawable.chip)
                setPadding(px(4), px(10), px(4), px(10))
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    Prefs.voice = voice
                    paintChips()
                    SoundPlayer.current?.playKind(VoiceKind.ACK, voice)
                }
            }
            chipViews[voice] = view
            voiceRow.addView(view, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = px(6)
            })
        }
        box.addView(caption(act, "Голос по умолчанию", dimColor, ::px))
        box.addView(voiceRow)
        paintChips()

        // ---- Слова активации ----
        box.addView(caption(act, "Слова активации: каждое отвечает своим голосом", dimColor, ::px))
        box.addView(wakeSwitch(act, "«Джарвис»", textColor, { Prefs.wakeJarvisWord }, { Prefs.wakeJarvisWord = it }))
        box.addView(wakeSwitch(act, "«Мита»", textColor, { Prefs.wakeMita }, { Prefs.wakeMita = it }))
        box.addView(wakeSwitch(act, "«Инженер»", textColor, { Prefs.wakeEngineer }, { Prefs.wakeEngineer = it }))

        // ---- Свой голос ----
        box.addView(caption(
            act,
            "Открытие приложений и браузера озвучивается всегда. Изменения настроек Джарвис комментирует примерно в 30% случаев.",
            dimColor, ::px
        ))
        box.addView(chip(act, "Записать свой голос", textColor, ::px) { showRecorder(act, requestMic) }, params(::px))
        box.addView(chip(act, "Удалить свой голос", textColor, ::px) {
            Voices.clearCustom(act)
            SoundPlayer.current?.reset()
            Toast.makeText(act, "Свой голос удалён", Toast.LENGTH_SHORT).show()
        }, params(::px))
        return root
    }

    private fun wakeSwitch(
        act: Activity,
        title: String,
        textColor: Int,
        get: () -> Boolean,
        set: (Boolean) -> Unit,
    ): SwitchCompat = SwitchCompat(act).apply {
        setText(title)
        setTextColor(textColor)
        isChecked = get()
        setOnCheckedChangeListener { _, on ->
            set(on)
            JarvisListenService.refresh(act)
        }
    }

    private fun caption(act: Activity, message: String, color: Int, px: (Int) -> Int): TextView =
        TextView(act).apply {
            setText(message)
            setTextColor(color)
            textSize = 12f
            setPadding(0, px(8), 0, px(4))
        }

    private fun params(px: (Int) -> Int) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.WRAP_CONTENT,
        LinearLayout.LayoutParams.WRAP_CONTENT,
    ).apply { topMargin = px(8) }

    private fun chip(act: Activity, label: String, textColor: Int, px: (Int) -> Int, onClick: () -> Unit): TextView =
        TextView(act).apply {
            setText(label)
            setTextColor(textColor)
            textSize = 13f
            setBackgroundResource(R.drawable.chip)
            setPadding(px(14), px(10), px(14), px(10))
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
        }

    // ---- Окно записи: список фраз ----

    private fun showRecorder(act: Activity, requestMic: () -> Unit) {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        val list = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(8), px(16), px(8))
        }
        val scroll = ScrollView(act).apply { addView(list) }
        lateinit var dialog: AlertDialog

        fun redraw() {
            list.removeAllViews()
            for (entry in Voices.entries(act)) list.addView(entryRow(act, entry, requestMic) { redraw() }, params(::px))
            list.addView(
                chip(act, "+ Ещё фраза", ContextCompat.getColor(act, R.color.accent), ::px) {
                    askNewPhrase(act) { redraw() }
                },
                params(::px)
            )
        }

        redraw()
        dialog = AlertDialog.Builder(act)
            .setTitle("Свой голос")
            .setView(scroll)
            .setPositiveButton("Готово", null)
            .create()
        dialog.setOnDismissListener {
            stopRecording(act) {}
            player?.release()
            player = null
        }
        dialog.show()
    }

    private fun entryRow(
        act: Activity,
        entry: Voices.Entry,
        requestMic: () -> Unit,
        refresh: () -> Unit,
    ): LinearLayout {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        val textColor = ContextCompat.getColor(act, R.color.text)
        val dimColor = ContextCompat.getColor(act, R.color.dim)
        val file = Voices.customFile(act, entry.id)
        val isRecording = recordingId == entry.id

        val row = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        row.addView(TextView(act).apply {
            val recorded = if (file.exists()) "записано" else "не записано"
            setText("«${entry.label}» · ${entry.kind.title} · $recorded")
            setTextColor(textColor)
            textSize = 14f
        })
        val buttons = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        buttons.addView(chip(act, if (isRecording) "■ Стоп" else "● Запись", textColor, ::px) {
            if (isRecording) {
                stopRecording(act, refresh)
            } else {
                if (ContextCompat.checkSelfPermission(act, Manifest.permission.RECORD_AUDIO) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    requestMic()
                    return@chip
                }
                startRecording(act, entry.id)
                refresh()
            }
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginEnd = px(6) })
        buttons.addView(chip(act, "▶", textColor, ::px) {
            if (file.exists()) playFile(act, file)
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginEnd = px(6) })
        buttons.addView(chip(act, "✕", dimColor, ::px) {
            if (recordingId == entry.id) stopRecording(act) {}
            Voices.removeEntry(act, entry.id)
            SoundPlayer.current?.reset()
            refresh()
        }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        row.addView(buttons, params(::px))
        return row
    }

    private fun askNewPhrase(act: Activity, onAdded: () -> Unit) {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        val input = EditText(act).apply { hint = "Текст фразы, например: открытие браузера" }
        val kinds = VoiceKind.values()
        val spinner = Spinner(act).apply {
            adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, kinds.map { it.title })
        }
        val form = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(8), px(16), px(8))
            addView(input)
            addView(spinner)
        }
        AlertDialog.Builder(act)
            .setTitle("Новая фраза")
            .setView(form)
            .setPositiveButton("Добавить") { _, _ ->
                val typed = input.text.toString().trim()
                if (typed.isNotEmpty()) {
                    Voices.addEntry(act, typed, kinds[spinner.selectedItemPosition])
                    onAdded()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // ---- Запись и проигрывание ----

    private fun startRecording(act: Activity, id: String) {
        stopRecording(act) {}
        val tmp = File(act.cacheDir, "rec_$id.m4a")
        tmp.delete()
        val rec = MediaRecorder()
        try {
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setAudioSamplingRate(44100)
            rec.setAudioChannels(1)
            rec.setAudioEncodingBitRate(96000)
            rec.setOutputFile(tmp.absolutePath)
            rec.prepare()
            rec.start()
            recorder = rec
            recordingId = id
            recordingTmp = tmp
        } catch (e: Exception) {
            rec.release()
            Toast.makeText(act, "Не удалось начать запись", Toast.LENGTH_SHORT).show()
        }
    }

    /** Останавливает запись и сохраняет её файлом фразы. Короткую запись отбрасываем. */
    private fun stopRecording(act: Activity, done: () -> Unit) {
        val rec = recorder ?: return done()
        val id = recordingId
        val tmp = recordingTmp
        recorder = null
        recordingId = null
        recordingTmp = null
        try {
            rec.stop()
            if (id != null && tmp != null) {
                val target = Voices.customFile(act, id)
                target.delete()
                if (tmp.renameTo(target)) {
                    SoundPlayer.current?.reset()
                    Toast.makeText(act, "Фраза записана", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            tmp?.delete()
            Toast.makeText(act, "Запись слишком короткая, попробуйте ещё раз", Toast.LENGTH_SHORT).show()
        } finally {
            rec.release()
        }
        done()
    }

    private fun playFile(act: Activity, file: File) {
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(file.absolutePath)
                prepare()
                start()
            }
        } catch (e: Exception) {
            Toast.makeText(act, "Не удалось проиграть запись", Toast.LENGTH_SHORT).show()
        }
    }
}
