# JARVIS 4.9 — Jetpack Compose / Cloudy migration

## What changed in this migration pass

- Added the Kotlin Compose compiler plugin and Jetpack Compose / Material 3 dependencies.
- Added Skydoves Cloudy (`com.github.skydoves:cloudy:0.7.1`).
- Replaced the Activity's XML root host with a Compose `ComposeView`.
- Embedded the existing three legacy page layouts in a Compose `AndroidView` compatibility host. This is intentional: existing View IDs, listeners, settings editors, logs, voice controls, and command bindings remain intact during the staged migration.
- Moved the bottom navigation dock to Jetpack Compose.
- Added Cloudy backdrop blur and Liquid Glass rendering to the Compose dock.
- Added spring-based active-indicator movement, icon scaling, haptic feedback, and animated dock visibility around the IME.
- Improved existing page transitions with directional translation, alpha, and subtle scale animation.

## Important scope note

This is a safe **hybrid migration**, not yet a full rewrite of every screen in Compose. The Activity shell and bottom navigation are Compose-native; the existing Home, Logs, and Settings page contents remain hosted through `AndroidView` so their behavior is not silently lost. A complete migration of those page internals requires moving each existing View binding and event handler into Compose state/ViewModels in separate, testable steps.

## Build

Open the project in Android Studio and run Gradle Sync. The build environment used to prepare this archive did not contain Gradle or an Android SDK, so an APK build could not be executed here. Resolve any dependency/plugin version prompts in Android Studio before generating the APK.

Cloudy reference: https://github.com/skydoves/Cloudy
