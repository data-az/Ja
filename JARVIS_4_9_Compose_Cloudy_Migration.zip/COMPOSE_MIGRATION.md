# JARVIS 4.9 — Compose host / Android 11 software glass

- Keeps the existing Compose host and the three legacy View-based pages.
- Keeps the original Gradle / Kotlin / Compose / AndroidX / ONNX Runtime / networking versions.
- Removes only the old Cloudy dependency/API from the supplied migration project.
- Retains the lower dock's in-project CPU glass renderer, spring indicator, icon scaling, haptics and visibility animation.
- Android 11 compatibility is provided without `RenderEffect`, AGSL `RuntimeShader`, `Modifier.blur()`, Cloudy, Kyant0 Backdrop or a new rendering dependency.
- Adds a Settings control for selecting a custom image background from Gallery/Files. The image is center-cropped, persisted using the document provider's read grant, and can be reset.
- Updates the other cards, chips and command input to a dark navy/blue glass palette so they no longer look pale/white against the background.

The CPU glass renderer is not Apple's private iOS compositor and not a 60 FPS GPU shader. It periodically captures a reduced-resolution region and performs optical processing on a background dispatcher. Performance depends on the phone.

## Build

Keep `JARVIS_4_9_Compose_Cloudy_Migration.zip` in the repository root. Copy `build-apk.yml` to `.github/workflows/build-apk.yml`. The workflow file is included unchanged.

A full Android SDK / Gradle build was not available in this environment. Run Gradle Sync and `:app:assembleDebug` in Android Studio or GitHub Actions before installing the APK.
