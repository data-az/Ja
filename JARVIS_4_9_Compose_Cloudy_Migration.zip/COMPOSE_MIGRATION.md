# JARVIS 4.9 — Compose host / Android 11 software glass

## What this package changes

- Keeps the existing Compose host and the three legacy View-based pages.
- Keeps the original Gradle / Kotlin / Compose / AndroidX / ONNX Runtime / networking versions.
- Removes only the Skydoves Cloudy dependency and its API calls.
- Replaces the dock's glass surface with `SoftwareLiquidGlass.kt`, a small in-project CPU renderer compatible with Android 8.0+ (including Android 11 / API 30).
- The renderer captures only the dock-sized region of the legacy Android View underneath it, downsamples it, then applies a compact blur pass, curved pixel displacement, RGB edge separation, saturation/contrast lift and a glass highlight.
- Keeps the existing dock navigation, spring indicator, icon scaling, haptics and visibility animation.

## Android compatibility

The software renderer does not use `RenderEffect`, AGSL `RuntimeShader`, `Modifier.blur()`, Cloudy, or Kyant0 Backdrop. Its optical processing is done on a reduced-resolution bitmap on a background dispatcher, so Android 11 can run it.

This is a custom CPU approximation, not Apple's private iOS compositor and not a GPU shader. The dock refreshes its captured background periodically (about 9 times per second); performance depends on the phone and complexity of the legacy screen. A true 60 FPS GPU implementation would require a separate OpenGL ES/EGL renderer and more invasive surface integration.

## Build

The original `build-apk.yml` workflow is included unchanged. Keep the project archive named `JARVIS_4_9_Compose_Cloudy_Migration.zip` in the repository root because the workflow searches for that exact filename. Copy `build-apk.yml` to `.github/workflows/build-apk.yml`.

The source archive was not built in this environment because an Android SDK / Gradle build environment was unavailable. Run Gradle Sync and `:app:assembleDebug` in Android Studio or GitHub Actions before installing the APK.
