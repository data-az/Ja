pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Cloudy is published through JitPack.
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "JARVIS AX"
include(":app")
