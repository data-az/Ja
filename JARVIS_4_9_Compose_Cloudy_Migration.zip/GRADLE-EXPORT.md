# JARVIS AX 4.9 — GitHub build configuration

The build is pinned to Android Gradle Plugin 9.1.1, Gradle 9.5.0, Kotlin 2.4.0, JDK 17, and Android SDK 37.

AGP 9.1 requires Gradle 9.3.1 or newer. This project temporarily opts out of AGP's built-in Kotlin and new DSL using `android.builtInKotlin=false` and `android.newDsl=false`, so the explicit Kotlin 2.4.0 Android and Compose compiler plugins can be applied without duplicate Kotlin extensions.

Cloudy 0.7.1 is on Maven Central; JitPack is no longer used.

The GitHub Actions workflow is at `.github/workflows/build-apk.yml`. It installs Gradle 9.5.0 directly, so a Gradle wrapper executable is not required on the CI runner. The project can be built with:

```bash
gradle :app:assembleDebug --stacktrace
```

The build must still be run in GitHub Actions to verify dependency resolution and Kotlin compilation in the target environment.
