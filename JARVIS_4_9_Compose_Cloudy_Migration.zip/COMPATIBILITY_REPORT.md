# JARVIS 4.9 — отчёт о совместимости (статическая проверка)

Сборка Gradle в среде проверки не запускалась (нет сети/SDK). Проверены метаданные версий, требования библиотек и код.

## Найденные проблемы и исправления
| # | Проблема | Исправление |
|---|----------|-------------|
| 1 | activity-compose 1.9.2 при Compose 1.12 (BOM 2026.08.00): рассинхрон activity/core/lifecycle | 1.13.0 |
| 2 | onnxruntime-android 1.17.1: .so не рассчитаны на 16 КБ страницы (Android 15+, targetSdk 37) | 1.22.0 (нативная поддержка 16 КБ) |
| 3 | JitPack в settings: Cloudy лежит в Maven Central, лишний репозиторий | удалён |
| 4 | material 1.9.0 / appcompat 1.6.1 / core-ktx 1.10.1 / coroutines 1.7.3 перекрывались транзитивно более новыми | 1.13.0 / 1.7.1 / 1.19.0 / 1.10.2 |
| 5 | `onBackPressed()` не вызывается при targetSdk 36+ (предиктивный «назад») — кнопка «назад» в подстраницах настроек сломана | OnBackPressedCallback + enableOnBackInvokedCallback |
| 6 | ComposeView по умолчанию поглощает window insets: View-страницы не получали отступы статус-бара и IME | consumeWindowInsets = false |
| 7 | Workflow: Build Tools не ставились явно | добавлен build-tools;36.0.0, timeout 45 мин |
| 8 | Документы расходились (AGP 9.1.0 vs 9.1.1, Gradle 9.3.1 vs 9.5, android.yml vs build-apk.yml) | выровнены |

## Проверено и оставлено как есть
AGP 9.1.1 ↔ Gradle 9.5.0 (мин. 9.3.1) · AGP 9.1.1 ↔ compileSdk/targetSdk 37 · Kotlin 2.4.0 ↔ Gradle 9.5.0 · KGP 2.4.0 ↔ Compose plugin 2.4.0 ·
Compose 1.12 ↔ AGP ≥ 9.1.1 · BOM ↔ material3 1.4.0 · builtInKotlin=false / newDsl=false ↔ внешний kotlin.android · JDK 17 ↔ AGP/Kotlin ·
Cloudy 0.7.1 API (cloudy/sky/liquidGlass/invalidate) ↔ вызовы в JarvisComposeHost · R.* ссылки на ресурсы (битых нет) ·
удалённые API Kotlin 2.x (toLowerCase, appendln, sumBy…) — не используются.

## Не проверено (нужен реальный запуск)
Компиляция Kotlin и пакеты импортов Cloudy (`com.skydoves.cloudy.*`) — сверены только с документацией; визуальная работа dock + AndroidView на устройстве.
