# JARVIS 4.9 — compatibility report

## Preserved from the supplied project

- AGP 9.1.1, Kotlin 2.4.0, Gradle 9.5.0 workflow, JDK 17.
- compileSdk 37, targetSdk 37, minSdk 26.
- Compose BOM 2026.08.00 and all existing AndroidX / Material / ONNX Runtime / OkHttp / Coroutines versions.
- Existing Activity, XML page layouts, View IDs, listeners, navigation callbacks and Compose host architecture.
- Supplied `build-apk.yml` copied unchanged.

## Rendering change

- Removed only `com.github.skydoves:cloudy:0.7.1` and its imports/calls.
- Added `SoftwareLiquidGlass.kt`, a self-contained CPU bitmap renderer. It captures the underlying legacy View region at reduced resolution and applies blur, optical displacement, RGB edge separation, color enhancement and specular tint.
- No `RenderEffect`, AGSL, `Modifier.blur()`, Cloudy, Kyant0 Backdrop or new dependency is used. Android 11 (API 30) is supported by this rendering path.

## Validation limits

Static source review and ZIP integrity checks only. An Android SDK / Gradle build and on-device visual/performance test were not available in this environment. Run Gradle Sync and `:app:assembleDebug` before installing. The CPU renderer is a visual approximation with periodic updates, not a 60 FPS GPU compositor; performance must be measured on the target phone.
