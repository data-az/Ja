# JARVIS 4.9 — Android 11 compatibility report

## Preserved from the supplied project

- Existing AGP/Kotlin/Gradle/JDK configuration and versions.
- compileSdk 37, targetSdk 37, minSdk 26.
- Compose BOM and all existing AndroidX / Material / ONNX Runtime / OkHttp / Coroutines versions.
- Existing Activity, XML page layouts, View IDs, listeners, navigation callbacks and Compose host architecture.
- Supplied `build-apk.yml` workflow retained unchanged.

## Rendering and appearance

- The existing lower software-glass dock renderer and dock navigation/animations are retained unchanged.
- No Cloudy, `RenderEffect`, AGSL, `Modifier.blur()` or additional rendering dependency is used.
- Non-dock cards, chips and command input use dark navy/blue glass fills instead of pale white translucent surfaces.
- A custom wallpaper picker is added to Settings. It uses Android's Storage Access Framework (`ACTION_OPEN_DOCUMENT` via `OpenDocument`), stores the selected URI permission, center-crops the image and restores it after restart.
- The wallpaper is darkened with a subtle overlay to preserve text contrast. Reset restores the original neon background.

## Validation limits

XML resources were parsed and the source was statically reviewed. A full Android SDK / Gradle build and on-device visual/performance test were not available in this environment. Run Gradle Sync and `:app:assembleDebug` before installing. The CPU renderer is a visual approximation with periodic updates, not a 60 FPS GPU compositor; performance must be measured on the target phone.
