package com.AX

import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.view.View
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Как часто обновлять снимок фона под стеклом. Раньше — каждый кадр, и это грузило процессор. */
private const val GLASS_REFRESH_MS = 600L

/**
 * Android 11-compatible software glass renderer.
 * Samples the actual legacy Android View under the Compose dock and performs
 * a downsampled CPU blur, lens displacement, RGB edge separation and color lift.
 * No RenderEffect, AGSL, Cloudy or additional rendering dependency is used.
 */
@Composable
internal fun SoftwareGlassBackdrop(
    backgroundView: View?,
    modifier: Modifier = Modifier,
) {
    var bounds by remember { mutableStateOf<Rect?>(null) }
    var glassBitmap by remember { mutableStateOf<Bitmap?>(null) }
    // Границы, для которых снят текущий bitmap. Пока границы не совпадают, старый кадр не рисуем:
    // иначе FillBounds растянет его на новые размеры (именно так панель «расползалась» после запуска).
    var glassRegion by remember { mutableStateOf<Rect?>(null) }

    LaunchedEffect(backgroundView, bounds) {
        val view = backgroundView ?: return@LaunchedEffect
        val region = bounds ?: return@LaunchedEffect
        // Первые кадры старта заняты раскладкой и инициализацией: стекло начинаем после них.
        delay(350L)
        while (isActive) {
            // Снимок фона обновляется раз в GLASS_REFRESH_MS, а не каждый кадр.
            val captured = withContext(Dispatchers.Main.immediate) {
                captureViewRegion(view, region)
            }
            val rendered = if (captured != null) {
                withContext(Dispatchers.Default) {
                    try { renderLiquidGlass(captured) } finally { captured.recycle() }
                }
            } else null
            if (rendered != null) {
                glassBitmap = rendered
                glassRegion = region
            }
            delay(GLASS_REFRESH_MS)
        }
    }

    Box(
        modifier = modifier.onGloballyPositioned { bounds = it.boundsInRoot() },
    ) {
        // Кадр рисуется только 1:1 для тех границ, для которых он снят.
        glassBitmap?.takeIf { glassRegion.sameRegion(bounds) }?.let { bitmap ->
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                filterQuality = FilterQuality.High,
                modifier = Modifier.fillMaxSize(),
            )
        }
        // Optical highlight and tint are layered over processed real background pixels.
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.18f),
                            Color(0x181A2A40),
                            Color(0x66101829),
                        )
                    )
                )
        )
    }
}

/** Совпадают ли прямоугольники с точностью до субпикселя (шум позиционирования не должен мигать кадром). */
private fun Rect?.sameRegion(other: Rect?): Boolean {
    if (this == null || other == null) return false
    return kotlin.math.abs(left - other.left) < 1f && kotlin.math.abs(top - other.top) < 1f &&
        kotlin.math.abs(width - other.width) < 1f && kotlin.math.abs(height - other.height) < 1f
}

/** Capture at reduced resolution; only the area behind the dock is retained. */
private fun captureViewRegion(view: View, bounds: Rect): Bitmap? {
    if (view.width <= 0 || view.height <= 0 || bounds.width <= 0f || bounds.height <= 0f) return null
    val scale = 0.2f
    val outW = max(1, (bounds.width * scale).roundToInt())
    val outH = max(1, (bounds.height * scale).roundToInt())
    val result = try {
        Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
    } catch (_: OutOfMemoryError) {
        return null
    }
    val canvas = AndroidCanvas(result)
    canvas.scale(scale, scale)
    canvas.translate(-bounds.left, -bounds.top)
    // Canvas clipping limits rasterization to the dock rectangle; no full-screen bitmap is made.
    view.draw(canvas)
    return result
}

/** CPU optical pass: Gaussian-like blur, curved displacement, RGB dispersion, saturation/contrast. */
private fun renderLiquidGlass(source: Bitmap): Bitmap {
    val width = source.width
    val height = source.height
    if (width < 2 || height < 2) return source.copy(Bitmap.Config.ARGB_8888, false)

    val input = IntArray(width * height)
    source.getPixels(input, 0, width, 0, 0, width, height)
    val blurred = boxBlur3x3(input, width, height)
    val output = IntArray(input.size)
    val minSide = min(width, height).toFloat()
    val maxShift = max(1f, minSide * 0.105f)

    for (y in 0 until height) {
        val ny = ((y + 0.5f) / height) * 2f - 1f
        for (x in 0 until width) {
            val nx = ((x + 0.5f) / width) * 2f - 1f
            val radius = sqrt(nx * nx + ny * ny)
            val edgeDistance = min(
                min(x.toFloat(), (width - 1 - x).toFloat()),
                min(y.toFloat(), (height - 1 - y).toFloat()),
            )
            val edge = (1f - edgeDistance / max(1f, minSide * 0.22f)).coerceIn(0f, 1f)
            val lens = ((1f - radius.coerceIn(0f, 1f)) * 0.55f + edge * 0.45f)
            val shiftX = nx * maxShift * lens
            val shiftY = ny * maxShift * lens
            val chroma = edge * 0.35f
            val sx = (x + shiftX).coerceIn(0f, (width - 1).toFloat())
            val sy = (y + shiftY).coerceIn(0f, (height - 1).toFloat())
            val red = sampleChannel(blurred, width, height, sx + chroma, sy, 16)
            val green = sampleChannel(blurred, width, height, sx, sy, 8)
            val blue = sampleChannel(blurred, width, height, sx - chroma, sy, 0)

            fun enhance(v: Int): Int = (((v - 128f) * 1.03f + 128f) * 1.02f + 1f)
                .roundToInt().coerceIn(0, 255)
            var r = enhance(red)
            var g = enhance(green)
            var b = enhance(blue)
            val gray = (r * 0.2126f + g * 0.7152f + b * 0.0722f)
            r = (gray + (r - gray) * 1.05f).roundToInt().coerceIn(0, 255)
            g = (gray + (g - gray) * 1.05f).roundToInt().coerceIn(0, 255)
            b = (gray + (b - gray) * 1.05f).roundToInt().coerceIn(0, 255)

            val rim = if (edge > 0.78f) ((edge - 0.78f) / 0.22f * 22f).roundToInt() else 0
            r = (r + rim).coerceAtMost(255)
            g = (g + rim).coerceAtMost(255)
            b = (b + rim).coerceAtMost(255)
            val fadeT = ((y + 0.5f) / (height * 0.5f)).coerceIn(0f, 1f)
            val alpha = (fadeT * fadeT * (3f - 2f * fadeT) * 255f).roundToInt()
            output[y * width + x] = (alpha shl 24) or (r shl 16) or (g shl 8) or b
        }
    }

    return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also {
        it.setPixels(output, 0, width, 0, 0, width, height)
    }
}

private fun boxBlur3x3(src: IntArray, width: Int, height: Int): IntArray {
    val tmp = IntArray(src.size)
    val out = IntArray(src.size)
    for (y in 0 until height) for (x in 0 until width) {
        var a = 0; var r = 0; var g = 0; var b = 0; var weight = 0
        for (dx in -1..1) {
            val xx = (x + dx).coerceIn(0, width - 1)
            val c = src[y * width + xx]
            val w = if (dx == 0) 2 else 1
            a += ((c ushr 24) and 255) * w; r += ((c ushr 16) and 255) * w
            g += ((c ushr 8) and 255) * w; b += (c and 255) * w; weight += w
        }
        tmp[y * width + x] = ((a / weight) shl 24) or ((r / weight) shl 16) or ((g / weight) shl 8) or (b / weight)
    }
    for (y in 0 until height) for (x in 0 until width) {
        var a = 0; var r = 0; var g = 0; var b = 0; var weight = 0
        for (dy in -1..1) {
            val yy = (y + dy).coerceIn(0, height - 1)
            val c = tmp[yy * width + x]
            val w = if (dy == 0) 2 else 1
            a += ((c ushr 24) and 255) * w; r += ((c ushr 16) and 255) * w
            g += ((c ushr 8) and 255) * w; b += (c and 255) * w; weight += w
        }
        out[y * width + x] = ((a / weight) shl 24) or ((r / weight) shl 16) or ((g / weight) shl 8) or (b / weight)
    }
    return out
}

private fun sampleChannel(
    pixels: IntArray,
    width: Int,
    height: Int,
    x: Float,
    y: Float,
    shift: Int,
): Int {
    val x0 = x.toInt().coerceIn(0, width - 1)
    val y0 = y.toInt().coerceIn(0, height - 1)
    val x1 = min(width - 1, x0 + 1)
    val y1 = min(height - 1, y0 + 1)
    val fx = (x - x0).coerceIn(0f, 1f)
    val fy = (y - y0).coerceIn(0f, 1f)
    val c00 = (pixels[y0 * width + x0] ushr shift) and 255
    val c10 = (pixels[y0 * width + x1] ushr shift) and 255
    val c01 = (pixels[y1 * width + x0] ushr shift) and 255
    val c11 = (pixels[y1 * width + x1] ushr shift) and 255
    val top = c00 + (c10 - c00) * fx
    val bottom = c01 + (c11 - c01) * fx
    return (top + (bottom - top) * fy).roundToInt().coerceIn(0, 255)
}
