package com.AX

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.speech.ModelDownloadListener
import android.speech.RecognitionSupport
import android.speech.RecognitionSupportCallback
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import java.util.concurrent.Executor

/**
 * Настоящее офлайн-распознавание: on-device SpeechRecognizer (Android 14 и выше)
 * и проверка/скачивание русского пакета. На старых версиях остаётся обычное распознавание.
 */
object OfflineSpeech {
    private const val LANG = "ru-RU"
    private val main = Handler(Looper.getMainLooper())
    private val mainExecutor = Executor { r -> main.post(r) }

    /** Поддерживается ли офлайн на этом устройстве. */
    fun supported(ctx: Context): Boolean =
        Build.VERSION.SDK_INT >= 34 && SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx)

    /** Офлайн, если включено и поддерживается; иначе обычный распознаватель. */
    fun create(ctx: Context): SpeechRecognizer =
        if (Prefs.offline && supported(ctx)) SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
        else SpeechRecognizer.createSpeechRecognizer(ctx)

    /** Проверяет русский пакет и скачивает его, если его нет. Сообщения идут в журнал и на экран. */
    fun ensureRussian(ctx: Context) {
        val say: (String) -> Unit = { msg ->
            AppLog.add("INFO", "Офлайн: $msg")
            Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
        }
        if (!supported(ctx)) {
            say("Офлайн-распознавание требует Android 14 и выше")
            return
        }
        val probe = SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, LANG)
        probe.checkRecognitionSupport(intent, mainExecutor, object : RecognitionSupportCallback {
            override fun onSupportResult(support: RecognitionSupport) {
                if (support.installedOnDeviceLanguages.any { it.startsWith("ru") }) {
                    say("Русский офлайн-пакет установлен")
                    probe.destroy()
                    return
                }
                say("Скачиваю русский офлайн-пакет…")
                probe.triggerModelDownload(intent, mainExecutor, object : ModelDownloadListener {
                    override fun onProgress(completedPercent: Int) {}
                    override fun onScheduled() {}
                    override fun onSuccess() {
                        say("Русский офлайн-пакет скачан")
                        probe.destroy()
                    }
                    override fun onError(error: Int) {
                        say("Не удалось скачать пакет: код $error")
                        probe.destroy()
                    }
                })
            }

            override fun onError(error: Int) {
                say("Не удалось проверить пакет: код $error")
                probe.destroy()
            }
        })
    }
}
