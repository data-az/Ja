package com.AX

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import org.json.JSONObject
import java.io.File

/**
 * Пользовательская команда, перенесена с ПК (user_commands.json):
 * фраза → файл, папка или сайт.
 *
 * На ПК хранится путь Windows и открывается через os.startfile. На Android файл и папку
 * выбирает системный пикер, поэтому цель хранится как content:// адрес, а доступ к нему
 * сохраняется на перезапуски (takePersistableUriPermission).
 */
data class UserCommand(
    val phrase: String,
    /** file | folder | url — то же, что на ПК. */
    val type: String,
    /** content:// адрес для file/folder, либо адрес сайта для url. */
    val target: String,
    /** Понятное имя для списка: имя файла, имя папки или сам адрес сайта. */
    val name: String,
)

object UserCommands {

    private const val FILE_NAME = "user_commands.json"
    private val TYPES = setOf("file", "folder", "url")

    /** Порядок добавления сохраняется: как и на ПК, побеждает первая подходящая фраза. */
    private val items = LinkedHashMap<String, UserCommand>()
    private var loaded = false

    /** Читает команды из памяти приложения один раз. Безопасно вызывать часто. */
    @Synchronized
    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val f = File(ctx.filesDir, FILE_NAME)
        if (!f.exists()) return
        try {
            val obj = JSONObject(f.readText(Charsets.UTF_8))
            for (key in obj.keys()) {
                val v = obj.optJSONObject(key) ?: continue
                val target = v.optString("target")
                if (key.isBlank() || target.isEmpty()) continue
                val type = v.optString("type", "file").takeIf { it in TYPES } ?: "file"
                items[key] = UserCommand(key, type, target, v.optString("name", target))
            }
        } catch (e: Exception) {
            // Повреждённый файл не должен ломать запуск: просто начинаем с пустого списка.
            items.clear()
        }
    }

    @Synchronized
    fun all(): List<UserCommand> = items.values.toList()

    @Synchronized
    fun exists(phrase: String): Boolean = items.containsKey(phrase)

    /** Первая команда, фраза которой встречается в тексте (текст уже в нижнем регистре). */
    @Synchronized
    fun match(text: String): UserCommand? =
        items.values.firstOrNull { it.phrase.isNotBlank() && text.contains(it.phrase) }

    @Synchronized
    fun add(ctx: Context, cmd: UserCommand) {
        items[cmd.phrase] = cmd
        save(ctx)
    }

    @Synchronized
    fun remove(ctx: Context, phrase: String) {
        items.remove(phrase)
        save(ctx)
    }

    @Synchronized
    fun clear(ctx: Context) {
        items.clear()
        save(ctx)
    }

    private fun save(ctx: Context) {
        try {
            val obj = JSONObject()
            for ((phrase, v) in items) {
                obj.put(
                    phrase,
                    JSONObject()
                        .put("type", v.type)
                        .put("target", v.target)
                        .put("name", v.name)
                )
            }
            File(ctx.filesDir, FILE_NAME).writeText(obj.toString(2), Charsets.UTF_8)
        } catch (e: Exception) {
            AppLog.add("ERR", "Не удалось сохранить свои команды: ${e.message}")
        }
    }

    /** Открывает файл, папку или сайт из команды. Возвращает результат для строки статуса. */
    fun open(ctx: Context, cmd: UserCommand): Reply {
        return try {
            val intent = when (cmd.type) {
                "url" -> Intent(Intent.ACTION_VIEW, Uri.parse(cmd.target))
                "folder" -> Intent(Intent.ACTION_VIEW)
                    .setDataAndType(folderDocumentUri(cmd.target), DocumentsContract.Document.MIME_TYPE_DIR)
                else -> {
                    val uri = Uri.parse(cmd.target)
                    Intent(Intent.ACTION_VIEW).setDataAndType(uri, ctx.contentResolver.getType(uri) ?: "*/*")
                }
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            ctx.startActivity(intent)
            Reply(true, "Открываю ${cmd.name}")
        } catch (e: ActivityNotFoundException) {
            Reply(
                false,
                if (cmd.type == "url") "Нет браузера для этой ссылки"
                else "Нет приложения, которое откроет «${cmd.name}»"
            )
        } catch (e: SecurityException) {
            Reply(false, "Нет доступа к «${cmd.name}». Удалите команду и добавьте её заново")
        } catch (e: Exception) {
            Reply(false, "Не удалось открыть «${cmd.name}»")
        }
    }

    /** Для папки храним адрес дерева из пикера; здесь переводим его в адрес самой папки. */
    private fun folderDocumentUri(treeTarget: String): Uri {
        val tree = Uri.parse(treeTarget)
        return DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
    }
}
