package com.AX

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.view.animation.LinearInterpolator
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.AbstractComposeView
import androidx.compose.ui.platform.ComposeView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.widget.doAfterTextChanged
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private var speech: SpeechRecognizer? = null
    private lateinit var sounds: SoundPlayer
    private lateinit var reactor: ReactorView
    private lateinit var heard: TextView
    private lateinit var status: TextView
    private lateinit var chipText: TextView
    private lateinit var chipDot: View
    private lateinit var micHalo: View
    private lateinit var logText: TextView
    private lateinit var stateFiles: TextView
    private lateinit var stateAccess: TextView
    private lateinit var stateMic: TextView
    private lateinit var stateCall: TextView
    private lateinit var stateContacts: TextView
    private lateinit var pages: List<View>

    // Команды выполняются в отдельном потоке, звук — через SoundPool: они не мешают друг другу.
    private val worker = Executors.newSingleThreadExecutor()
    private var haloAnim: ObjectAnimator? = null
    private var listening = false
    private var currentPage = 0
    private var uiEditor: UiEditor? = null
    private val startT0 = android.os.SystemClock.elapsedRealtime()
    /** Замер этапа запуска: время от старта и память, которую занимает приложение. Пишется в журнал «Логи». */
    private fun stage(name: String) {
        val ms = android.os.SystemClock.elapsedRealtime() - startT0
        val rt = Runtime.getRuntime()
        val heapMb = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)
        AppLog.add("INFO", "Запуск, $name: $ms мс, память приложения $heapMb МБ")
    }
    // Общие кривые переходов: уход — ускоряется, приход — тормозит мягко.
    private val EASE_IN = android.view.animation.PathInterpolator(0.4f, 0f, 1f, 1f)
    private val EASE_OUT = android.view.animation.PathInterpolator(0.2f, 0.7f, 0.2f, 1f)
    private var composePage by mutableIntStateOf(0)
    private var composeDockVisible by mutableStateOf(true)
    private var uiInitialized = false
    /** Окно сейчас на экране. Нужен, чтобы таймер стартовал, если инициализация закончилась уже после onResume. */
    private var resumed = false

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startListening() else status.text = "Нет доступа к микрофону"
    }

    // Разрешения, которых не хватило команде (контакты, звонки): спрашиваем и повторяем команду.
    private var pendingRetry: String? = null
    private val permRequest = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val retry = pendingRetry
        pendingRetry = null
        if (retry != null && result.isNotEmpty() && result.values.all { it }) {
            runCommand(retry)
        } else {
            status.setTextColor(color(R.color.err))
            status.text = "Без разрешения команда не выполнена"
            AppLog.add("ERR", "Разрешения не выданы: ${result.filterValues { !it }.keys.joinToString()}")
        }
    }

    // Стартовый запрос разрешений: можно пропустить, тогда каждое разрешение спросится при первом использовании функции.
    private var startupStep = 0   // 0 — нет, 1 — ждём возврат из «Все файлы», 2 — из «Специальных возможностей»
    private val startupPerms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { continueStartupFlow() }

    private fun color(res: Int) = ContextCompat.getColor(this, res)

    /** Запрос разрешения из строки в настройках; после ответа обновляем статусы. */
    private val permManual = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refreshStates() }

    private fun isGranted(permission: String) =
        checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    /** Не выдано — запрашиваем; выдано — открываем настройки приложения, чтобы его можно было отозвать. */
    private fun requestOrOpenSettings(permission: String) {
        if (isGranted(permission)) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
        } else {
            permManual.launch(arrayOf(permission))
        }
    }

    private fun askPermissionsOnFirstRun() {
        if (Prefs.permsAsked) return
        Prefs.permsAsked = true
        AlertDialog.Builder(this)
            .setTitle("Разрешения для JARVIS")
            .setMessage(
                "Для всех функций нужны: микрофон, звонки, контакты, доступ ко всем файлам и служба специальных " +
                "возможностей.\n\nМожно пропустить: нужное разрешение запросится, когда вы впервые воспользуетесь функцией."
            )
            .setPositiveButton("Разрешить") { _, _ ->
                val missing = arrayOf(
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.CALL_PHONE,
                    Manifest.permission.READ_CONTACTS
                ).filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
                if (missing.isEmpty()) continueStartupFlow() else startupPerms.launch(missing.toTypedArray())
            }
            .setNegativeButton("Пропустить", null)
            .show()
    }

    private fun continueStartupFlow() {
        if (!Commands.hasAllFiles() && Build.VERSION.SDK_INT >= 30) {
            startupStep = 1
            openAllFilesSettings()
        } else {
            startupStep = 2
            openAccessibilityIfNeeded()
        }
    }

    private fun openAccessibilityIfNeeded() {
        startupStep = 0
        if (JarvisAccessibility.instance == null) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    // Системные пикеры для «Своих команд»: файл или папка. Результат передаём панели.
    private var userCommandsPanel: UserCommandsPanel? = null
    private val pickFile = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> userCommandsPanel?.onPicked(uri, "file") }
    private val pickFolder = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> userCommandsPanel?.onPicked(uri, "folder") }

    /** Функция требует особого доступа (все файлы / специальные возможности): показываем запрос сразу. */
    private fun offerSpecialAccess(text: String) {
        val files = text.startsWith("Нет доступа ко всем файлам")
        val access = text.startsWith("Включите службу")
        if (!files && !access) return
        AlertDialog.Builder(this)
            .setTitle("Нужно разрешение")
            .setMessage(if (files) "Для этой команды нужен доступ ко всем файлам." else "Для этой команды нужно включить службу «JARVIS AZ» в специальных возможностях.")
            .setPositiveButton("Открыть настройки") { _, _ ->
                if (files) openAllFilesSettings() else startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        Prefs.init(this)
        UiLayout.init(this)
        stage("старт активности")

        composePage = savedInstanceState?.getInt("page", 0) ?: 0
        // Предиктивный «назад» (targetSdk 36+) больше не вызывает onBackPressed(): используем dispatcher.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (uiEditor?.active == true) {
                    uiEditor?.exit()
                    return
                }
                if (!closeSettingsSub()) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                    isEnabled = true
                }
            }
        })

        setContentView(ComposeView(this).apply {
            // Иначе ComposeView «съедает» insets, и устаревшие View-страницы не получают отступы статус-бара/IME.
            disableInsetsConsumption()
            setContent {
                JarvisComposeHost(
                    currentPage = composePage,
                    showDock = composeDockVisible,
                    onPageSelected = ::selectComposePage,
                    onLegacyRootReady = { legacyRoot ->
                        if (!uiInitialized) {
                            legacyRoot.post {
                                if (!uiInitialized) {
                                    initializeLegacyUi(savedInstanceState)
                                    uiInitialized = true
                                    if (resumed) startStatsTicker()
                                    refreshStates()
                                    if (savedInstanceState == null) askPermissionsOnFirstRun()
                                }
                            }
                        }
                    }
                )
            }
        })
    }

    private fun initializeLegacyUi(savedInstanceState: Bundle?) {
        stage("интерфейс: начало инициализации")
        reactor = findViewById(R.id.reactor)
        heard = findViewById(R.id.heard)
        status = findViewById(R.id.status)
        chipText = findViewById(R.id.chipText)
        chipDot = findViewById(R.id.statusDot)
        micHalo = findViewById(R.id.micHalo)
        logText = findViewById(R.id.logText)
        stateFiles = findViewById(R.id.stateFiles)
        stateAccess = findViewById(R.id.stateAccess)
        stateMic = findViewById(R.id.stateMic)
        stateCall = findViewById(R.id.stateCall)
        stateContacts = findViewById(R.id.stateContacts)
        pages = listOf(
            findViewById(R.id.pageHome),
            findViewById(R.id.pageLogs),
            findViewById(R.id.pageSettings)
        )

        val nav = findViewById<GlassNavView>(R.id.nav)
        nav.visibility = View.INVISIBLE
        val navDivider = findViewById<View>(R.id.navDivider)
        val inputRow = findViewById<View>(R.id.inputRow)
        val dp = resources.displayMetrics.density
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.root)) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val imeBottom = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            val imeOn = insets.isVisible(WindowInsetsCompat.Type.ime()) || imeBottom > 0
            val onHome = currentPage == 0
            // ГЛАВНАЯ ЗАМОРОЖЕНА: клавиатура ложится поверх, а реактор, карточка, кнопки, микрофон и навигация
            // не сжимаются, не прячутся и не двигаются. Двигается только строка ввода (liftInput), и лишь
            // настолько, чтобы не оказаться под клавиатурой. Остальные вкладки (в настройках есть поля ввода)
            // по-прежнему сжимаются над клавиатурой.
            val resize = imeOn && !onHome
            v.setPadding(bars.left, bars.top, bars.right, if (resize) imeBottom else 0)
            // Стеклянная панель плавает: отступ от системной навигации — внешний margin, а не padding,
            // иначе стекло окажется внутри системной полосы.
            val navLp = nav.layoutParams as android.view.ViewGroup.MarginLayoutParams
            val navBottom = (12 * dp).toInt() + if (resize) 0 else bars.bottom
            if (navLp.bottomMargin != navBottom) {
                navLp.bottomMargin = navBottom
                nav.layoutParams = navLp
            }
            composeDockVisible = !resize
            nav.visibility = if (resize) View.GONE else View.INVISIBLE
            navDivider.visibility = View.GONE
            liftInput(inputRow, if (imeOn && onHome) v.height - imeBottom else -1, bars.top, dp)
            insets
        }

        // Кнопки громкости управляют потоком «Медиа», в котором играют звуки Джарвиса.
        volumeControlStream = android.media.AudioManager.STREAM_MUSIC
        sounds = SoundPlayer(this)
        Commands.warmUp(this)

        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            speech = SpeechRecognizer.createSpeechRecognizer(this).also {
                it.setRecognitionListener(speechListener)
            }
        } else {
            status.text = "Распознавание речи недоступно на этом устройстве"
        }

        findViewById<View>(R.id.btnMic).setOnClickListener { onMicClick() }
        SpringPress.attach(findViewById(R.id.btnMic))
        SpringPress.attach(findViewById(R.id.btnSend))
        setupTextInput()

        nav.onItemSelected = { id ->
            showPage(
                when (id) {
                    R.id.nav_logs -> 1
                    R.id.nav_settings -> 2
                    else -> 0
                }
            )
        }

        setupLogs()
        stage("интерфейс: логи готовы")

        // Редактор интерфейса: сохранённые правки применяются сразу, до первого показа.
        val editor = UiEditor(this, homeEditTargets())
        editor.install(findViewById(android.R.id.content)) { dockReservePx() }
        editor.applySaved()
        uiEditor = editor

        setupSettings()

        // Поворот экрана пересоздаёт активность: возвращаем открытую вкладку и последнюю фразу с ответом.
        savedInstanceState?.let { st ->
            st.getString("heard")?.let { heard.text = it }
            st.getString("status")?.let { status.text = it }
            when (st.getInt("page", 0)) {
                1 -> nav.selectedItemId = R.id.nav_logs
                2 -> nav.selectedItemId = R.id.nav_settings
            }
        }
        if (composePage != currentPage) {
            nav.selectedItemId = when (composePage) {
                1 -> R.id.nav_logs
                2 -> R.id.nav_settings
                else -> R.id.nav_home
            }
        }
        stage("интерфейс: инициализация закончена")
        if (savedInstanceState == null) AppLog.add("INFO", "JARVIS AZ запущен")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("page", currentPage)
        if (uiInitialized) {
            outState.putString("heard", heard.text.toString())
            outState.putString("status", status.text.toString())
        }
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        if (uiInitialized) {
            startStatsTicker()
            refreshStates()
            if (startupStep == 1) {
                startupStep = 2
                openAccessibilityIfNeeded()
            }
        }
    }

    override fun onPause() {
        resumed = false
        uiEditor?.exit()
        statsHandler.removeCallbacks(statsTick)
        speech?.cancel()
        if (uiInitialized) setListeningUi(false)
        super.onPause()
    }

    override fun onDestroy() {
        AppLog.listener = null
        haloAnim?.cancel()
        worker.shutdownNow()
        speech?.destroy()
        if (::sounds.isInitialized) sounds.release()
        super.onDestroy()
    }

    private fun selectComposePage(index: Int) {
        if (index !in 0..2) return
        if (!uiInitialized) {
            composePage = index
            return
        }
        val id = when (index) {
            1 -> R.id.nav_logs
            2 -> R.id.nav_settings
            else -> R.id.nav_home
        }
        findViewById<GlassNavView>(R.id.nav).selectedItemId = id
    }

    private fun showPage(index: Int) {
        if (index !in 0..2 || index == currentPage) return
        val previous = currentPage
        currentPage = index
        composePage = index
        if (index != 0) uiEditor?.exit()
        closeSettingsSub()
        ViewCompat.requestApplyInsets(findViewById(R.id.root))

        val direction = if (index > previous) 1f else -1f
        pages.forEachIndexed { i, page ->
            page.animate().cancel()
            if (i == index) {
                page.alpha = 0f
                page.translationX = 18f * direction * resources.displayMetrics.density
                page.scaleX = 0.992f
                page.scaleY = 0.992f
                page.visibility = View.VISIBLE
                page.animate()
                    .alpha(1f)
                    .translationX(0f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(260L)
                    .setInterpolator(android.view.animation.PathInterpolator(0.18f, 0.72f, 0.2f, 1f))
                    .start()
            } else if (i == previous) {
                page.animate()
                    .alpha(0f)
                    .translationX(-14f * direction * resources.displayMetrics.density)
                    .setDuration(150L)
                    .withEndAction {
                        page.visibility = View.GONE
                        page.alpha = 1f
                        page.translationX = 0f
                    }
                    .start()
            } else {
                page.visibility = View.GONE
                page.alpha = 1f
                page.translationX = 0f
            }
        }
    }

    /**
     * Единственное, что двигается на главной при открытой клавиатуре: строка ввода. Если клавиатура
     * ([keyboardTop] — её верх в координатах окна, -1 — закрыта) перекрыла бы строку, строка приподнимается
     * ровно над клавиатурой; всё остальное остаётся на месте. Если не перекрывает (планшет, высокий экран),
     * не двигается совсем.
     */
    private fun liftInput(row: View, keyboardTop: Int, minTop: Int, dp: Float) {
        row.post {
            row.animate().cancel()
            var lift = 0f
            if (keyboardTop >= 0) {
                val loc = IntArray(2)
                row.getLocationInWindow(loc)
                val baseTop = loc[1] - row.translationY       // позиция без подъёма
                val gap = 8 * dp
                val need = baseTop + row.height + gap - keyboardTop
                if (need > 0f) lift = minOf(need, maxOf(0f, baseTop - minTop - gap))
            }
            // Под приподнятой строкой не должны просвечивать карточка и кнопки.
            if (lift > 0f) row.setBackgroundColor(color(R.color.bg))
            row.animate().translationY(-lift + UiLayout.offsetY("inputRow")).setDuration(150)
                .withEndAction { if (row.translationY == 0f) row.background = null }
                .start()
        }
    }

    // ---------- Состояние интерфейса ----------

    private fun setChip(text: String, colorRes: Int) {
        chipText.text = text
        chipDot.backgroundTintList = ColorStateList.valueOf(color(colorRes))
    }

    private fun setListeningUi(on: Boolean) {
        listening = on
        reactor.listening = on
        if (on) {
            setChip("Слушаю", R.color.accent)
            startHalo()
        } else {
            stopHalo()
        }
    }

    private fun setBusy(on: Boolean) {
        reactor.busy = on
        if (on) setChip("Выполняю", R.color.violet) else if (!listening) setChip("Готов", R.color.ok)
    }

    private fun startHalo() {
        if (haloAnim?.isRunning == true) return
        haloAnim = ObjectAnimator.ofPropertyValuesHolder(
            micHalo,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.3f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.3f),
            PropertyValuesHolder.ofFloat(View.ALPHA, 0.9f, 0.1f)
        ).apply {
            duration = 1100
            interpolator = LinearInterpolator()
            repeatCount = ObjectAnimator.INFINITE
            start()
        }
    }

    private fun stopHalo() {
        haloAnim?.cancel()
        haloAnim = null
        micHalo.scaleX = 1f
        micHalo.scaleY = 1f
        micHalo.alpha = 0.35f
    }

    // ---------- Распознавание ----------

    private val speechListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            setListeningUi(true)
            status.setTextColor(color(R.color.dim))
            status.text = "Слушаю…"
        }

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {
            reactor.setLevel(rmsdB)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            setListeningUi(false)
            // Пока сервис возвращает текст, показываем, что работа идёт.
            setBusy(true)
            status.text = "Распознаю…"
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (!partial.isNullOrBlank()) heard.text = "«$partial»"
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            setListeningUi(false)
            setBusy(false)
            val msg = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    "Не расслышал, попробуйте ещё раз"
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    "Нет связи с сервисом распознавания"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    "Нет доступа к микрофону"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                    "Распознавание занято, повторите"
                else -> "Ошибка распознавания"
            }
            status.setTextColor(color(R.color.err))
            status.text = msg
            AppLog.add("ERR", "$msg (код $error)")
        }

        override fun onResults(results: Bundle?) {
            setListeningUi(false)
            val all = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.filter { it.isNotBlank() }.orEmpty()
            if (all.isEmpty()) {
                setBusy(false)
                return
            }
            runCommand(all.first(), all.drop(1))
        }
    }

    private fun startListening() {
        val recognizer = speech ?: run {
            status.text = "Распознавание речи недоступно на этом устройстве"
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            // WEB_SEARCH быстрее FREE_FORM на коротких командах.
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, Prefs.offline)
            // Короткая пауза тишины: распознавание заканчивается быстрее.
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 350L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 300L)
        }
        recognizer.startListening(intent)
    }

    private fun onMicClick() {
        if (listening) {
            // Повторное нажатие завершает запись сразу.
            speech?.stopListening()
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // ---------- Текстовый ввод ----------

    private fun setupTextInput() {
        val et = findViewById<EditText>(R.id.etCommand)
        fun submit() {
            val t = et.text.toString().trim()
            if (t.isEmpty()) return
            et.setText("")
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .hideSoftInputFromWindow(et.windowToken, 0)
            runCommand(t)
        }
        findViewById<View>(R.id.btnSend).setOnClickListener { submit() }
        et.setOnEditorActionListener { _, actionId, event ->
            val enter = event?.keyCode == KeyEvent.KEYCODE_ENTER && event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_SEND || enter) { submit(); true } else false
        }
    }

    // ---------- Выполнение команды ----------

    private fun runCommand(text: String, alternatives: List<String> = emptyList()) {
        heard.text = "«$text»"
        AppLog.cmd(
            "HEARD",
            if (alternatives.isEmpty()) text else "$text\n   другие варианты: ${alternatives.joinToString(" | ")}",
            text
        )
        status.setTextColor(color(R.color.dim))
        status.text = "Выполняю…"
        setBusy(true)

        // Звук играет в тот момент, когда Джарвис понял, какая это команда, и идёт фоном,
        // пока программа открывается. Нераспознанная фраза звука не даёт.
        val streamId = AtomicInteger(0)
        val soundPlayed = AtomicBoolean(false)
        val onRecognized: () -> Unit = {
            if (Prefs.soundOn && soundPlayed.compareAndSet(false, true)) {
                streamId.set(sounds.playRandom())
            }
        }

        if (worker.isShutdown) return
        worker.execute {
            val t0 = System.currentTimeMillis()
            var reply = try {
                Commands.run(this@MainActivity, text, onRecognized = onRecognized)
            } catch (e: Throwable) {
                AppLog.add("ERR", "Команда «$text»: ${e.javaClass.simpleName}: ${e.message}")
                Reply(false, "Ошибка: ${e.message}")
            }
            // Если главный вариант не сработал, пробуем остальные гипотезы распознавания (без API: ждать сеть 3 раза незачем).
            if (!reply.ok) for (alt in alternatives) {
                val r = try {
                    Commands.run(this@MainActivity, alt, useAi = false, onRecognized = onRecognized)
                } catch (e: Throwable) { continue }
                if (r.ok) { reply = r; break }
            }
            AppLog.cmd(
                if (reply.ok) "INFO" else "ERR",
                "Команда «$text» обработана за ${System.currentTimeMillis() - t0} мс: " +
                    (if (reply.ok) "успех" else "неудача") + ", вариантов распознавания ${1 + alternatives.size}" +
                    ", ИИ-поиск ${if (Prefs.supremeOn) "включён" else "выключен"}",
                "за ${System.currentTimeMillis() - t0} мс"
            )
            runOnUiThread { if (!isDestroyed) handle(reply, streamId.get()) }
        }
    }

    private fun handle(r: Reply, streamId: Int) {
        setBusy(false)
        status.setTextColor(color(if (r.ok) R.color.ok else R.color.err))
        status.text = r.text
        AppLog.cmd(if (r.ok) "OK" else "ERR", r.text)
        // Если команда не удалась, обрываем уже начавшийся звук.
        if (!r.ok) sounds.stop(streamId)
        if (!r.ok) offerSpecialAccess(r.text)
        // Команде не хватило разрешения: спрашиваем и после «Разрешить» выполняем её заново.
        if (!r.ok && r.needPerms != null && r.retry != null) {
            pendingRetry = r.retry
            permRequest.launch(r.needPerms)
        }
        if (r.exit) finishAffinity()
    }

    // ---------- Логи ----------

    // Вкладка журнала: null — «Все» (кратко), иначе один раздел (полностью).
    private var logTab: LogCat? = null

    private fun setupLogs() {
        val tabs = listOf<Pair<Int, LogCat?>>(
            R.id.tabLogAll to null,
            R.id.tabLogSound to LogCat.SOUND,
            R.id.tabLogCmd to LogCat.CMD,
            R.id.tabLogApi to LogCat.API
        )

        fun styleTabs() {
            for ((id, cat) in tabs) {
                val b = findViewById<com.google.android.material.button.MaterialButton>(id)
                val on = cat == logTab
                // Стеклянный сегмент: активная вкладка — мягкая акцентная подсветка, а не сплошная заливка
                // Заливку активного сегмента даёт скользящая пилюля под кнопками, сама кнопка прозрачна.
                b.backgroundTintList = ColorStateList.valueOf(0x00000000)
                b.setTextColor(if (on) color(R.color.text) else color(R.color.dim))
                b.strokeColor = ColorStateList.valueOf(if (on) 0x80A9D7FF.toInt() else color(R.color.glass_stroke))
            }
        }

        fun catColor(c: LogCat) = when (c) {
            LogCat.SOUND -> R.color.orange
            LogCat.CMD -> R.color.accent
            LogCat.API -> R.color.violet
        }

        fun refresh() {
            val sb = SpannableStringBuilder()
            val shown = AppLog.lines.filter { logTab == null || it.cat == logTab }
            if (shown.isEmpty()) {
                sb.append(
                    when (logTab) {
                        LogCat.SOUND -> "Звуковых событий пока нет"
                        LogCat.API -> "Запросов к API пока не было"
                        else -> "Пока пусто — скажите команду"
                    }
                )
                sb.setSpan(
                    ForegroundColorSpan(color(R.color.dim)), 0, sb.length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
            for (line in shown.asReversed()) {
                if (sb.isNotEmpty()) sb.append('\n')
                if (Prefs.logTime) {
                    val s = sb.length
                    sb.append(line.time).append("  ")
                    sb.setSpan(
                        ForegroundColorSpan(color(R.color.dim)), s, sb.length,
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
                if (logTab == null) {
                    // «Все»: метка раздела, чтобы было видно, откуда запись.
                    val s = sb.length
                    sb.append(line.cat.title).append("  ")
                    sb.setSpan(
                        ForegroundColorSpan(color(catColor(line.cat))), s, sb.length,
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                }
                val s = sb.length
                sb.append(line.level).append("  ")
                val levelColor = when (line.level) {
                    "OK" -> R.color.ok
                    "ERR" -> R.color.err
                    "HEARD" -> R.color.accent
                    "API", "SEARCH" -> R.color.violet
                    else -> R.color.dim
                }
                sb.setSpan(
                    ForegroundColorSpan(color(levelColor)), s, sb.length,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                sb.append(if (logTab == null) AppLog.briefOf(line) else line.text)
            }
            logText.text = sb
        }

        // Пилюля выбранного раздела. Едет пружиной и на миг растягивается, как у нижней панели.
        val pill = findViewById<View>(R.id.logPill)
        val tabRow = findViewById<View>(R.id.logTabsRow)
        val slideX = SpringAnimation(pill, DynamicAnimation.TRANSLATION_X).apply {
            spring = SpringForce()
                .setStiffness(420f)
                .setDampingRatio(SpringForce.DAMPING_RATIO_NO_BOUNCY)
        }
        val stretch = SpringAnimation(pill, DynamicAnimation.SCALE_X, 1f).apply {
            spring = SpringForce()
                .setStiffness(260f)
                .setDampingRatio(SpringForce.DAMPING_RATIO_NO_BOUNCY)
        }
        fun selectedTab(): View = findViewById(tabs.first { it.second == logTab }.first)

        // Ставит пилюлю точно под выбранную кнопку. [animate] = false — без движения (первая раскладка, поворот).
        fun placePill(animate: Boolean) {
            val target = selectedTab()
            if (target.width == 0) return
            if (pill.width != target.width || pill.height != target.height) {
                pill.layoutParams = android.widget.FrameLayout.LayoutParams(target.width, target.height)
            }
            if (animate && pill.width > 0) {
                pill.scaleX = 1.05f
                slideX.animateToFinalPosition(target.left.toFloat())
                stretch.animateToFinalPosition(1f)
            } else {
                slideX.cancel()
                stretch.cancel()
                pill.scaleX = 1f
                pill.translationX = target.left.toFloat()
            }
        }
        // Раскладка могла прийти позже (вкладка была скрыта): тогда и ставим пилюлю.
        tabRow.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> placePill(animate = false) }

        for ((id, cat) in tabs) {
            findViewById<View>(id).setOnClickListener {
                if (cat == logTab) return@setOnClickListener
                logTab = cat
                styleTabs()
                placePill(animate = true)
                // Список плавно гаснет и появляется заново, а не меняется скачком.
                logText.animate().cancel()
                val lift = 6f * resources.displayMetrics.density
                logText.animate().alpha(0f).translationY(lift)
                    .setDuration(160L).setInterpolator(EASE_IN)
                    .withEndAction {
                        refresh()
                        logText.translationY = -lift
                        logText.animate().alpha(1f).translationY(0f)
                            .setDuration(280L).setInterpolator(EASE_OUT).start()
                    }.start()
            }
        }
        AppLog.listener = { refresh() }
        findViewById<View>(R.id.btnClearLogs).setOnClickListener { AppLog.clear() }
        findViewById<View>(R.id.btnCopyLogs).setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("JARVIS log", logText.text))
            android.widget.Toast.makeText(this, "Лог скопирован", android.widget.Toast.LENGTH_SHORT).show()
        }
        styleTabs()
        refresh()
    }

    // ---------- Настройки ----------

    private fun setupSettings() {
        val swSound = findViewById<SwitchCompat>(R.id.swSound)
        val swOffline = findViewById<SwitchCompat>(R.id.swOffline)
        val swLog = findViewById<SwitchCompat>(R.id.swLog)
        val swLogTime = findViewById<SwitchCompat>(R.id.swLogTime)

        swSound.isChecked = Prefs.soundOn
        swOffline.isChecked = Prefs.offline
        swLog.isChecked = Prefs.logEnabled
        swLogTime.isChecked = Prefs.logTime

        swSound.setOnCheckedChangeListener { _, on -> Prefs.soundOn = on }

        val seekVolume = findViewById<android.widget.SeekBar>(R.id.seekVolume)
        seekVolume.progress = (Prefs.soundVolume * 100).toInt()
        seekVolume.setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: android.widget.SeekBar?, p: Int, fromUser: Boolean) {
                if (fromUser) Prefs.soundVolume = p / 100f
            }
            override fun onStartTrackingTouch(sb: android.widget.SeekBar?) {}
            override fun onStopTrackingTouch(sb: android.widget.SeekBar?) {
                if (Prefs.soundOn) sounds.playRandom()
            }
        })
        swOffline.setOnCheckedChangeListener { _, on -> Prefs.offline = on }
        swLog.setOnCheckedChangeListener { _, on -> Prefs.logEnabled = on }
        swLogTime.setOnCheckedChangeListener { _, on ->
            Prefs.logTime = on
            AppLog.listener?.invoke()
        }

        setupSettingsNav()
        setupInterfaceSettings()
        setupCourtSettings()
        // Списки команд и пользовательские команды строятся после первого кадра: не задерживают показ экрана.
        findViewById<View>(R.id.root).post {
            setupCommandList()
            setupUserCommands()
            stage("списки команд построены")
        }

        findViewById<View>(R.id.permMic).setOnClickListener { requestOrOpenSettings(Manifest.permission.RECORD_AUDIO) }
        findViewById<View>(R.id.permCall).setOnClickListener { requestOrOpenSettings(Manifest.permission.CALL_PHONE) }
        findViewById<View>(R.id.permContacts).setOnClickListener { requestOrOpenSettings(Manifest.permission.READ_CONTACTS) }
        findViewById<View>(R.id.btnAllFiles).setOnClickListener { openAllFilesSettings() }
        findViewById<View>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    // ---- Настройки: меню и отдельные страницы ----

    private var openSettingsSub: View? = null

    private fun setupSettingsNav() {
        val pairs = listOf(
            Triple(R.id.rowSound, R.id.subSound, R.id.btnBackSound),
            Triple(R.id.rowAi, R.id.subAi, R.id.btnBackAi),
            Triple(R.id.rowLogs, R.id.subLogs, R.id.btnBackLogs),
            Triple(R.id.rowPerm, R.id.subPerm, R.id.btnBackPerm),
            Triple(R.id.rowCmd, R.id.subCmd, R.id.btnBackCmd)
        )
        for ((row, page, back) in pairs) {
            findViewById<View>(row).setOnClickListener { openSettingsSub(findViewById(page)) }
            findViewById<View>(back).setOnClickListener { closeSettingsSub() }
        }
    }

    private fun openSettingsSub(page: View) {
        crossFade(from = findViewById(R.id.settingsMenu), to = page, forward = true)
        openSettingsSub = page
    }

    /** Возвращает меню настроек. Возвращает false, если страница и так закрыта. */
    private fun closeSettingsSub(): Boolean {
        val open = openSettingsSub ?: return false
        crossFade(from = open, to = findViewById(R.id.settingsMenu), forward = false)
        openSettingsSub = null
        return true
    }

    /**
     * Смена экрана внутри настроек: уходящий экран гаснет и чуть сдвигается, приходящий
     * проявляется со сдвигом навстречу. Сдвиг в сторону, противоположную направлению движения.
     */
    private fun crossFade(from: View, to: View, forward: Boolean) {
        val shift = 14f * resources.displayMetrics.density * (if (forward) 1f else -1f)
        from.animate().cancel()
        to.animate().cancel()
        from.animate()
            .alpha(0f)
            .translationX(-shift)
            .setDuration(170L)
            .setInterpolator(EASE_IN)
            .withEndAction {
                from.visibility = View.GONE
                from.alpha = 1f
                from.translationX = 0f
            }
            .start()
        to.alpha = 0f
        to.translationX = shift
        to.visibility = View.VISIBLE
        to.animate()
            .alpha(1f)
            .translationX(0f)
            .setDuration(300L)
            .setInterpolator(EASE_OUT)
            .start()
    }

    // ---- Интерфейс: редактор главной и сброс ----

    private fun setupInterfaceSettings() {
        findViewById<View>(R.id.rowUi).setOnClickListener {
            renderHiddenList()
            openSettingsSub(findViewById(R.id.subUi))
        }
        findViewById<View>(R.id.btnBackUi).setOnClickListener { closeSettingsSub() }
        findViewById<View>(R.id.btnEditHome).setOnClickListener {
            closeSettingsSub()
            // Переход на главную через нижнее меню: там же включится режим правки.
            findViewById<GlassNavView>(R.id.nav).selectedItemId = R.id.nav_home
            uiEditor?.enter()
        }
        findViewById<View>(R.id.btnResetUi).setOnClickListener { confirmResetUi() }
    }

    /** Список скрытых элементов в настройках. Пересобирается при каждом открытии. */
    private fun renderHiddenList() {
        val box = findViewById<LinearLayout>(R.id.hiddenList)
        box.removeAllViews()
        val hidden = uiEditor?.hiddenTargets().orEmpty()
        findViewById<View>(R.id.hiddenEmpty).visibility = if (hidden.isEmpty()) View.VISIBLE else View.GONE
        val dp = resources.displayMetrics.density
        for (t in hidden) {
            val row = TextView(this).apply {
                text = "Вернуть: ${t.title}"
                textSize = 15f
                setTextColor(color(R.color.text))
                setPadding((4 * dp).toInt(), (14 * dp).toInt(), (4 * dp).toInt(), (14 * dp).toInt())
                setBackgroundResource(android.R.drawable.list_selector_background)
                isClickable = true
                setOnClickListener {
                    uiEditor?.restore(t)
                    renderHiddenList()
                }
            }
            box.addView(row, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun confirmResetUi() {
        AlertDialog.Builder(this, R.style.Jarvis_AlertDialog)
            .setTitle("Сбросить интерфейс?")
            .setMessage("Положение, размер, цвета и скрытые элементы вернутся к исходным.")
            .setPositiveButton("Сбросить") { _, _ ->
                uiEditor?.exit()
                UiLayout.resetAll()
                // Пересоздание перерисует все элементы с исходными параметрами; открытая вкладка сохранится.
                recreate()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    /** Элементы главной, которые можно редактировать. На альбомной разметке часть элементов другая — отсутствующие пропускаются. */
    private fun homeEditTargets(): List<EditTarget> = UiEditor.HOME_ITEMS.mapNotNull { (key, title) ->
        val id = resources.getIdentifier(key, "id", packageName)
        if (id == 0) return@mapNotNull null
        findViewById<View>(id)?.let { EditTarget(key, title, it) }
    }

    /**
     * Сколько снизу занимает нижнее меню вместе с отступами: поверхность редактора не должна
     * перехватывать касания в этой зоне, иначе меню перестанет открывать настройки.
     */
    private fun dockReservePx(): Int {
        val dp = resources.displayMetrics.density
        val navBottom = ViewCompat.getRootWindowInsets(findViewById(R.id.root))
            ?.getInsets(WindowInsetsCompat.Type.navigationBars())?.bottom ?: 0
        return ((12 + 70 + 8) * dp).toInt() + navBottom
    }

    // ---- Верховный суд ----

    private fun setupCourtSettings() {
        val swCourt = findViewById<SwitchCompat>(R.id.swCourt)
        swCourt.isChecked = Prefs.supremeOn
        swCourt.setOnCheckedChangeListener { _, on -> Prefs.supremeOn = on }

        val key = findViewById<EditText>(R.id.etCourtKey)
        key.setText(Prefs.supremeKey)
        key.doAfterTextChanged { Prefs.supremeKey = it?.toString().orEmpty() }

        val model = findViewById<EditText>(R.id.etCourtModel)
        model.setText(Prefs.supremeModel)
        model.doAfterTextChanged { Prefs.supremeModel = it?.toString().orEmpty() }

        val tvKey = findViewById<TextView>(R.id.tvKeyState)
        fun keyLine() = SupremeCourt.keysSummary()
        tvKey.text = keyLine()

        // Плашки в заголовках карточек провайдеров: есть ли ключ.
        val badgeOr = findViewById<TextView>(R.id.tvBadgeOr)
        val badgeCf = findViewById<TextView>(R.id.tvBadgeCf)
        val badgeHf = findViewById<TextView>(R.id.tvBadgeHf)
        fun badge(tv: TextView, text: String, ok: Boolean) {
            tv.text = text
            tv.setTextColor(color(if (ok) R.color.ok else R.color.dim))
        }
        fun refreshBadges() {
            val orOk = Prefs.supremeKey.isNotBlank()
            badge(badgeOr, if (orOk) "ключ введён" else "нет ключа", orOk)
            val cfOk = Prefs.cfToken.isNotBlank() && Prefs.cfAccount.isNotBlank()
            badge(badgeCf, when {
                cfOk -> "ключ введён"
                Prefs.cfToken.isNotBlank() -> "нужен Account ID"
                Prefs.cfAccount.isNotBlank() -> "нужен токен"
                else -> "нет ключа"
            }, cfOk)
            val hfOk = Prefs.hfKey.isNotBlank()
            badge(badgeHf, if (hfOk) "ключ введён" else "нет ключа", hfOk)
        }
        refreshBadges()
        key.doAfterTextChanged { tvKey.text = keyLine(); refreshBadges() }

        // Режим полного ключа: поиск приложений только через API.
        val swKeyOnly = findViewById<SwitchCompat>(R.id.swKeyOnly)
        swKeyOnly.isChecked = Prefs.keyOnly
        swKeyOnly.setOnCheckedChangeListener { _, on ->
            Prefs.keyOnly = on
            AppLog.add("API", "Режим полного ключа: ${if (on) "ВКЛ (локальный поиск отключён)" else "выкл"}")
            if (on && !SupremeCourt.hasAnyKey) tvKey.text = "Введите API-ключ, иначе «открой …» не сработает"
        }

        // Cloudflare (Account ID + токен) и Hugging Face.
        fun bind(id: Int, get: () -> String, set: (String) -> Unit) {
            val et = findViewById<EditText>(id)
            et.setText(get())
            et.doAfterTextChanged {
                set(it?.toString().orEmpty())
                refreshBadges()
                tvKey.text = keyLine()
            }
        }
        bind(R.id.etCfAccount, { Prefs.cfAccount }) { Prefs.cfAccount = it }
        bind(R.id.etCfToken, { Prefs.cfToken }) { Prefs.cfToken = it }
        bind(R.id.etCfModel, { Prefs.cfModel }) { Prefs.cfModel = it }
        bind(R.id.etHfKey, { Prefs.hfKey }) { Prefs.hfKey = it }
        bind(R.id.etHfModel, { Prefs.hfModel }) { Prefs.hfModel = it }

        // Приоритет: кого спрашивать первым. Остальные с ключами остаются запасными.
        val order = listOf("auto" to "авто", "openrouter" to "OpenRouter", "cloudflare" to "Cloudflare", "huggingface" to "Hugging Face")
        val btnProvider = findViewById<com.google.android.material.button.MaterialButton>(R.id.btnProvider)
        fun providerText() = "Приоритет: " + (order.firstOrNull { it.first == Prefs.provider }?.second ?: "авто")
        btnProvider.text = providerText()
        btnProvider.setOnClickListener {
            val i = order.indexOfFirst { it.first == Prefs.provider }
            Prefs.provider = order[(i + 1) % order.size].first
            btnProvider.text = providerText()
        }

        findViewById<View>(R.id.btnKeyCheck).setOnClickListener {
            tvKey.text = "Проверяю ключи…"
            Thread {
                val r = SupremeCourt.checkKey()
                runOnUiThread { if (!isDestroyed) tvKey.text = "${SupremeCourt.keysSummary()}\n\n$r" }
            }.start()
        }
    }

    // ---- Свои команды (перенос с ПК) ----

    private fun setupUserCommands() {
        userCommandsPanel = UserCommandsPanel(
            act = this,
            container = findViewById(R.id.userCmdContainer),
            launchPick = { kind ->
                if (kind == "folder") pickFolder.launch(null) else pickFile.launch(arrayOf("*/*"))
            },
            // На ПК при добавлении команды играет звук «команда добавлена»; здесь — тот же общий звук.
            onAdded = { if (Prefs.soundOn) sounds.playRandom() },
        ).also { it.build() }
    }

    // ---- Список команд ----

    private fun setupCommandList() {
        val list = findViewById<LinearLayout>(R.id.commandList)
        val dp = resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        Commands.catalog.forEachIndexed { i, (cmd, desc) ->
            if (i > 0) {
                list.addView(View(this).apply {
                    setBackgroundColor(color(R.color.border))
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, px(1)
                    ).apply { marginStart = px(16) }
                })
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(px(16), px(12), px(16), px(12))
                isClickable = true
                isFocusable = true
                // Нажатие подставляет шаблон команды в строку ввода на главной.
                // ВАЖНО: внутри apply «this» — это строка списка, и её findViewById не видит ни строку ввода,
                // ни навигацию (возвращал null → вылет). Поэтому обращаемся к активности явно.
                setOnClickListener {
                    val et = this@MainActivity.findViewById<EditText>(R.id.etCommand)
                    val template = cmd.substringBefore(" /").substringBefore(" <").trim()
                    this@MainActivity.findViewById<GlassNavView>(R.id.nav).selectedItemId = R.id.nav_home
                    et.setText("$template ")
                    et.setSelection(et.text.length)
                    et.requestFocus()
                    (this@MainActivity.getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                        .showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
                }
            }
            row.addView(TextView(this).apply {
                text = cmd
                setTextColor(color(R.color.accent))
                textSize = 14f
            })
            row.addView(TextView(this).apply {
                text = desc
                setTextColor(color(R.color.dim))
                textSize = 12f
            })
            list.addView(row)
        }
    }

    private fun openAllFilesSettings() {
        val pkg = Uri.parse("package:$packageName")
        val intent = if (Build.VERSION.SDK_INT >= 30) {
            Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkg)
        } else {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg)
        }
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkg))
        }
    }

    // ---------- Часы и полосы состояния на главной (как на ПК) ----------

    private val statsHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val statsTick = object : Runnable {
        override fun run() {
            updateClockAndStats()
            statsHandler.postDelayed(this, 1000L)
        }
    }

    private fun startStatsTicker() {
        statsHandler.removeCallbacks(statsTick)
        statsHandler.post(statsTick)
    }

    private fun updateClockAndStats() {
        if (!uiInitialized || isDestroyed) return
        val now = java.util.Date()
        val locale = java.util.Locale.forLanguageTag("ru")
        findViewById<TextView>(R.id.clockText)?.text =
            java.text.SimpleDateFormat("HH:mm", locale).format(now)
        findViewById<TextView>(R.id.dateText)?.text =
            java.text.SimpleDateFormat("d MMMM, EEEE", locale).format(now)

        val am = getSystemService(android.media.AudioManager::class.java)
        val max = am?.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC) ?: 0
        val cur = am?.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) ?: 0
        val volPct = if (max > 0) cur * 100 / max else 0
        findViewById<android.widget.ProgressBar>(R.id.barVolume)?.progress = volPct
        findViewById<TextView>(R.id.valVolume)?.text = "$volPct%"

        val mi = android.app.ActivityManager.MemoryInfo()
        getSystemService(android.app.ActivityManager::class.java)?.getMemoryInfo(mi)
        val ramPct = if (mi.totalMem > 0) ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toInt() else 0
        findViewById<android.widget.ProgressBar>(R.id.barRam)?.progress = ramPct
        findViewById<TextView>(R.id.valRam)?.text = "$ramPct%"
    }

    private fun refreshStates() {
        fun apply(view: TextView, on: Boolean) {
            view.text = if (on) "Включено" else "Выключено"
            view.setTextColor(color(if (on) R.color.ok else R.color.dim))
        }
        apply(stateMic, isGranted(Manifest.permission.RECORD_AUDIO))
        apply(stateCall, isGranted(Manifest.permission.CALL_PHONE))
        apply(stateContacts, isGranted(Manifest.permission.READ_CONTACTS))
        apply(stateFiles, Commands.hasAllFiles())
        apply(stateAccess, JarvisAccessibility.instance != null)
    }
}

/**
 * Свойство consumeWindowInsets объявлено расширением и для AbstractComposeView (актуальное), и для ComposeView
 * (устаревшее, по умолчанию true). Вызов с receiver'ом AbstractComposeView выбирает актуальное и не даёт предупреждения.
 */
private fun AbstractComposeView.disableInsetsConsumption() {
    consumeWindowInsets = false
}
