package com.AX

import android.view.LayoutInflater
import android.view.View
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.Spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.automirrored.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.automirrored.rounded.List
import androidx.compose.ui.viewinterop.AndroidView

@Composable
fun JarvisComposeHost(
    currentPage: Int,
    showDock: Boolean,
    onPageSelected: (Int) -> Unit,
    onLegacyRootReady: (View) -> Unit,
) {
    var legacyBackgroundView by remember { mutableStateOf<View?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            factory = { context ->
                LayoutInflater.from(context)
                    .inflate(R.layout.activity_main, null, false)
                    .also { legacyRoot ->
                        legacyBackgroundView = legacyRoot
                        onLegacyRootReady(legacyRoot)
                    }
            },
            modifier = Modifier.fillMaxSize(),
            update = { /* Existing View-based screens retain their own state and listeners. */ },
        )

        AnimatedVisibility(
            visible = showDock,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(420, easing = FastOutSlowInEasing)) +
                slideInVertically(tween(480, easing = FastOutSlowInEasing)) { it / 2 },
            exit = fadeOut(tween(260, easing = FastOutSlowInEasing)) +
                slideOutVertically(tween(300, easing = FastOutSlowInEasing)) { it / 2 },
        ) {
            LiquidGlassDock(
                selectedPage = currentPage,
                onPageSelected = onPageSelected,
                backgroundView = legacyBackgroundView,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(
                        bottom = 12.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
                    ),
            )
        }
    }
}

@Composable
private fun LiquidGlassDock(
    selectedPage: Int,
    onPageSelected: (Int) -> Unit,
    backgroundView: View?,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(34.dp)

    BoxWithConstraints(
        modifier = modifier
            .height(70.dp)
            .clip(shape),
    ) {
        // Android 11-compatible CPU optical renderer samples the actual legacy screen.
        SoftwareGlassBackdrop(
            backgroundView = backgroundView,
            modifier = Modifier.fillMaxSize(),
        )

        val slotWidth = maxWidth / 5
        val density = LocalDensity.current
        val slotPx = with(density) { slotWidth.toPx() }
        val insetPx = with(density) { 5.dp.toPx() }

        // Позиция пилюли в «слотах» (0, 1, 2) — меняется плавно, с лёгким упругим перелётом.
        // Раньше был короткий ход пружиной, и пилюля выглядела так, будто прыгает. Теперь ход длиннее.
        val position = remember { Animatable(selectedPage.toFloat()) }
        LaunchedEffect(selectedPage) {
            position.animateTo(
                targetValue = selectedPage.toFloat(),
                animationSpec = spring(dampingRatio = 0.94f, stiffness = 170f),
            )
        }

        Box(
            modifier = Modifier
                .width(slotWidth - 10.dp)
                .height(60.dp)
                .align(Alignment.CenterStart)
                .graphicsLayer {
                    val p = position.value
                    // «Растяжка» в середине хода: пилюля чуть вытягивается, на остановке — круглая.
                    val frac = p - kotlin.math.floor(p)
                    val stretch = 1f - kotlin.math.abs(2f * frac - 1f)
                    translationX = p * slotPx + insetPx
                    scaleX = 1f + 0.06f * stretch
                }
                .clip(RoundedCornerShape(27.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0x4AFFFFFF), Color(0x20C7E8FF), Color(0x1AFFFFFF))
                    )
                )
                .border(1.dp, Color(0x4DFFFFFF), RoundedCornerShape(27.dp)),
        )

        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 3.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            DockItem(0, selectedPage, "Главная", Icons.Rounded.Home, onPageSelected, Modifier.weight(1f))
            DockItem(1, selectedPage, "Распознавание", Icons.Rounded.Mic, onPageSelected, Modifier.weight(1f))
            DockItem(2, selectedPage, "Команды", Icons.AutoMirrored.Rounded.List, onPageSelected, Modifier.weight(1f))
            DockItem(3, selectedPage, "Инфо", Icons.Rounded.Info, onPageSelected, Modifier.weight(1f))
            DockItem(4, selectedPage, "Настройки", Icons.Rounded.Settings, onPageSelected, Modifier.weight(1f))
        }
    }
}

@Composable
private fun DockItem(
    page: Int,
    selectedPage: Int,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onPageSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val selected = page == selectedPage
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.08f else 0.96f,
        animationSpec = spring(dampingRatio = 0.9f, stiffness = 300f),
        label = "dock-icon-scale-$page",
    )
    val alpha by animateFloatAsState(
        targetValue = if (selected) 1f else 0.62f,
        animationSpec = tween(320, easing = FastOutSlowInEasing),
        label = "dock-item-alpha-$page",
    )
    val haptics = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(28.dp))
            .clickable(
                interactionSource = interaction,
                indication = null,
            ) {
                if (!selected) {
                    haptics.performHapticFeedback(HapticFeedbackType.Confirm)
                    onPageSelected(page)
                }
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = Color.White.copy(alpha = alpha),
            modifier = Modifier
                .size(23.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                },
        )
        Text(
            text = label,
            color = Color.White.copy(alpha = alpha),
            fontSize = 9.sp,
            lineHeight = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 3.dp),
        )
    }
}
