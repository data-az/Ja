package com.AX

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibility : AccessibilityService() {

    override fun onServiceConnected() {
        Prefs.init(this)
        instance = this
        AppLog.add("INFO", "Служба доступности включена")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    /** Свайп по экрану: вверх, вниз, влево или вправо. */
    fun swipe(dir: String): Boolean {
        val dm = resources.displayMetrics
        val cx = dm.widthPixels / 2f
        val cy = dm.heightPixels / 2f
        val dx = dm.widthPixels * 0.3f
        val dy = dm.heightPixels * 0.3f
        val path = Path().apply {
            when (dir) {
                "вверх" -> { moveTo(cx, cy + dy); lineTo(cx, cy - dy) }
                "вниз" -> { moveTo(cx, cy - dy); lineTo(cx, cy + dy) }
                "влево" -> { moveTo(cx + dx, cy); lineTo(cx - dx, cy) }
                else -> { moveTo(cx - dx, cy); lineTo(cx + dx, cy) }
            }
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 250))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    /** Дописывает текст в активное поле ввода другого приложения. */
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val field = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val old = field.text?.toString().orEmpty()
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + text)
        }
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    companion object {
        @Volatile
        var instance: JarvisAccessibility? = null
    }
}