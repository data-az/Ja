package com.AX

import android.content.Context
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

/** Элемент главной, который можно редактировать: ключ хранения (он же id в XML), подпись и сам вид. */
class EditTarget(val key: String, val title: String, val view: View)

/**
 * Хранилище правок интерфейса. Отдельный файл настроек, чтобы не трогать [Prefs].
 * Всё, что здесь сохранено, применяется при каждом запуске.
 */
object UiLayout {
    private var sp: SharedPreferences? = null

    fun init(context: Context) {
        if (sp == null) sp = context.applicationContext.getSharedPreferences("ui_layout", Context.MODE_PRIVATE)
    }

    private fun prefs(): SharedPreferences = requireNotNull(sp) { "UiLayout.init не вызван" }

    fun offsetX(key: String): Float = prefs().getFloat("$key.tx", 0f)
    fun offsetY(key: String): Float = prefs().getFloat("$key.ty", 0f)
    fun scale(key: String): Float = prefs().getFloat("$key.s", 1f)
    fun color(key: String): Int? = if (prefs().contains("$key.c")) prefs().getInt("$key.c", 0) else null
    fun hidden(key: String): Boolean = prefs().getBoolean("$key.h", false)

    /** Сохраняет положение и масштаб вида. */
    fun savePlacement(t: EditTarget) {
        prefs().edit()
            .putFloat("${t.key}.tx", t.view.translationX)
            .putFloat("${t.key}.ty", t.view.translationY)
            .putFloat("${t.key}.s", t.view.scaleX)
            .apply()
    }

    fun saveColor(key: String, color: Int) = prefs().edit().putInt("$key.c", color).apply()

    fun setHidden(key: String, value: Boolean) = prefs().edit().putBoolean("$key.h", value).apply()

    fun resetAll() = prefs().edit().clear().apply()

    /** Применяет сохранённые правки к виду. */
    fun applyTo(t: EditTarget) {
        t.view.translationX = offsetX(t.key)
        t.view.translationY = offsetY(t.key)
        val s = scale(t.key)
        t.view.scaleX = s
        t.view.scaleY = s
        color(t.key)?.let { tintTree(t.view, it) }
        t.view.visibility = if (hidden(t.key)) View.GONE else View.VISIBLE
    }
}

/** Цвета на выбор. Первый — стандартный серый, как у ПК. */
private val PALETTE: List<Pair<String, Int>> = listOf(
    "Светло-серый" to 0xFFE8E8E8.toInt(),
    "Белый" to 0xFFFFFFFF.toInt(),
    "Голубой" to 0xFF8AB8FF.toInt(),
    "Зелёный" to 0xFF7DDC9A.toInt(),
    "Золотой" to 0xFFD6C28A.toInt(),
    "Красный" to 0xFFE57373.toInt(),
    "Фиолетовый" to 0xFFB39DDB.toInt(),
)

/** Перекрашивает текст, иконки, полосы и реактор внутри вида. */
internal fun tintTree(v: View, color: Int) {
    when (v) {
        is ReactorView -> { v.baseColor = color; v.invalidate() }
        is TextView -> v.setTextColor(color)
        is ProgressBar -> v.progressTintList = ColorStateList.valueOf(color)
        is ImageView -> v.imageTintList = ColorStateList.valueOf(color)
    }
    if (v is ViewGroup) for (i in 0 until v.childCount) tintTree(v.getChildAt(i), color)
}

/**
 * Режим редактирования главной.
 *
 * Пока режим включён, поверх главной лежит прозрачная поверхность [surface]: она перехватывает все касания
 * (внутренние кнопки и поля на это время не получают нажатий), а сама решает, какой элемент двигать или масштабировать.
 * Нижнее меню остаётся доступным: поверхность не закрывает его область (см. [install]).
 * Режим не сохраняется между запусками: [exit] вызывается при уходе с главной, паузе и выходе.
 */
class UiEditor(
    private val activity: android.app.Activity,
    private val targets: List<EditTarget>,
) {
    var active = false
        private set

    private val dp = activity.resources.displayMetrics.density
    private var selected: EditTarget? = null
    private var surface: EditSurface? = null
    private var bar: LinearLayout? = null
    private var barHint: TextView? = null
    private val actionButtons = ArrayList<TextView>()

    private val frame = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = 14 * dp
        setStroke((1.5f * dp).toInt(), 0xB3FFFFFF.toInt())
    }

    /** Добавляет поверхность и панель инструментов в [content] (корневой FrameLayout окна). */
    fun install(content: ViewGroup, dockReservePx: () -> Int) {
        val s = EditSurface(dockReservePx)
        s.visibility = View.GONE
        content.addView(s, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        surface = s

        val b = buildBar()
        b.visibility = View.GONE
        content.addView(b, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        ViewCompat.setOnApplyWindowInsetsListener(b) { v, insets ->
            val top = insets.getInsets(WindowInsetsCompat.Type.systemBars()).top
            v.setPadding(v.paddingLeft, top + (8 * dp).toInt(), v.paddingRight, v.paddingBottom)
            insets
        }
        ViewCompat.requestApplyInsets(b)
        bar = b
    }

    /** Применяет сохранённые правки ко всем элементам. Вызывается один раз при создании. */
    fun applySaved() {
        targets.forEach { UiLayout.applyTo(it) }
    }

    fun hiddenTargets(): List<EditTarget> = targets.filter { UiLayout.hidden(it.key) }

    /** Возвращает скрытый элемент на место. */
    fun restore(t: EditTarget) {
        UiLayout.setHidden(t.key, false)
        t.view.visibility = View.VISIBLE
    }

    fun enter() {
        if (active) return
        active = true
        surface?.visibility = View.VISIBLE
        bar?.visibility = View.VISIBLE
        refreshButtons()
    }

    fun exit() {
        if (!active) return
        active = false
        deselect()
        surface?.visibility = View.GONE
        bar?.visibility = View.GONE
    }

    // ---------- выбор и действия ----------

    private fun select(t: EditTarget?) {
        if (t === selected) return
        selected?.view?.foreground = null
        selected = t
        t?.view?.foreground = frame
        refreshButtons()
    }

    private fun deselect() = select(null)

    private fun refreshButtons() {
        val has = selected != null
        barHint?.text = if (has) "«${selected!!.title}». Перетаскивайте, двумя пальцами — размер."
        else "Перетаскивайте элементы. Нажмите на элемент, чтобы выбрать."
        actionButtons.forEach { it.alpha = if (has || it.tag == "done") 1f else 0.4f }
    }

    private fun resize(factor: Float) {
        val t = selected ?: return
        setScale(t, t.view.scaleX * factor)
        UiLayout.savePlacement(t)
    }

    private fun setScale(t: EditTarget, value: Float) {
        val s = value.coerceIn(MIN_SCALE, MAX_SCALE)
        t.view.scaleX = s
        t.view.scaleY = s
    }

    private fun pickColor(t: EditTarget) {
        AlertDialog.Builder(activity, R.style.Jarvis_AlertDialog)
            .setTitle("Цвет: ${t.title}")
            .setItems(PALETTE.map { it.first }.toTypedArray()) { _, which ->
                val c = PALETTE[which].second
                UiLayout.saveColor(t.key, c)
                tintTree(t.view, c)
            }
            .show()
    }

    private fun hideSelected() {
        val t = selected ?: return
        UiLayout.setHidden(t.key, true)
        deselect()
        t.view.visibility = View.GONE
    }

    /** Ищет элемент под точкой (координаты экрана) с учётом сдвига и масштаба. */
    private fun targetAt(x: Float, y: Float): EditTarget? = targets.asReversed().firstOrNull { t ->
        val v = t.view
        if (v.visibility != View.VISIBLE || v.width == 0) return@firstOrNull false
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        x >= loc[0] && x <= loc[0] + v.width * v.scaleX &&
            y >= loc[1] && y <= loc[1] + v.height * v.scaleY
    }

    // ---------- панель инструментов ----------

    private fun buildBar(): LinearLayout {
        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xE60E0E0F.toInt())
            isClickable = true
            setPadding((12 * dp).toInt(), 0, (12 * dp).toInt(), (10 * dp).toInt())
        }
        val hint = TextView(activity).apply {
            textSize = 13f
            setTextColor(activity.getColor(R.color.dim))
            gravity = Gravity.CENTER
            setPadding(0, (4 * dp).toInt(), 0, (10 * dp).toInt())
        }
        barHint = hint
        root.addView(hint)

        val row = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        // Кнопки: подпись, метка, действие. «Готово» работает всегда, остальные — только при выбранном элементе.
        val buttons: List<Triple<String, String, () -> Unit>> = listOf(
            Triple("Меньше", "smaller", { resize(1f / 1.12f) }),
            Triple("Больше", "bigger", { resize(1.12f) }),
            Triple("Цвет", "color", { selected?.let { pickColor(it) } }),
            Triple("Скрыть", "hide", { hideSelected() }),
            Triple("Готово", "done", { exit() }),
        )
        for ((label, tagName, action) in buttons) {
            val b = TextView(activity).apply {
                text = label
                tag = tagName
                textSize = 13f
                gravity = Gravity.CENTER
                setTextColor(activity.getColor(R.color.text))
                setBackgroundResource(R.drawable.chip)
                setPadding((10 * dp).toInt(), (8 * dp).toInt(), (10 * dp).toInt(), (8 * dp).toInt())
                isClickable = true
                setOnClickListener {
                    if (selected != null || tagName == "done") action()
                }
            }
            actionButtons += b
            row.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = (3 * dp).toInt()
                marginEnd = (3 * dp).toInt()
            })
        }
        root.addView(row)
        return root
    }

    // ---------- касания ----------

    /**
     * Прозрачная поверхность. Перехватывает все касания, пока режим включён.
     * Нижнее меню закрыто от неё отступом снизу (см. [install]).
     */
    private inner class EditSurface(private val dockReservePx: () -> Int) : FrameLayout(activity) {
        private var lastRawX = 0f
        private var lastRawY = 0f

        private val scaleDetector = ScaleGestureDetector(
            activity,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(d: ScaleGestureDetector): Boolean {
                    val t = selected ?: return false
                    setScale(t, t.view.scaleX * d.scaleFactor)
                    return true
                }

                override fun onScaleEnd(d: ScaleGestureDetector) {
                    selected?.let { UiLayout.savePlacement(it) }
                }
            },
        )

        init {
            isClickable = true
        }

        override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = true

        override fun onTouchEvent(e: MotionEvent): Boolean {
            scaleDetector.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    lastRawX = e.rawX
                    lastRawY = e.rawY
                    select(targetAt(e.rawX, e.rawY))
                }
                MotionEvent.ACTION_MOVE -> {
                    val t = selected
                    if (t != null && e.pointerCount == 1 && !scaleDetector.isInProgress) {
                        t.view.translationX += e.rawX - lastRawX
                        t.view.translationY += e.rawY - lastRawY
                    }
                    lastRawX = e.rawX
                    lastRawY = e.rawY
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    selected?.let { UiLayout.savePlacement(it) }
                }
            }
            return true
        }

        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            // Касания в зоне нижнего меню не забираем: меню должно открывать настройки даже в режиме правки.
            val fromBottom = height - ev.y
            if (ev.actionMasked == MotionEvent.ACTION_DOWN && fromBottom < dockReservePx()) return false
            return super.dispatchTouchEvent(ev)
        }
    }

    companion object {
        private const val MIN_SCALE = 0.5f
        private const val MAX_SCALE = 2.0f

        /** Элементы главной по id из page_home.xml. Порядок — порядок в списке скрытых. */
        val HOME_ITEMS: List<Pair<String, String>> = listOf(
            "headerRow" to "Шапка",
            "barsBlock" to "Громкость и память",
            "greeting" to "Приветствие",
            "hint" to "Подсказка",
            "reactor" to "Реактор",
            "heard" to "Вы сказали",
            "statusRow" to "Статус и часы",
            "inputRow" to "Строка ввода",
            "micFrame" to "Микрофон",
        )
    }
}
