package com.AX

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.util.Locale

object Commands {

    private val root: File get() = Environment.getExternalStorageDirectory()
    private val noAccess = Reply(false, "Нет доступа ко всем файлам. Разрешите в Настройках приложения")

    private fun arg(cmd: String, vararg prefixes: String): String? =
        prefixes.firstOrNull { cmd.startsWith(it) }?.let { cmd.removePrefix(it).trim() }

    /** Слова-команды запуска приложений. Без одного из них первым словом приложение НЕ открывается. */
    private val APP_TRIGGERS = setOf("открой", "запусти", "старт")

    /** Слова, которые можно сказать перед командой: «Джарвис, пожалуйста, открой …». */
    private val LEADING_FILLERS = setOf("джарвис", "пожалуйста")

    /**
     * Возвращает название приложения, если фраза начинается с команды [APP_TRIGGERS]
     * (после необязательных «джарвис»/«пожалуйста»). Иначе null: фраза не адресована ассистенту.
     * Пример: «открой телеграм» -> «телеграм»; «телеграм» -> null; «скажи другу открой» -> null.
     */
    private fun appQuery(c: String): String? {
        val words = c.split(Regex("[^\\p{L}\\p{N}.+-]+")).filter { it.isNotEmpty() }
        var i = 0
        while (i < words.size && words[i] in LEADING_FILLERS) i++
        if (i >= words.size || words[i] !in APP_TRIGGERS) return null
        return words.drop(i + 1).joinToString(" ")
    }

    /** Справочник команд для экрана «Настройки → Команды»: (что сказать/написать, что произойдёт). */
    val catalog: List<Pair<String, String>> = listOf(
        "открой / запусти / старт <приложение>" to "Запуск приложения: «открой телеграм»",
        "открой папку <имя>" to "Ищет папку по всему хранилищу и открывает в «Файлах»",
        "открой папку <А> в папке <Б>" to "Ищет папку А во всех папках с именем Б",
        "создай папку <имя>" to "Создать папку в хранилище",
        "создай файл <имя>" to "Создать пустой .txt файл",
        "найди папку <имя>" to "То же, что «открой папку»",
        "открой сайт <адрес>" to "Сайт или поиск Google",
        "позвони <имя контакта>" to "Звонок по имени: «позвони маме», «позвони Ивану Петрову»",
        "позвони <номер>" to "Звонок по номеру цифрами",
        "напиши <текст> в телеграм" to "Текст уходит в Telegram, чат выбираете вы",
        "включи / выключи фонарик" to "Вспышка камеры",
        "wi-fi" to "Настройки Wi-Fi",
        "точка доступа" to "Настройки точки доступа",
        "интернет" to "Настройки мобильного интернета",
        "скриншот" to "Снимок экрана (служба доступности)",
        "выключи телефон" to "Меню питания (служба доступности)",
        "голос ниже / голос выше" to "Тональность голоса ±0.1",
        "сбрось тональность" to "Вернуть тональность голоса 1.0",
        "стоп / выход" to "Закрыть JARVIS"
    )

    /** [useAi] = false: без обращения к API (для запасных гипотез распознавания, чтобы не ждать сеть по 3 раза). */
    private val CALL_TRIGGERS = arrayOf("позвонить", "позвони", "звони", "набери", "вызови")

    /**
     * Разбирает фразу и выполняет команду.
     * [onRecognized] вызывается в момент, когда Джарвис понял, какая это команда (до выполнения),
     * чтобы звук играл фоном, пока программа открывается.
     */
    fun run(ctx: Context, raw: String, useAi: Boolean = true, onRecognized: () -> Unit = {}): Reply {
        var c = raw.lowercase(Locale.getDefault()).trim()
        // «Джарвис, пожалуйста, открой …»: вежливые слова в начале не мешают разбору команды.
        while (c.contains(' ') && c.substringBefore(' ').trim(',', '.', '!') in LEADING_FILLERS) {
            c = c.substringAfter(' ').trim()
        }
        // Команда распознана: сигналим один раз и выполняем.
        fun hit(block: () -> Reply): Reply {
            onRecognized()
            return block()
        }

        UserCommands.load(ctx)

        if (c == "стоп" || c.contains("выход")) return Reply(true, "Закрываю JARVIS", exit = true)

        arg(c, "открой папку", "открыть папку", "найди папку", "найти папку", "поиск папки")
            ?.let { return hit { openFolder(ctx, it) } }
        arg(c, "создай папку")?.let { return hit { createFolder(it) } }
        arg(c, "создай текстовый файл", "создай файл")?.let { return hit { createTextFile(it) } }
        arg(c, "открой сайт", "открыть сайт")?.let { return hit { openSite(ctx, it) } }
        arg(c, *CALL_TRIGGERS)?.let { return hit { call(ctx, it, raw) } }
        if (c.startsWith("напиши") && c.contains("телеграм")) return hit { telegram(ctx, raw) }
        if (c.contains("фонарик")) return hit { torch(ctx, !c.contains("выключ")) }
        if (c.contains("wi-fi") || c.contains("wifi") || c.contains("вай фай") || c.contains("вайфай"))
            return hit { settings(ctx, Settings.ACTION_WIFI_SETTINGS, "Настройки Wi-Fi") }
        if (c.contains("точк") && c.contains("доступ"))
            return hit { settings(ctx, Settings.ACTION_WIRELESS_SETTINGS, "Точка доступа") }
        // «интернет» без команды запуска — настройки мобильных данных. А «открой интернет» — это приложение
        // (браузер), его раньше перехватывала эта строка и приложения до поиска не доходили.
        if (c == "интернет" || c.contains("мобильный интернет") || c.contains("мобильные данные"))
            return hit { settings(ctx, Settings.ACTION_DATA_ROAMING_SETTINGS, "Мобильный интернет") }
        // Только ЯВНЫЕ формулировки: голое слово «снимок» (как в «открой фотоснимок») скриншотом не является.
        if (c.contains("скриншот") || c.contains("снимок экрана") || c.contains("сними экран") || c == "скрин")
            return hit { global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, "Скриншот сделан") }
        if (c.contains("выключи телефон") || c.contains("выключить телефон"))
            return hit {
                global(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG,
                    "Открыл меню питания: выберите «Выключить» сами")
            }

        // Свои команды (как на ПК): проверяются раньше поиска приложений, поэтому фраза из настроек побеждает.
        UserCommands.match(c)?.let { cmd -> return hit { UserCommands.open(ctx, cmd) } }

        // Приложения открываем ТОЛЬКО по команде «открой / запусти / старт».
        appQuery(c)?.let { return hit { openApp(ctx, it, useAi) } }

        return Reply(false, "Не понял команду: $raw")
    }

    fun hasAllFiles() = Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()

    /**
     * «открой папку А», «открой папку А в папке Б»: ищет по всему хранилищу (см. [FolderSearch]).
     * Если папок с таким именем несколько, открывает самую вероятную и называет остальные.
     */
    private fun openFolder(ctx: Context, text: String): Reply {
        if (!hasAllFiles()) return noAccess
        if (text.isBlank()) return openInFiles(ctx, root)
        val chain = FolderSearch.parseChain(text)
        if (chain.isEmpty()) return Reply(false, "Назовите папку")

        // Быстрый путь: точное имя прямо в корне («открой папку Download»), без обхода дерева.
        if (chain.size == 1) {
            val direct = File(root, chain[0])
            if (direct.isDirectory) return openInFiles(ctx, direct)
        }

        val res = FolderSearch.find(chain)
        val label = chain.joinToString(" в ")
        if (res.hits.isEmpty()) {
            val tail = if (res.timedOut) " (поиск прерван по времени, просмотрено ${res.scanned} папок)" else ""
            return Reply(false, "Папка «$label» не найдена$tail")
        }
        val best = res.hits.first()
        val r = openInFiles(ctx, best.dir)
        val shortPath = best.dir.absolutePath.removePrefix(root.absolutePath).ifEmpty { "/" }
        val others = res.hits.size - 1
        val more = if (others > 0) ". Ещё совпадений: $others" else ""
        if (others > 0) {
            AppLog.add("SEARCH", "Папка «$label»: " + res.hits.take(6).joinToString("; ") {
                it.dir.absolutePath.removePrefix(root.absolutePath)
            })
        }
        return r.copy(text = "${r.text} ($shortPath)$more")
    }

    private fun openInFiles(ctx: Context, dir: File): Reply {
        // Внутренняя память — том «primary», SD-карта — том с её идентификатором (/storage/XXXX-XXXX).
        val path = dir.absolutePath
        val docId = if (path.startsWith(root.absolutePath)) {
            "primary:" + path.removePrefix(root.absolutePath).trim('/')
        } else {
            val rest = path.removePrefix("/storage/")
            rest.substringBefore('/') + ":" + rest.substringAfter('/', "")
        }
        val uri = DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", docId)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, DocumentsContract.Document.MIME_TYPE_DIR)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent)
            Reply(true, "Открываю ${dir.name.ifEmpty { "хранилище" }}")
        } catch (e: Exception) {
            Reply(false, "Нет приложения-проводника. Установите «Файлы» или откройте их вручную")
        }
    }

    private fun createFolder(name: String): Reply {
        if (!hasAllFiles()) return noAccess
        if (name.isBlank()) return Reply(false, "Назовите папку")
        val dir = File(root, name)
        FolderSearch.invalidate()
        return if (dir.exists() || dir.mkdirs()) Reply(true, "Папка «$name» создана")
        else Reply(false, "Не удалось создать папку")
    }

    private fun createTextFile(name: String): Reply {
        if (!hasAllFiles()) return noAccess
        if (name.isBlank()) return Reply(false, "Назовите файл")
        val file = File(root, name.replace(Regex("[\\\\/:*?\"<>|]"), "_") + ".txt")
        return try {
            if (!file.exists()) file.createNewFile()
            Reply(true, "Файл ${file.name} создан")
        } catch (e: Exception) {
            Reply(false, "Ошибка создания файла: ${e.message}")
        }
    }

    private fun openSite(ctx: Context, site: String): Reply {
        val url = when {
            site.startsWith("http") -> site
            site.contains(".") -> "https://${site.replace(" ", "")}"
            else -> "https://www.google.com/search?q=${Uri.encode(site)}"
        }
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Reply(true, "Открываю $site")
        } catch (e: Exception) {
            Reply(false, "Не удалось открыть сайт")
        }
    }

    private val CALL_PERMS = arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)

    private fun granted(ctx: Context, perm: String) =
        ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED

    /**
     * «позвони маме» / «позвони Ивану Петрову» — по имени из контактов;
     * «позвони 89001234567» — по номеру цифрами (как раньше).
     */
    private fun call(ctx: Context, rest: String, raw: String): Reply {
        val typedNumber = rest.filter { it.isDigit() || it == '+' }
        val digitCount = typedNumber.count { it.isDigit() }
        val isNumber = digitCount >= 5 || (digitCount >= 3 && rest.none { it.isLetter() })
        val needed = if (isNumber) arrayOf(Manifest.permission.CALL_PHONE) else CALL_PERMS
        val missing = needed.filter { !granted(ctx, it) }
        if (missing.isNotEmpty()) {
            return Reply(false, "Нужно разрешение: ${if (isNumber) "звонки" else "контакты и звонки"}",
                needPerms = missing.toTypedArray(), retry = raw)
        }
        if (isNumber) return dial(ctx, typedNumber, typedNumber)

        val spoken = ContactSearch.spokenName(rest)
        if (spoken.isEmpty()) return Reply(false, "Кому позвонить? Назовите имя контакта")
        val contacts = ContactSearch.load(ctx)
        if (contacts.isEmpty()) return Reply(false, "В контактах нет номеров")
        val matches = ContactSearch.find(contacts, spoken)
        if (matches.isEmpty()) return Reply(false, "Контакт «$spoken» не найден")

        val top = matches[0]
        // Двое почти одинаково подходят («Иван Петров» и «Иван Сидоров»): не гадаем, кому звонить.
        val rival = matches.drop(1).firstOrNull { it.contact.id != top.contact.id }
        if (rival != null && top.score < 0.97f && top.score - rival.score < 0.06f) {
            val names = matches.filter { top.score - it.score < 0.06f }.take(3).joinToString(" или ") { it.contact.name }
            AppLog.add("SEARCH", "Контакты «$spoken»: неоднозначно — $names")
            return Reply(false, "Уточните, $names")
        }
        val number = ContactSearch.pickNumber(top.contact)
            ?: return Reply(false, "У контакта ${top.contact.name} нет номера")
        AppLog.add("SEARCH", "«$spoken» → ${top.contact.name} (${"%.2f".format(Locale.US, top.score)})")
        return dial(ctx, number, top.contact.name)
    }

    private fun dial(ctx: Context, number: String, who: String): Reply {
        return try {
            ctx.startActivity(
                Intent(Intent.ACTION_CALL, Uri.fromParts("tel", number, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            Reply(true, "Звоню $who")
        } catch (e: SecurityException) {
            Reply(false, "Нет разрешения на звонки")
        } catch (e: Exception) {
            Reply(false, "Не удалось позвонить: ${e.message}")
        }
    }

    /** «напиши привет в телеграм»: текст уходит в Telegram, чат выбираете вы. */
    private fun telegram(ctx: Context, raw: String): Reply {
        val body = raw
            .replace(Regex("^напиши\\s*", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\s+в\\s+(телеграм\\w*|telegram)\\s*$", RegexOption.IGNORE_CASE), "")
            .trim()
        if (body.isEmpty()) return Reply(false, "Что написать?")
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, body)
            setPackage("org.telegram.messenger")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            ctx.startActivity(intent)
            Reply(true, "Telegram: выберите чат, текст уже готов")
        } catch (e: Exception) {
            Reply(false, "Telegram не установлен")
        }
    }

    private fun torch(ctx: Context, on: Boolean): Reply {
        return try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return Reply(false, "Фонарик не найден")
            cm.setTorchMode(id, on)
            Reply(true, if (on) "Фонарик включён" else "Фонарик выключен")
        } catch (e: Exception) {
            Reply(false, "Ошибка фонарика: ${e.message}")
        }
    }

    private fun settings(ctx: Context, action: String, text: String): Reply = try {
        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        Reply(true, text)
    } catch (e: Exception) {
        Reply(false, "Не удалось открыть: $text")
    }

    private fun global(action: Int, text: String): Reply {
        val svc = JarvisAccessibility.instance
            ?: return Reply(false, "Включите службу «JARVIS AZ» в настройках доступности")
        return if (svc.performGlobalAction(action)) Reply(true, text)
        else Reply(false, "Система отказала в действии")
    }

    /** Поисковый движок приложений. Системные триггеры в [run] проверяются раньше него. */
    val engine = SmartAppSearchEngine()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Заранее индексирует приложения (в Dispatchers.Default), чтобы «открой/запусти/старт …» не тормозило. */
    fun warmUp(ctx: Context) {
        val app = ctx.applicationContext
        engine.attach(app)
        scope.launch { engine.buildIndex(loadApps(app)) }
    }

    private fun loadApps(ctx: Context): List<AppInfo> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0).map {
            val f = it.activityInfo.applicationInfo.flags
            // Системное = прошивочное и НЕ обновлённое из магазина (обновлённый YouTube/Chrome считаем пользовательским).
            val system = (f and ApplicationInfo.FLAG_SYSTEM) != 0 && (f and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, system)
        }
        // Системные пакеты без иконки в лаунчере (установщик пакетов и т.п.) тоже попадают в индекс.
        val known = apps.mapTo(HashSet()) { it.pkg }
        return apps + engine.systemApps(pm).filter { it.pkg !in known }
    }

    private fun openApp(ctx: Context, query: String, useAi: Boolean = true): Reply {
        if (query.isBlank()) return Reply(false, "Какое приложение открыть?")
        if (Prefs.keyOnly && !SupremeCourt.hasAnyKey)
            return Reply(false, "Режим полного ключа: введите API-ключ в Настройках")
        engine.attach(ctx)
        if (!engine.isReady) engine.indexAppsBlocking(loadApps(ctx))
        // Команда выполняется в рабочем потоке; каскад (пользовательские → системные → «Верховный суд») ждём здесь.
        val hit = runBlocking { engine.search(query, useAi) }
        if (hit == null) {
            val why = SupremeCourt.lastError
            return if (Prefs.keyOnly && useAi && why != null) Reply(false, "Верховный суд: $why")
            else Reply(false, "Приложение «$query» не найдено")
        }
        return launch(ctx, hit.app)
    }

    private fun launch(ctx: Context, app: AppInfo): Reply {
        return if (engine.launchPackage(ctx, app.pkg, app.cls)) Reply(true, "Открываю ${app.label}")
        else Reply(false, "У «${app.label}» нет экрана запуска")
    }
}
