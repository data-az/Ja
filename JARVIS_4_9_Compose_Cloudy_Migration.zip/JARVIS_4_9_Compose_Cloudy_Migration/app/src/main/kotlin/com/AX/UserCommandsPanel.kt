package com.AX

import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Блок «Свои команды» в Настройках → Команды. Перенос с ПК: тип (файл/папка/сайт),
 * фраза, выбор через системный пикер, список с удалением и кнопка «Очистить всё».
 *
 * [launchPick] открывает системный пикер для "file" или "folder"; результат приходит в [onPicked].
 * [onAdded] вызывается после добавления (на ПК в этот момент играет звук «команда добавлена»).
 */
class UserCommandsPanel(
    private val act: MainActivity,
    private val container: LinearLayout,
    private val launchPick: (kind: String) -> Unit,
    private val onAdded: () -> Unit,
) {
    private val dp = act.resources.displayMetrics.density
    private fun px(v: Int) = (v * dp).roundToInt()
    private fun color(res: Int) = ContextCompat.getColor(act, res)

    /** Выбранный тип для новой команды: file | folder | url. */
    private var kind = "file"
    private var pickedTarget = ""
    private var pickedName = ""

    private lateinit var phraseInput: EditText
    private lateinit var urlInput: EditText
    private lateinit var typeFile: MaterialButton
    private lateinit var typeFolder: MaterialButton
    private lateinit var typeUrl: MaterialButton
    private lateinit var pickButton: MaterialButton
    private lateinit var pickedLabel: TextView
    private lateinit var listBox: LinearLayout
    private lateinit var counter: TextView
    private lateinit var clearButton: MaterialButton

    fun build() {
        container.removeAllViews()
        container.setPadding(px(16), px(16), px(16), px(16))

        // Тип команды: три переключателя в стиле вкладок логов.
        val typeRow = LinearLayout(act).apply { orientation = LinearLayout.HORIZONTAL }
        typeFile = segment("Файл") { selectKind("file") }
        typeFolder = segment("Папка") { selectKind("folder") }
        typeUrl = segment("Сайт") { selectKind("url") }
        listOf(typeFile, typeFolder, typeUrl).forEachIndexed { i, b ->
            typeRow.addView(b, LinearLayout.LayoutParams(0, px(40), 1f).apply {
                if (i > 0) marginStart = px(6)
            })
        }
        container.addView(typeRow, matchWrap())

        phraseInput = EditText(act).apply {
            hint = "Фраза, например «мой проект»"
            background = ContextCompat.getDrawable(act, R.drawable.input)
            setTextColor(color(R.color.text))
            setHintTextColor(color(R.color.dim))
            textSize = 14f
            setSingleLine(true)
            setPadding(px(18), 0, px(18), 0)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        }
        container.addView(phraseInput, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(48))
            .apply { topMargin = px(12) })

        urlInput = EditText(act).apply {
            hint = "Адрес сайта, например youtube.com"
            background = ContextCompat.getDrawable(act, R.drawable.input)
            setTextColor(color(R.color.text))
            setHintTextColor(color(R.color.dim))
            textSize = 14f
            setSingleLine(true)
            setPadding(px(18), 0, px(18), 0)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        container.addView(urlInput, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(48))
            .apply { topMargin = px(8) })

        // Выбор файла/папки и показ того, что выбрано.
        pickButton = outlined("Выбрать файл") { launchPick(kind) }
        container.addView(pickButton, matchWrap().apply { topMargin = px(8) })

        pickedLabel = TextView(act).apply {
            setTextColor(color(R.color.dim))
            textSize = 12f
            setPadding(px(4), px(6), px(4), 0)
        }
        container.addView(pickedLabel, matchWrap())

        val addButton = MaterialButton(act).apply {
            text = "Добавить команду"
            setTextColor(color(R.color.text))
            cornerRadius = px(20)
            backgroundTintList = android.content.res.ColorStateList.valueOf(0x383D9BFF)
            strokeColor = android.content.res.ColorStateList.valueOf(0x80A9D7FF.toInt())
            strokeWidth = px(1)
            textSize = 13f
            setOnClickListener { add() }
        }
        container.addView(addButton, matchWrap().apply { topMargin = px(12) })

        // Счётчик и «Очистить всё».
        val footer = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        counter = TextView(act).apply {
            setTextColor(color(R.color.dim))
            textSize = 12f
        }
        footer.addView(counter, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        clearButton = outlined("Очистить всё") { confirmClearAll() }
        footer.addView(clearButton, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, px(36)))
        container.addView(footer, matchWrap().apply { topMargin = px(14) })

        listBox = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        container.addView(listBox, matchWrap().apply { topMargin = px(8) })

        selectKind("file")
        refresh()
    }

    /** Результат системного пикера: сохраняем доступ и запоминаем имя для списка. */
    fun onPicked(uri: Uri?, pickedKind: String) {
        if (uri == null) return
        // Доступ переживёт перезапуск приложения, иначе сохранённая команда перестанет открываться.
        runCatching {
            act.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        kind = pickedKind
        pickedTarget = uri.toString()
        pickedName = if (pickedKind == "folder") folderName(uri) else fileName(uri)
        showPicked()
    }

    private fun selectKind(k: String) {
        if (kind != k) {
            // Смена типа сбрасывает выбор: файл не подходит для папки и наоборот.
            pickedTarget = ""
            pickedName = ""
        }
        kind = k
        styleSegments()
        val isUrl = k == "url"
        urlInput.visibility = if (isUrl) View.VISIBLE else View.GONE
        pickButton.visibility = if (isUrl) View.GONE else View.VISIBLE
        pickedLabel.visibility = if (isUrl) View.GONE else View.VISIBLE
        pickButton.text = if (k == "folder") "Выбрать папку" else "Выбрать файл"
        showPicked()
    }

    private fun showPicked() {
        pickedLabel.text = when {
            pickedTarget.isEmpty() -> if (kind == "folder") "Папка не выбрана" else "Файл не выбран"
            else -> "Выбрано: $pickedName"
        }
    }

    private fun styleSegments() {
        val map = mapOf("file" to typeFile, "folder" to typeFolder, "url" to typeUrl)
        map.forEach { (k, b) ->
            val on = k == kind
            b.backgroundTintList = android.content.res.ColorStateList.valueOf(if (on) 0x383D9BFF else 0x00000000)
            b.setTextColor(if (on) color(R.color.text) else color(R.color.dim))
            b.strokeColor = android.content.res.ColorStateList.valueOf(
                if (on) 0x80A9D7FF.toInt() else color(R.color.glass_stroke)
            )
        }
    }

    private fun add() {
        val phrase = phraseInput.text.toString().trim()
            .lowercase(Locale.getDefault())
            .replace(Regex("\\s+"), " ")
        if (phrase.isEmpty()) return toast("Введите фразу команды")

        val cmd = if (kind == "url") {
            var url = urlInput.text.toString().trim()
            if (url.isEmpty()) return toast("Введите адрес сайта")
            if (!url.startsWith("http://", ignoreCase = true) && !url.startsWith("https://", ignoreCase = true)) {
                url = "https://$url"
            }
            UserCommand(phrase, "url", url, url)
        } else {
            if (pickedTarget.isEmpty()) {
                return toast(if (kind == "folder") "Выберите папку для команды" else "Выберите файл для команды")
            }
            UserCommand(phrase, kind, pickedTarget, pickedName)
        }

        if (UserCommands.exists(phrase)) {
            AlertDialog.Builder(act)
                .setTitle("Команда существует")
                .setMessage("Команда «$phrase» уже есть. Заменить?")
                .setPositiveButton("Заменить") { _, _ -> commit(cmd) }
                .setNegativeButton("Отмена", null)
                .show()
        } else {
            commit(cmd)
        }
    }

    private fun commit(cmd: UserCommand) {
        UserCommands.add(act, cmd)
        phraseInput.text?.clear()
        urlInput.text?.clear()
        pickedTarget = ""
        pickedName = ""
        showPicked()
        refresh()
        onAdded()
    }

    fun refresh() {
        val all = UserCommands.all()
        counter.text = "Всего: ${all.size}"
        clearButton.isEnabled = all.isNotEmpty()
        clearButton.alpha = if (all.isNotEmpty()) 1f else 0.4f
        listBox.removeAllViews()

        if (all.isEmpty()) {
            listBox.addView(TextView(act).apply {
                text = "Пока нет. Добавьте команду выше: например, «мой проект» → папка."
                setTextColor(color(R.color.dim))
                textSize = 12f
                setPadding(px(4), px(8), px(4), px(4))
            }, matchWrap())
            return
        }

        all.forEachIndexed { i, cmd ->
            if (i > 0) {
                listBox.addView(View(act).apply {
                    setBackgroundColor(color(R.color.border))
                }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, px(1)).apply {
                    topMargin = px(4); bottomMargin = px(4)
                })
            }
            listBox.addView(TextView(act).apply {
                isClickable = true
                isFocusable = true
                setPadding(px(4), px(10), px(4), px(10))
                text = "${cmd.phrase} → ${label(cmd)}"
                setTextColor(color(R.color.text))
                textSize = 14f
                setOnClickListener { confirmDelete(cmd) }
            }, matchWrap())
        }
    }

    private fun label(cmd: UserCommand): String = when (cmd.type) {
        "url" -> "сайт: ${cmd.target}"
        "folder" -> "папка: ${cmd.name}"
        else -> cmd.name
    }

    private fun confirmDelete(cmd: UserCommand) {
        AlertDialog.Builder(act)
            .setTitle("Удалить команду?")
            .setMessage("«${cmd.phrase}» → ${label(cmd)}")
            .setPositiveButton("Удалить") { _, _ ->
                UserCommands.remove(act, cmd.phrase)
                refresh()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun confirmClearAll() {
        if (UserCommands.all().isEmpty()) return
        AlertDialog.Builder(act)
            .setTitle("Очистка всех команд")
            .setMessage("Удалить ВСЕ свои команды?")
            .setPositiveButton("Удалить") { _, _ ->
                UserCommands.clear(act)
                refresh()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun segment(text: String, onClick: () -> Unit) = MaterialButton(
        act, null, com.google.android.material.R.attr.materialButtonOutlinedStyle
    ).apply {
        this.text = text
        textSize = 12.5f
        cornerRadius = px(20)
        minimumWidth = 0
        setOnClickListener { onClick() }
    }

    private fun outlined(text: String, onClick: () -> Unit) = MaterialButton(
        act, null, com.google.android.material.R.attr.materialButtonOutlinedStyle
    ).apply {
        this.text = text
        setTextColor(color(R.color.accent))
        textSize = 12.5f
        cornerRadius = px(20)
        strokeColor = android.content.res.ColorStateList.valueOf(color(R.color.border))
        minimumWidth = 0
        setOnClickListener { onClick() }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun toast(msg: String) {
        Toast.makeText(act, msg, Toast.LENGTH_SHORT).show()
    }

    private fun fileName(uri: Uri): String = runCatching {
        act.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/') ?: "файл"

    private fun folderName(uri: Uri): String = runCatching {
        DocumentsContract.getTreeDocumentId(uri).substringAfterLast('/').substringAfterLast(':')
    }.getOrDefault("").ifEmpty { "Хранилище" }
}
