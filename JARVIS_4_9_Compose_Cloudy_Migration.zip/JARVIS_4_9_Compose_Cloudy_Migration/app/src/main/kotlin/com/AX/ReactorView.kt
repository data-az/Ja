package com.AX

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.PI
import kotlin.math.sin

/**
 * «Реактор» в стиле JARVIS AZ для ПК: тонкое дышащее кольцо, внешние кольца,
 * заливка, две волны по бокам и точка в центре. Всё растёт от громкости голоса (см. [setLevel]).
 * Цвет тот же, что у ПК: светло-серый, без цветных подсветок.
 * Анимация покадровая и останавливается, когда вид не на экране.
 */
class ReactorView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Идёт запись голоса: кольцо расширяется от громкости. */
    var listening = false

    /** Распознавание / выполнение команды: кольца вращаются быстрее. */
    var busy = false

    /** Цвет реактора. Меняется в редакторе интерфейса; по умолчанию как на ПК. */
    var baseColor: Int = COLOR_BASE

    private var level = 0f
    private var levelSmooth = 0f
    private var time = 0f
    private var lastFrame = 0L

    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val wavePath = Path()

    /** Громкость из onRmsChanged (примерно от -2 до 10 дБ). */
    fun setLevel(rmsDb: Float) {
        level = ((rmsDb + 2f) / 12f).coerceIn(0f, 1f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrame == 0L) 0f else ((now - lastFrame) / 1000f).coerceAtMost(0.05f)
        lastFrame = now
        time += dt * (if (busy) 2.2f else 1f)
        levelSmooth += (level - levelSmooth) * 0.35f
        if (!listening) level *= 0.9f

        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val cx = w / 2f
        val cy = h / 2f
        val rMax = minOf(w, h) / 2f * 0.92f
        val lvl = levelSmooth
        val base = baseColor

        // Внутренний радиус дышит и растёт от голоса (как ПК: 0.30 R + вклад громкости)
        val r0 = rMax * (0.30f + 0.012f * sin(time * 1.3f)) + lvl * rMax * 0.10f

        // Внешние тонкие кольца
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f * density
        for (k in RINGS downTo 1) {
            val rk = r0 + k * rMax * 0.10f + lvl * rMax * 0.04f * k
            paint.color = withAlpha(base, minOf(255f, 70f / k + lvl * 40f).toInt())
            canvas.drawCircle(cx, cy, rk, paint)
        }

        // Лёгкая заливка внутри
        paint.style = Paint.Style.FILL
        paint.color = withAlpha(base, (10f + lvl * 30f).toInt())
        canvas.drawCircle(cx, cy, r0, paint)

        // Основное кольцо
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.6f * density
        paint.color = withAlpha(base, 235)
        canvas.drawCircle(cx, cy, r0, paint)

        // Волны по бокам: растут от голоса
        for (side in intArrayOf(-1, 1)) {
            for (layer in 0..1) {
                val ampK = if (layer == 0) 1.0f else 0.6f
                val alpha = if (layer == 0) 120 else 60
                val x0 = cx + side * (r0 + rMax * 0.18f)
                val x1 = cx + side * (w / 2f - 6f * density)
                wavePath.reset()
                val n = 48
                for (i in 0..n) {
                    val t = i / n.toFloat()
                    val x = x0 + (x1 - x0) * t
                    val envelope = Math.pow(sin(PI * t), 1.5).toFloat()
                    val amp = (2f * density + lvl * rMax * 0.32f) * ampK * envelope
                    val y = cy + sin(t * 9f + time * 3f + layer * 1.3f) * amp
                    if (i == 0) wavePath.moveTo(x, y) else wavePath.lineTo(x, y)
                }
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 1f * density
                paint.color = withAlpha(base, alpha)
                canvas.drawPath(wavePath, paint)
            }
        }

        // Точка в центре
        paint.style = Paint.Style.FILL
        paint.color = withAlpha(base, 255)
        canvas.drawCircle(cx, cy, (3f + lvl * 3f) * density, paint)

        if (isShown) postInvalidateOnAnimation()
    }

    private fun withAlpha(rgb: Int, alpha: Int): Int =
        (alpha.coerceIn(0, 255) shl 24) or (rgb and 0x00FFFFFF)

    companion object {
        private const val RINGS = 3
        /** #E8E8E8, цвет «Готов» и кольца на ПК. */
        const val COLOR_BASE = 0xFFE8E8E8.toInt()
    }
}
