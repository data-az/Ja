package com.AX

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.provider.MediaStore
import android.view.KeyEvent

/**
 * Музыкальные команды: «включи <трек/альбом/исполнителя>» отдаёт запрос плееру,
 * «пауза», «дальше», «предыдущий» нажимают кнопки медиа для текущего плеера.
 */
object MusicCommands {

    private const val YOUTUBE = "включи на ютубе"

    private val PLAY_PREFIXES = listOf(
        "включи музыку", "включи трек", "включи песню", "включи альбом",
        "включи исполнителя", "включи избранное", "включи скачанное",
        "поставь музыку", "поставь песню", "играй", YOUTUBE
    )

    /** Фраза → (код кнопки медиа, что ответить). */
    private val CONTROL: Map<String, Pair<Int, String>> = mapOf(
        "пауза" to (KeyEvent.KEYCODE_MEDIA_PAUSE to "Пауза"),
        "продолжить" to (KeyEvent.KEYCODE_MEDIA_PLAY to "Продолжаю"),
        "дальше" to (KeyEvent.KEYCODE_MEDIA_NEXT to "Следующий трек"),
        "следующий трек" to (KeyEvent.KEYCODE_MEDIA_NEXT to "Следующий трек"),
        "следующая песня" to (KeyEvent.KEYCODE_MEDIA_NEXT to "Следующий трек"),
        "предыдущий трек" to (KeyEvent.KEYCODE_MEDIA_PREVIOUS to "Предыдущий трек"),
        "предыдущая песня" to (KeyEvent.KEYCODE_MEDIA_PREVIOUS to "Предыдущий трек")
    )

    fun matches(c: String): Boolean =
        CONTROL.containsKey(c) || PLAY_PREFIXES.any { c.startsWith(it) }

    fun run(ctx: Context, c: String): Reply {
        CONTROL[c]?.let { (code, label) -> return press(ctx, code, label) }
        val prefix = PLAY_PREFIXES.first { c.startsWith(it) }
        val query = c.removePrefix(prefix).trim()
        if (query.isEmpty()) return press(ctx, KeyEvent.KEYCODE_MEDIA_PLAY, "Продолжаю музыку")
        return play(ctx, query, youtube = prefix == YOUTUBE)
    }

    private fun press(ctx: Context, code: Int, label: String): Reply {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return Reply(true, label)
    }

    private fun play(ctx: Context, query: String, youtube: Boolean): Reply {
        val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            putExtra(MediaStore.EXTRA_MEDIA_QUERY, query)
            putExtra("query", query)
            if (youtube) setPackage("com.google.android.youtube")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            ctx.startActivity(intent)
            Reply(true, "Включаю: $query")
        } catch (e: Exception) {
            Reply(false, "Нет музыкального приложения для «$query»")
        }
    }
}
