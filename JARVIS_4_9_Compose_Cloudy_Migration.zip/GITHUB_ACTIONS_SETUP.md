# GitHub Actions build

This project keeps the supplied toolchain configuration:

- Android Gradle Plugin 9.1.1
- Gradle 9.5.0 (installed by the supplied workflow)
- Kotlin 2.4.0
- JDK 17
- compileSdk / targetSdk 37
- minSdk 26 (Android 8.0+; Android 11 / API 30 is supported)

The Cloudy dependency has been removed. The dock glass effect is implemented in project Kotlin code and adds no rendering dependency.

## Repository layout

1. Keep `JARVIS_4_9_Compose_Cloudy_Migration.zip` in the repository root.
2. Copy `build-apk.yml` to `.github/workflows/build-apk.yml`.
3. Commit and push, or run the workflow manually from Actions.

The supplied workflow is intentionally retained unchanged to avoid disturbing the Android SDK setup you already tested.

## Local build

Open the extracted project in Android Studio, run Gradle Sync, then build `:app:assembleDebug`.
