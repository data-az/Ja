# GitHub Actions build

This archive uses a pinned toolchain:

- Android Gradle Plugin 9.1.0
- Gradle 9.3.1
- Kotlin 2.4.0
- JDK 17
- compileSdk / targetSdk 37

AGP 9.1 requires Gradle 9.3.1 or newer. The project opts out of AGP's built-in Kotlin and the new Android DSL while it applies the external Kotlin 2.4.0 plugins. This avoids registering Kotlin twice.

Cloudy 0.7.1 is resolved from JitPack; the repository is declared in `settings.gradle.kts`.

## If the GitHub repository contains this ZIP

Copy `android.yml` from this archive to `.github/workflows/android.yml` in the GitHub repository. Keep the project ZIP in the repository (root or up to two folders below it). Run the workflow manually from Actions.

## If the GitHub repository contains the extracted project

Copy `.github/workflows/android.yml` into the repository and adjust the workflow's unpack step: remove the ZIP search/unzip step and set `PROJECT_DIR` to `$GITHUB_WORKSPACE`.

The workflow installs Gradle itself, so the GitHub build does not depend on a checked-in `gradlew` script.
