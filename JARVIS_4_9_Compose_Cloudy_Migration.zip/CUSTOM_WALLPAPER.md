# Custom backgrounds — JARVIS 4.9 / Android 11

- Open **Settings → Appearance → Own JARVIS background → Upload background**.
- Pick an image from Gallery or Files. The Android Storage Access Framework is used; the app does not request broad storage permissions.
- The chosen image is center-cropped, darkened slightly for text contrast, and saved so it is restored after restarting JARVIS.
- Use **Reset** to return to the original neon background.
- The dock's software-glass renderer samples the updated screen underneath it, so the selected wallpaper also appears through the dock.

The non-dock cards, command field and chips now use dark navy/blue tinted glass rather than the former pale white translucent fill. The dock renderer and its navigation/animations were intentionally left unchanged.
