Голос Piper (ru_RU-ruslan-medium) импортируется из приложения:
Настройки -> Голос -> «Импортировать файлы голоса». Выберите сразу два файла:
  *.onnx     - модель Piper (ru_RU-ruslan-medium.onnx из rhasspy/piper-voices), сохранится как silero_tts.onnx
  tokens.txt - таблица фонем «символ id» (из csukuangfj/vits-piper-ru_RU-ruslan-medium)
Необязательно:
  stress.txt - свои ударения: слово на строку, знак + перед ударной гласной (прив+ет)
  *.onnx.json - конфиг модели (частота, scales), сохранится как model.json
Вручную (запасной путь): Android/data/com.AX/files/silero/ на телефоне.
Модель понимает фонемы, а не буквы; текст в фонемы переводит встроенный RuPhonemizer.
Подробный разбор работы голоса: Логи -> «Звук».
