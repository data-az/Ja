package com.AX

import android.annotation.SuppressLint
import android.view.MotionEvent
import android.view.View
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

/**
 * Пружинное нажатие: при касании вьюха мягко сжимается и возвращается пружиной.
 * Touch-слушатель возвращает false, поэтому обычные клики продолжают работать.
 */
object SpringPress {

    @SuppressLint("ClickableViewAccessibility")
    fun attach(view: View, pressedScale: Float = 0.92f) {
        val sx = spring(view, DynamicAnimation.SCALE_X)
        val sy = spring(view, DynamicAnimation.SCALE_Y)
        view.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx.animateToFinalPosition(pressedScale)
                    sy.animateToFinalPosition(pressedScale)
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    sx.animateToFinalPosition(1f)
                    sy.animateToFinalPosition(1f)
                }
            }
            false
        }
    }

    private fun spring(view: View, property: DynamicAnimation.ViewProperty) =
        SpringAnimation(view, property).apply {
            spring = SpringForce(1f)
                .setStiffness(SpringForce.STIFFNESS_MEDIUM)
                .setDampingRatio(SpringForce.DAMPING_RATIO_MEDIUM_BOUNCY)
        }
}
