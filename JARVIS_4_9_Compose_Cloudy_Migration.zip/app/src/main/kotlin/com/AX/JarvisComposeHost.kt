package com.AX

import android.view.LayoutInflater
import android.view.View
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.ReceiptLong
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.skydoves.cloudy.cloudy
import com.skydoves.cloudy.liquidGlass
import com.skydoves.cloudy.rememberSky
import com.skydoves.cloudy.sky

@Composable
fun JarvisComposeHost(
    currentPage: Int,
    showDock: Boolean,
    onPageSelected: (Int) -> Unit,
    onLegacyRootReady: (View) -> Unit,
) {
    val sky = rememberSky()
    LaunchedEffect(currentPage) { sky.invalidate(durationMillis = 280) }

    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            factory = { context ->
                LayoutInflater.from(context)
                    .inflate(R.layout.activity_main, null, false)
                    .also(onLegacyRootReady)
            },
            modifier = Modifier.fillMaxSize().sky(sky),
            update = { /* Existing View-based screens retain their own state and listeners. */ },
        )

        AnimatedVisibility(
            visible = showDock,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(spring(stiffness = Spring.StiffnessMediumLow)),
            exit = fadeOut(spring(stiffness = Spring.StiffnessMedium)),
        ) {
            LiquidGlassDock(
                selectedPage = currentPage,
                onPageSelected = onPageSelected,
                sky = sky,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(
                        bottom = 12.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
                    ),
            )
        }
    }
}

@Composable
private fun LiquidGlassDock(
    selectedPage: Int,
    onPageSelected: (Int) -> Unit,
    sky: com.skydoves.cloudy.Sky,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(34.dp)
    var measuredSize by remember { mutableStateOf(IntSize.Zero) }
    val lensCenter = Offset(measuredSize.width / 2f, measuredSize.height / 2f)
    val lensSize = Size(measuredSize.width.toFloat(), measuredSize.height.toFloat())

    BoxWithConstraints(
        modifier = modifier
            .height(70.dp)
            .clip(shape)
            .cloudy(
                sky = sky,
                radius = 26,
                tint = Color(0xA9161D2D),
                shape = shape,
                cpuBlurEnabled = true,
            )
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xB82B3448), Color(0xA00C1220), Color(0xB81B2435))
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    listOf(Color(0xA6FFFFFF), Color(0x24FFFFFF), Color(0x66A9DFFF), Color(0x44FFFFFF))
                ),
                shape = shape,
            )
            .onSizeChanged { measuredSize = it }
            .then(
                if (measuredSize.width > 0 && measuredSize.height > 0) {
                    Modifier.liquidGlass(
                        lensCenter = lensCenter,
                        lensSize = lensSize,
                        cornerRadius = 34f,
                        refraction = 0.16f,
                        curve = 0.22f,
                        dispersion = 0.012f,
                        saturation = 1.08f,
                        contrast = 1.04f,
                        tint = Color.Transparent,
                        edge = 0.18f,
                    )
                } else Modifier
            ),
        ) {
        val slotWidth = maxWidth / 3
        val indicatorX by animateDpAsState(
            targetValue = slotWidth * selectedPage,
            animationSpec = spring(
                dampingRatio = 0.72f,
                stiffness = 430f,
                visibilityThreshold = 0.5.dp,
            ),
            label = "glass-indicator-position",
        )
        Box(
            modifier = Modifier
                .offset(x = indicatorX + 5.dp)
                .width(slotWidth - 10.dp)
                .height(60.dp)
                .align(Alignment.CenterStart)
                .clip(RoundedCornerShape(27.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0x4AFFFFFF), Color(0x20C7E8FF), Color(0x1AFFFFFF))
                    )
                )
                .border(1.dp, Color(0x4DFFFFFF), RoundedCornerShape(27.dp)),
        )

        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 3.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            DockItem(0, selectedPage, "Главная", Icons.Rounded.Home, onPageSelected, Modifier.weight(1f))
            DockItem(1, selectedPage, "Логи", Icons.Rounded.ReceiptLong, onPageSelected, Modifier.weight(1f))
            DockItem(2, selectedPage, "Настройки", Icons.Rounded.Settings, onPageSelected, Modifier.weight(1f))
        }
    }
}

@Composable
private fun DockItem(
    page: Int,
    selectedPage: Int,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onPageSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val selected = page == selectedPage
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.12f else 0.94f,
        animationSpec = spring(dampingRatio = 0.62f, stiffness = 480f),
        label = "dock-icon-scale-$page",
    )
    val alpha by animateFloatAsState(
        targetValue = if (selected) 1f else 0.62f,
        animationSpec = spring(stiffness = 360f),
        label = "dock-item-alpha-$page",
    )
    val haptics = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(28.dp))
            .clickable(
                interactionSource = interaction,
                indication = null,
            ) {
                if (!selected) {
                    haptics.performHapticFeedback(HapticFeedbackType.Confirm)
                    onPageSelected(page)
                }
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = Color.White.copy(alpha = alpha),
            modifier = Modifier
                .size(23.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                },
        )
        Text(
            text = label,
            color = Color.White.copy(alpha = alpha),
            fontSize = 10.sp,
            lineHeight = 12.sp,
            modifier = Modifier.padding(top = 3.dp),
        )
    }
}
