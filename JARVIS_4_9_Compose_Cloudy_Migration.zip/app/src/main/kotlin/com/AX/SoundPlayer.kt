package com.AX

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.util.Collections

/**
 * Проигрывает звуки из res/raw. Случайный звук выбирается так,
 * что один и тот же не идёт два раза подряд. Воспроизведение не блокирует
 * поток: [playRandom] возвращает идентификатор потока сразу, а [stop] может
 * оборвать звук, если команда не удалась.
 */
class SoundPlayer(private val context: Context) {

    private val names = listOf("zaprosvipolnen", "zagrujay", "yes", "kakpojelayte", "daser")
    private val pool = SoundPool.Builder()
        .setMaxStreams(2)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        .build()

    private val ids = mutableMapOf<String, Int>()
    private val loaded: MutableSet<Int> = Collections.synchronizedSet(HashSet<Int>())
    private var lastName: String? = null

    @Volatile
    private var released = false

    init {
        pool.setOnLoadCompleteListener { _, sampleId, status ->
            val name = ids.entries.firstOrNull { it.value == sampleId }?.key ?: "#$sampleId"
            if (status == 0) {
                loaded.add(sampleId)
                AppLog.sound("INFO", "Файл $name.wav загружен в SoundPool (id $sampleId)", null)
            } else {
                AppLog.sound("ERR", "Файл $name.wav не загрузился, статус $status", "wav $name не загрузился")
            }
        }
        for (name in names) {
            val resId = context.resources.getIdentifier(name, "raw", context.packageName)
            if (resId != 0) {
                ids[name] = pool.load(context, resId, 1)
            } else {
                AppLog.sound("ERR", "Нет ресурса res/raw/$name.wav", "нет файла $name.wav")
            }
        }
    }

    /** Запускает случайный звук и сразу возвращает id потока (0, если играть нечего). */
    fun playRandom(): Int {
        if (released) return 0
        val ready = ids.filterValues { it in loaded }.keys
        if (ready.isEmpty()) {
            AppLog.sound("ERR", "Готовые звуки не воспроизведены: ни один wav ещё не загружен (${ids.size} в очереди)", "wav ещё не загружены")
            return 0
        }
        val candidates = ready.filter { it != lastName }.ifEmpty { ready.toList() }
        val name = candidates.random()
        lastName = name
        val v = Prefs.soundVolume
        val stream = pool.play(ids.getValue(name), v, v, 1, 0, 1f)
        AppLog.sound(
            if (stream == 0) "ERR" else "INFO",
            "Готовый звук $name.wav: громкость ${"%.2f".format(java.util.Locale.US, v)}, поток $stream" +
                if (stream == 0) " — SoundPool отказался играть" else "",
            "wav $name" + if (stream == 0) " не сыграл" else ""
        )
        return stream
    }

    fun stop(streamId: Int) {
        if (!released && streamId != 0) pool.stop(streamId)
    }

    fun release() {
        released = true
        pool.release()
    }
}
