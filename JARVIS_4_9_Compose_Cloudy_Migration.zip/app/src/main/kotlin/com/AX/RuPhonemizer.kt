package com.AX

import java.util.Locale

/**
 * Русский текст → фонемы IPA в том виде, в каком их выдаёт espeak-ng (voice "ru").
 *
 * Модели Piper (в т.ч. ru_RU-ruslan-medium) обучены НЕ на буквах, а на фонемах espeak-ng:
 * «привет» → `prʲɪvʲˈet`. Если подать модели кириллицу, она не найдёт ни одного своего символа
 * и промолчит (или пискнет на пару миллисекунд). Этот объект заменяет espeak-ng, которого на Android нет.
 *
 * Что умеет: числа → слова, латиница → кириллица, редукция гласных, смягчение согласных,
 * оглушение/озвончение, ударение (словарь + правила; своё слово можно добавить в stress.txt).
 *
 * Ударение в записи слова — знак «+» перед ударной гласной: `прив+ет`. Буква «ё» всегда ударная.
 * Чистый Kotlin без зависимостей от Android, поэтому проверяется на ПК.
 */
object RuPhonemizer {

    private const val VOWELS = "аеёиоуыэюя"
    private const val IOTATED = "еёюя"
    private const val HARD_ONLY = "жшц"
    private const val SOFT_ONLY = "чщй"
    private const val SOFTENERS = "еёиюяь"
    private const val VOICED = "бвгджз"
    private const val VOICELESS = "пфктшсхцчщ"
    private val DEVOICE = mapOf('б' to 'п', 'в' to 'ф', 'г' to 'к', 'д' to 'т', 'ж' to 'ш', 'з' to 'с')
    private val VOICE = mapOf('п' to 'б', 'ф' to 'в', 'к' to 'г', 'т' to 'д', 'ш' to 'ж', 'с' to 'з')

    private val CONS = mapOf(
        'б' to "b", 'в' to "v", 'г' to "ɡ", 'д' to "d", 'ж' to "ʐ", 'з' to "z", 'й' to "j",
        'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'п' to "p", 'р' to "r", 'с' to "s",
        'т' to "t", 'ф' to "f", 'х' to "x", 'ц' to "ts", 'ч' to "tɕ", 'ш' to "ʂ", 'щ' to "ɕː"
    )

    /** Знаки, которые модель знает и которые дают паузу/интонацию. */
    private const val PUNCT = ".,!?:;"

    /** Слова без своего ударения (предлоги, союзы, частицы). */
    private val CLITICS = setOf(
        "в", "во", "на", "с", "со", "к", "ко", "у", "о", "об", "обо", "от", "до", "за", "из", "по",
        "при", "про", "над", "под", "без", "для", "не", "ни", "ли", "же", "бы", "б", "ль", "то", "ка"
    )

    /** Произносится не так, как пишется (замена букв «в длину» один к одному). */
    private val RESPELL = mapOf(
        "что" to "што", "чтобы" to "штобы", "конечно" to "конешно", "скучно" to "скушно",
        "нарочно" to "нарошно", "сегодня" to "севодня", "его" to "ево", "него" to "нево",
        "чего" to "чево", "кого" to "ково", "того" to "тово", "этого" to "этово",
                "солнце" to "сонце", "сердце" to "сэрце", "чувство" to "чуство", "лестница" to "лесница"
    )

    private val BUILTIN_STRESS: Map<String, String> by lazy {
        val numbers = (ONES_M.toList() + ONES_F.toList() + TEENS.toList() + TENS.toList() + HUNDREDS.toList())
            .joinToString(" ") + " т+ысяча т+ысячи т+ысяч милли+он милли+она милли+онов"
        parseDictionary(BUILTIN_DICTIONARY + " " + numbers)
    }

    /** Словарь пользователя (stress.txt): слово с «+» на строку. Перекрывает встроенный. */
    @Volatile
    private var userStress: Map<String, String> = emptyMap()

    fun setUserDictionary(lines: List<String>) {
        userStress = parseDictionary(lines.joinToString(" "))
    }

    private fun parseDictionary(src: String): Map<String, String> {
        val m = HashMap<String, String>()
        for (w in src.split(Regex("[\\s,;]+"))) {
            val word = w.trim().lowercase(Locale.ROOT)
            if (word.isEmpty() || !word.contains('+')) continue
            m[word.replace("+", "")] = word
        }
        return m
    }

    // ------------------------------------------------------------------ Публичное

    /** Фонемы для одного куска текста (одно-два предложения). Пустая строка, если озвучивать нечего. */
    fun phonemize(text: String): String {
        val sb = StringBuilder()
        for (tok in tokenize(prepare(text))) {
            if (tok.length == 1 && tok[0] in PUNCT) {
                if (sb.isNotEmpty() && sb.last() != ' ' && sb.last() !in PUNCT) sb.append(tok)
                continue
            }
            val ipa = wordToIpa(tok)
            if (ipa.isEmpty()) continue
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(ipa)
        }
        return sb.toString().trim()
    }

    /** Текст после подстановок (числа, латиница) — для лога. */
    fun normalized(text: String): String = prepare(text)

    // ------------------------------------------------------------------ Подготовка текста

    private fun prepare(text: String): String {
        var s = text.lowercase(Locale.ROOT)
        s = s.replace('ё', 'ё')
        s = expandNumbers(s)
        s = transliterateLatin(s)
        return s
    }

    private fun tokenize(s: String): List<String> {
        val res = ArrayList<String>()
        val cur = StringBuilder()
        fun flush() { if (cur.isNotEmpty()) { res.add(cur.toString()); cur.setLength(0) } }
        var i = 0
        while (i < s.length) {
            val c = s[i]
            when {
                c in 'а'..'я' || c == 'ё' || c == '+' -> cur.append(c)
                c == '-' && cur.isNotEmpty() && i + 1 < s.length && (s[i + 1] in 'а'..'я' || s[i + 1] == 'ё') -> flush()
                c == '—' || c == '–' || c == '-' -> { flush(); if (res.isNotEmpty() && res.last() !in PUNCT_TOKENS) res.add(",") }
                c in PUNCT -> { flush(); res.add(c.toString()) }
                c == '…' -> { flush(); res.add(".") }
                else -> flush()
            }
            i++
        }
        flush()
        return res
    }

    private val PUNCT_TOKENS = PUNCT.map { it.toString() }.toSet()

    // ------------------------------------------------------------------ Числа

    private val ONES_M = arrayOf("", "од+ин", "дв+а", "тр+и", "чет+ыре", "пять", "шесть", "семь", "в+осемь", "д+евять")
    private val ONES_F = arrayOf("", "одн+а", "дв+е", "тр+и", "чет+ыре", "пять", "шесть", "семь", "в+осемь", "д+евять")
    private val TEENS = arrayOf(
        "д+есять", "од+иннадцать", "двен+адцать", "трин+адцать", "чет+ырнадцать",
        "пятн+адцать", "шестн+адцать", "семн+адцать", "восемн+адцать", "девятн+адцать"
    )
    private val TENS = arrayOf(
        "", "", "дв+адцать", "тр+идцать", "с+орок", "пятьдес+ят", "шестьдес+ят",
        "с+емьдесят", "в+осемьдесят", "девян+осто"
    )
    private val HUNDREDS = arrayOf(
        "", "сто", "дв+ести", "тр+иста", "чет+ыреста", "пятьс+от", "шестьс+от", "семьс+от",
        "восемьс+от", "девятьс+от"
    )

    private fun triplet(n: Int, feminine: Boolean, out: MutableList<String>) {
        val h = n / 100
        val t = n / 10 % 10
        val o = n % 10
        if (h > 0) out.add(HUNDREDS[h])
        if (t == 1) { out.add(TEENS[o]); return }
        if (t > 1) out.add(TENS[t])
        if (o > 0) out.add((if (feminine) ONES_F else ONES_M)[o])
    }

    private fun form(n: Long, one: String, few: String, many: String): String {
        val last = (n % 10).toInt()
        val two = (n % 100).toInt()
        return when {
            two in 11..14 -> many
            last == 1 -> one
            last in 2..4 -> few
            else -> many
        }
    }

    private fun numberToWords(value: Long): String {
        if (value == 0L) return "ноль"
        val out = ArrayList<String>()
        var v = value
        val billions = (v / 1_000_000_000L).toInt(); v %= 1_000_000_000L
        val millions = (v / 1_000_000L).toInt(); v %= 1_000_000L
        val thousands = (v / 1_000L).toInt(); v %= 1_000L
        val rest = v.toInt()
        if (billions > 0) {
            triplet(billions, false, out)
            out.add(form(billions.toLong(), "милли+ард", "милли+арда", "милли+ардов"))
        }
        if (millions > 0) {
            triplet(millions, false, out)
            out.add(form(millions.toLong(), "милли+он", "милли+она", "милли+онов"))
        }
        if (thousands > 0) {
            triplet(thousands, true, out)
            out.add(form(thousands.toLong(), "т+ысяча", "т+ысячи", "т+ысяч"))
        }
        if (rest > 0) triplet(rest, false, out)
        return out.joinToString(" ")
    }

    private val NUMBER = Regex("(\\d+)(?:[.,](\\d+))?")

    private fun expandNumbers(s: String): String = NUMBER.replace(s) { m ->
        val whole = m.groupValues[1]
        val frac = m.groupValues[2]
        val wholeWords = if (whole.length <= 12) numberToWords(whole.toLong())
        else whole.map { numberToWords((it - '0').toLong()) }.joinToString(" ")
        val sb = StringBuilder(" ").append(wholeWords)
        if (frac.isNotEmpty()) {
            sb.append(" запят+ая ")
            sb.append(frac.map { numberToWords((it - '0').toLong()) }.joinToString(" "))
        }
        sb.append(' ').toString()
    }

    // ------------------------------------------------------------------ Латиница

    private val LATIN_WORDS = mapOf(
        "jarvis" to "дж+арвис", "telegram" to "телегр+ам", "youtube" to "ют+уб", "whatsapp" to "вотс+ап",
        "google" to "г+угл", "chrome" to "кр+ом", "yandex" to "+яндекс", "instagram" to "инстагр+ам",
        "tiktok" to "тикт+ок", "spotify" to "спот+ифай", "android" to "андр+оид", "ok" to "ок+ей",
        "bluetooth" to "бл+ютус", "wifi" to "в+ай-ф+ай", "az" to "эй з+эд", "ai" to "эй +ай",
        "gmail" to "джим+ейл", "viber" to "в+айбер", "discord" to "диск+орд",
        "vk" to "вэ-к+а", "facebook" to "фейсб+ук", "twitter" to "тв+иттер", "netflix" to "н+етфликс",
        "play" to "пл+ей", "market" to "м+аркет", "store" to "ст+ор", "camera" to "к+амера",
        "silero" to "сил+еро", "piper" to "п+айпер"
    )

    private val LATIN_DIGRAPHS = listOf(
        "sch" to "щ", "tch" to "ч", "sh" to "ш", "ch" to "ч", "th" to "т", "ph" to "ф", "kh" to "х",
        "zh" to "ж", "ts" to "ц", "yo" to "ё", "yu" to "ю", "ya" to "я", "ee" to "и", "oo" to "у",
        "ck" to "к", "qu" to "кв", "ou" to "ау", "ea" to "и"
    )
    private val LATIN_LETTERS = mapOf(
        'a' to "а", 'b' to "б", 'c' to "к", 'd' to "д", 'e' to "е", 'f' to "ф", 'g' to "г", 'h' to "х",
        'i' to "и", 'j' to "дж", 'k' to "к", 'l' to "л", 'm' to "м", 'n' to "н", 'o' to "о", 'p' to "п",
        'q' to "к", 'r' to "р", 's' to "с", 't' to "т", 'u' to "у", 'v' to "в", 'w' to "в", 'x' to "кс",
        'y' to "и", 'z' to "з"
    )

    private fun transliterateLatin(s: String): String = Regex("[a-z]+").replace(s) { m ->
        val w = m.value
        LATIN_WORDS[w] ?: transliterateWord(w)
    }

    private fun transliterateWord(w0: String): String {
        var w = w0
        if (w.length > 3 && w.endsWith("e") && w[w.length - 2] !in "aeiouy") w = w.dropLast(1)
        val sb = StringBuilder()
        var i = 0
        outer@ while (i < w.length) {
            for ((from, to) in LATIN_DIGRAPHS) {
                if (w.startsWith(from, i)) { sb.append(to); i += from.length; continue@outer }
            }
            sb.append(LATIN_LETTERS[w[i]] ?: ""); i++
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------ Слово → IPA

    private class Word(val letters: MutableList<Char>, var stress: Int) {
        fun removeAt(i: Int) {
            letters.removeAt(i)
            if (stress > i) stress--
        }
        fun replace(i: Int, c: Char) { letters[i] = c }
    }

    private fun wordToIpa(token: String): String {
        // 1. Разбор «+»
        var stress = -1
        val letters = ArrayList<Char>()
        for (ch in token) {
            if (ch == '+') { stress = letters.size; continue }
            if (ch in 'а'..'я' || ch == 'ё') letters.add(ch)
        }
        if (letters.isEmpty()) return ""
        val original = letters.joinToString("")
        val vowelCount = letters.count { it in VOWELS }
        var clitic = false

        // 2. Ударение
        if (stress >= letters.size) stress = -1
        if (stress < 0 && 'ё' in letters) stress = letters.indexOf('ё')
        if (stress < 0) {
            val d = userStress[original] ?: BUILTIN_STRESS[original]
            if (d != null) stress = d.indexOf('+').let { if (it >= 0) it else -1 }
        }
        if (stress < 0 && original in CLITICS) clitic = true
        if (stress < 0 && !clitic) {
            stress = when (vowelCount) {
                0 -> -1
                1 -> letters.indexOfFirst { it in VOWELS }
                else -> guessStress(original)
            }
        }
        val w = Word(letters, stress)

        // 3. Орфоэпия: буквы, которые читаются иначе
        RESPELL[original]?.let { r -> if (r.length == w.letters.size) for (i in r.indices) w.replace(i, r[i]) }
        applyRules(w)

        // 4. Оглушение / озвончение
        assimilate(w, hasVowel = vowelCount > 0)

        // 5. Буквы → фонемы
        return render(w, clitic)
    }

    private fun applyRules(w: Word) {
        var s = w.letters.joinToString("")
        // «его/ого» в окончаниях → «ево/ова»
        if (s.length > 3 && (s.endsWith("ого") || s.endsWith("его"))) w.replace(s.length - 2, 'в')
        // -ться / -тся → [ц]
        s = w.letters.joinToString("")
        if (s.endsWith("ться") && s.length > 4) {
            val i = s.length - 4
            w.replace(i, 'ц'); w.removeAt(i + 1); w.removeAt(i + 1)   // "ть" "с" → "ц"
        } else if (s.endsWith("тся") && s.length > 3) {
            val i = s.length - 3
            w.replace(i, 'ц'); w.removeAt(i + 1)
        }
        // вств → ств
        s = w.letters.joinToString("")
        var k = s.indexOf("вств")
        while (k >= 0) { w.removeAt(k); s = w.letters.joinToString(""); k = s.indexOf("вств") }
        // тц, дц → ц
        s = w.letters.joinToString("")
        for (pair in listOf("тц", "дц")) {
            var q = s.indexOf(pair)
            while (q >= 0) { w.removeAt(q); s = w.letters.joinToString(""); q = s.indexOf(pair) }
        }
        // сч, зч, жч → щ
        var i = 0
        while (i < w.letters.size - 1) {
            if (w.letters[i] in "сзж" && w.letters[i + 1] == 'ч') { w.replace(i, 'щ'); w.removeAt(i + 1) }
            i++
        }
    }

    private fun assimilate(w: Word, hasVowel: Boolean) {
        val L = w.letters
        val n = L.size
        for (i in n - 1 downTo 0) {
            val c = L[i]
            val voiced = c in DEVOICE
            val voiceless = c in VOICE
            if (!voiced && !voiceless) continue
            var j = i + 1
            while (j < n && (L[j] == 'ь' || L[j] == 'ъ')) j++
            if (j >= n) {
                if (voiced && hasVowel) L[i] = DEVOICE.getValue(c)      // на конце слова
                continue
            }
            val next = L[j]
            when {
                next in VOICELESS -> if (voiced) L[i] = DEVOICE.getValue(c)
                next in "бгджз" -> if (voiceless) L[i] = VOICE.getValue(c)
            }
        }
    }

    /** Роли гласной относительно ударения. */
    private const val STRESSED = 0
    private const val PRETONIC1 = 1
    private const val PRETONIC_FAR = 2
    private const val POSTTONIC = 3

    private fun render(w: Word, clitic: Boolean): String {
        val L = w.letters
        val n = L.size
        val vowelPos = L.indices.filter { L[it] in VOWELS }
        val sp = vowelPos.indexOf(w.stress)

        fun role(i: Int): Int {
            if (clitic || sp < 0) return PRETONIC1
            val p = vowelPos.indexOf(i)
            return when {
                p == sp -> STRESSED
                p == sp - 1 -> PRETONIC1
                p < sp -> PRETONIC_FAR
                else -> POSTTONIC
            }
        }

        val sb = StringBuilder()
        var i = 0
        while (i < n) {
            val c = L[i]
            when {
                c in VOWELS -> {
                    val prev = if (i > 0) L[i - 1] else null
                    val r = role(i)
                    val afterHard = prev != null && prev in HARD_ONLY
                    val afterShch = prev != null && prev in "чщ"
                    if (c in IOTATED && (prev == null || prev in VOWELS || prev == 'ь' || prev == 'ъ')) sb.append('j')
                    if (r == STRESSED) sb.append('ˈ')
                    val ph = when (c) {
                        'а' -> when (r) {
                            STRESSED -> "a"
                            PRETONIC1 -> if (afterShch) "ɪ" else "ɐ"
                            PRETONIC_FAR -> if (i == vowelPos[0]) "ɐ" else "ə"
                            else -> "ə"
                        }
                        'о' -> when (r) {
                            STRESSED -> "o"
                            PRETONIC1 -> "ɐ"
                            PRETONIC_FAR -> if (i == vowelPos[0]) "ɐ" else "ə"
                            else -> "ə"
                        }
                        'у', 'ю' -> "u"
                        'ы' -> "ɨ"
                        'э' -> if (r == STRESSED) "ɛ" else "ɪ"
                        'и' -> if (afterHard) "ɨ" else if (r == STRESSED) "i" else "ɪ"
                        'е' -> if (afterHard) (if (r == STRESSED) "ɛ" else "ɨ") else (if (r == STRESSED) "e" else "ɪ")
                        'ё' -> "o"
                        'я' -> when (r) { STRESSED -> "a"; PRETONIC1, PRETONIC_FAR -> "ɪ"; else -> "ə" }
                        else -> ""
                    }
                    sb.append(ph)
                }
                c == 'ь' || c == 'ъ' -> {}
                else -> {
                    val base = CONS[c]
                    if (base != null) {
                        val double = i + 1 < n && L[i + 1] == c && c != 'щ'
                        val nx = L.getOrNull(if (double) i + 2 else i + 1)
                        val soft = c in SOFT_ONLY || (c !in HARD_ONLY && nx != null && nx in SOFTENERS)
                        sb.append(base)
                        if (soft && c !in "жшцчщй") sb.append('ʲ')
                        if (double) { sb.append('ː'); i++ }
                    }
                }
            }
            i++
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------ Угадывание ударения

    /** Для слов вне словаря: правила по окончаниям, иначе предпоследний слог. Возвращает индекс буквы. */
    private fun guessStress(word: String): Int {
        var s = word
        val reflexive = s.endsWith("ся") || s.endsWith("сь")
        if (reflexive && s.length > 4) s = s.dropLast(2)

        fun lastVowelBefore(idx: Int): Int {
            for (k in idx - 1 downTo 0) if (s[k] in VOWELS) return k
            return -1
        }
        val vowels = s.indices.filter { s[it] in VOWELS }
        if (vowels.size < 2) return vowels.firstOrNull() ?: -1

        // -ировать / -овать / -евать
        for (suf in listOf("овать", "евать")) if (s.endsWith(suf)) return s.length - suf.length
        // -ывать / -ивать: ударение на гласную перед суффиксом
        for (suf in listOf("ывать", "ивать")) if (s.endsWith(suf)) return lastVowelBefore(s.length - suf.length)
        // совершенный вид: вы́-
        if (s.startsWith("вы") && vowels.size >= 3 && VY_ENDINGS.any { s.endsWith(it) }) return 1
        // инфинитивы: на последний слог
        if (s.endsWith("ть") || s.endsWith("ти") || s.endsWith("чь")) return vowels.last()
        // прилагательные: -ого/-его, -ая/-ое/-ые/-яя/-ее — ударение на основе
        if (vowels.size >= 3) {
            if (s.endsWith("ого") || s.endsWith("его")) return lastVowelBefore(s.length - 3)
            for (suf in listOf("ая", "ое", "ые", "яя", "ее")) if (s.endsWith(suf)) return lastVowelBefore(s.length - 2)
        }
        // -ция, -ние
        if (s.endsWith("ция") && vowels.size >= 3) return lastVowelBefore(s.length - 3)
        if (s.endsWith("ние") && vowels.size >= 3) return lastVowelBefore(s.length - 2)
        // приказ: -и́ / -и́те (включи, найди, позвони)
        if (s.endsWith("ите") && vowels.size >= 3) return vowels[vowels.size - 2]
        // по умолчанию — предпоследний слог
        return vowels[vowels.size - 2]
    }

    private val VY_ENDINGS = listOf(
        "ть", "ти", "л", "ла", "ло", "ли", "ю", "ешь", "ет", "ем", "ете", "ут", "ют", "ит", "им", "ите", "ат", "ят",
        "ен", "ена", "ено", "ены", "ь"
    )

    // ------------------------------------------------------------------ Встроенный словарь ударений

    private const val BUILTIN_DICTIONARY = """
        открыв+аю открыв+ает открыв+ай открыв+ать откр+ыть откр+ой откр+ойте откр+ыт откр+ыто откр+ыта
        закрыв+аю закрыв+ает закрыв+ать закр+ыть закр+ой закр+ыт закр+ыто
        запуск+аю запуск+ает запуст+и запуст+ить зап+ущен зап+ущено
        включ+аю включ+ает включ+ить включ+и включен+о включен+а включ+ите включ+ение
        выключ+аю выключ+ает выключ+ать в+ыключить в+ыключи в+ыключен в+ыключено в+ыключена в+ыключите
        звон+ю звон+ишь звон+ить позвон+ить позвон+и звонк+и звон+ок набер+и набер+ите
        найд+и найт+и найд+ен найд+ено найд+ена найд+ены
        с+оздан созд+ана с+оздано с+озданы созд+ать созд+ай созда+ю
        сд+елано сд+елан сд+елай сд+елать
        напис+ать напиш+и пиш+у нап+исано
        выполн+яю в+ыполнен в+ыполнено в+ыполнить в+ыполни в+ыполнена
        п+онял понял+а пон+ятно пон+ять
        ком+анда ком+анду ком+анды ком+анд ком+андой
        д+оступ д+оступа д+оступу дост+упно дост+упности
        сл+ужба сл+ужбу сл+ужбы
        разреш+ите разреш+ение разреш+ения разреш+ений разреш+ить
        н+ужно нужн+ы нужн+а
        настр+ойки настр+ойка настр+ойках настр+оек настр+ойку
        прилож+ение прилож+ения прилож+ений прилож+ению прилож+ением
        ф+айлы файл+ам файл+ов
        п+апка п+апку п+апки п+апке п+апок
        фонар+ик фонар+ика фонар+ику
        тон+альность тон+альности сбр+ошена сбр+ошен сбр+ошено сбр+осить
        сист+ема сист+емы сист+ем сист+емах н+орме н+орма
        дж+арвис в+ашим в+ашей в+аш усл+угам усл+уги усл+уга усл+угами
        ош+ибка ош+ибки ош+ибку ош+ибок
        конт+акт конт+акты конт+акта конт+акте конт+актов конт+актом
        уточн+ите назов+ите скаж+ите ком+у как+ой как+ое как+ие
        верх+овный реж+им п+олного п+олный ключ+а введ+ите п+оиск лок+альный
        пров+ерка провер+яю пров+ерить раб+отает раб+отаю раб+ота раб+оты
        хорош+о прив+ет здр+авствуйте здр+авствуй пож+алуйста спас+ибо
        провод+ника провод+ник установ+ите установ+ить вручн+ую хран+илище
        отказ+ала отказ+ал д+ействии д+ействие д+ействия
        удал+ось гот+ово сл+ушаю
        в+ыход
        галер+ея к+амера к+амеру
        сообщ+ение сообщ+ения сообщ+ений сообщ+ить
        д+обрый д+оброе д+обрая добр+о в+ечер вчер+а сейч+ас теп+ерь з+автра +утро
        сл+едующий предыд+ущий н+овый н+овая н+овое
        пол+ьзователь пол+ьзователя пол+ьзователю
        загруж+аю загруж+ен загруж+ена
        ист+ория ист+ории
        м+узыка м+узыку м+узыки
        телеф+он телеф+она телеф+оны
        интерн+ет интерн+ета
        п+омощь п+омощи
        н+овости н+овость
        пог+ода пог+оду
        вр+емя врем+ени дел+а д+ело д+елать д+елаю д+елает
        н+омер н+омера
        т+очка запят+ая
    """
}
