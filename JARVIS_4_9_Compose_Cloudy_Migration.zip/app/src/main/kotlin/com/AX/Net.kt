package com.AX

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Результат HTTP-вызова. [error] != null — до сервера не дошли (сеть, DNS, таймаут); [code] тогда -1. */
data class HttpResult(val code: Int, val body: String, val error: String? = null) {
    val ok: Boolean get() = error == null && code in 200..299
}

/**
 * Сетевой слой «Верховного суда»: OkHttp, маскировка под мобильный браузер,
 * таймауты под WARP и собственный DNS (не зависит от системного резолвера телефона).
 */
object Net {

    const val USER_AGENT =
        "Mozilla/5.0 (Linux; Android 11; OPPO A54) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/120.0.0.0 Mobile Safari/537.36"
    private const val REFERER = "https://github.com"
    private const val TITLE = "Jarvis Voice Assistant Mobile"

    /** Яндекс.DNS (базовый). */
    private val DNS_SERVERS = listOf("77.88.8.8", "77.88.8.1")

    /** Инициализация клиента: таймауты, свой DNS. */
    fun createClient(): OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .callTimeout(35, TimeUnit.SECONDS)
        .dns(FallbackDns(DNS_SERVERS))
        .retryOnConnectionFailure(true)
        .build()

    val client: OkHttpClient by lazy { createClient() }

    /** Обязательный набор заголовков «как из браузера OPPO A54». */
    private fun Request.Builder.browserHeaders(apiKey: String): Request.Builder =
        header("User-Agent", USER_AGENT)
            .header("HTTP-Referer", REFERER)
            .header("X-Title", TITLE)
            .header("Accept", "application/json")
            .header("Authorization", "Bearer $apiKey")

    /** POST JSON. Не бросает исключений (кроме отмены корутины): сбои возвращаются в [HttpResult.error]. */
    suspend fun postJson(url: String, json: String, apiKey: String): HttpResult =
        withContext(Dispatchers.IO) {
            try {
                // Без charset в типе: заголовок уйдёт ровно «application/json».
                val body = json.toByteArray(Charsets.UTF_8).toRequestBody("application/json".toMediaType())
                val req = Request.Builder().url(url).browserHeaders(apiKey).post(body).build()
                client.newCall(req).await().use { HttpResult(it.code, it.body?.string().orEmpty()) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                failure(e)
            }
        }

    /** GET (проверка ключа). Тот же клиент и заголовки. */
    suspend fun get(url: String, apiKey: String): HttpResult =
        withContext(Dispatchers.IO) {
            try {
                val req = Request.Builder().url(url).browserHeaders(apiKey).get().build()
                client.newCall(req).await().use { HttpResult(it.code, it.body?.string().orEmpty()) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                failure(e)
            }
        }

    private fun failure(e: Throwable): HttpResult {
        val text = when (e) {
            is UnknownHostException -> "DNS не нашёл ${e.message ?: "хост"} (проверьте интернет/WARP)"
            is SocketTimeoutException -> "таймаут соединения (${e.message ?: "нет ответа"})"
            is javax.net.ssl.SSLException -> "ошибка TLS: ${e.message}"
            is IOException -> "сеть: ${e.javaClass.simpleName}: ${e.message}"
            else -> "${e.javaClass.simpleName}: ${e.message}"
        }
        return HttpResult(-1, "", text)
    }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation { runCatching { cancel() } }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (!cont.isCancelled) cont.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: Response) {
                cont.resume(response) { response.close() }
            }
        })
    }

    // ---------------- DNS ----------------

    /**
     * Резолвер: сначала прямые UDP-запросы A-записей к Яндекс.DNS (77.88.8.8 / 77.88.8.1),
     * затем системный DNS как запасной. Адреса объединяются: OkHttp перебирает их по очереди.
     * Результат кэшируется на 5 минут.
     */
    class FallbackDns(private val servers: List<String>) : Dns {
        private class Entry(val at: Long, val addrs: List<InetAddress>)

        private val cache = ConcurrentHashMap<String, Entry>()

        override fun lookup(hostname: String): List<InetAddress> {
            cache[hostname]?.let { if (System.currentTimeMillis() - it.at < 300_000) return it.addrs }

            val out = LinkedHashSet<InetAddress>()
            for (server in servers) {
                try {
                    val found = queryA(hostname, server)
                    if (found.isNotEmpty()) {
                        out.addAll(found)
                        AppLog.add("API", "DNS $hostname → ${found.joinToString { it.hostAddress ?: "?" }} ($server)")
                        break
                    }
                } catch (e: Exception) {
                    AppLog.add("ERR", "DNS $server: ${e.javaClass.simpleName}: ${e.message}")
                }
            }
            try {
                out.addAll(Dns.SYSTEM.lookup(hostname))
            } catch (e: Exception) {
                if (out.isEmpty()) throw UnknownHostException("$hostname: ${e.message}")
            }
            val list = out.toList()
            cache[hostname] = Entry(System.currentTimeMillis(), list)
            return list
        }

        /** Один UDP-запрос типа A. Бросает исключение при таймауте/битом ответе. */
        private fun queryA(host: String, server: String): List<InetAddress> {
            val id = SecureRandom().nextInt(0x10000)
            val q = java.io.ByteArrayOutputStream()
            fun u16(v: Int) { q.write(v shr 8 and 0xFF); q.write(v and 0xFF) }
            u16(id); u16(0x0100); u16(1); u16(0); u16(0); u16(0)   // заголовок: RD=1, один вопрос
            for (label in host.split('.')) {
                val b = label.toByteArray(Charsets.US_ASCII)
                q.write(b.size); q.write(b)
            }
            q.write(0); u16(1); u16(1)                              // тип A, класс IN
            val req = q.toByteArray()

            DatagramSocket().use { sock ->
                sock.soTimeout = 3000
                val addr = InetAddress.getByName(server)
                sock.send(DatagramPacket(req, req.size, addr, 53))
                val buf = ByteArray(1500)
                val resp = DatagramPacket(buf, buf.size)
                sock.receive(resp)
                return parse(buf, resp.length, id, host)
            }
        }

        private fun parse(b: ByteArray, len: Int, id: Int, host: String): List<InetAddress> {
            if (len < 12) throw IOException("короткий ответ DNS")
            fun u16(p: Int) = (b[p].toInt() and 0xFF shl 8) or (b[p + 1].toInt() and 0xFF)
            if (u16(0) != id) throw IOException("чужой id в ответе DNS")
            if ((u16(2) and 0x000F) != 0) throw IOException("DNS rcode=${u16(2) and 0x000F}")
            val qd = u16(4)
            val an = u16(6)
            var p = 12
            fun skipName() {
                while (p < len) {
                    val l = b[p].toInt() and 0xFF
                    if (l == 0) { p += 1; return }
                    if (l and 0xC0 == 0xC0) { p += 2; return }
                    p += l + 1
                }
            }
            repeat(qd) { skipName(); p += 4 }
            val res = ArrayList<InetAddress>()
            repeat(an) {
                if (p >= len) return@repeat
                skipName()
                val type = u16(p)
                val rdLen = u16(p + 8)
                p += 10
                if (type == 1 && rdLen == 4 && p + 4 <= len) {
                    res.add(InetAddress.getByAddress(host, b.copyOfRange(p, p + 4)))
                }
                p += rdLen
            }
            return res
        }
    }
}
