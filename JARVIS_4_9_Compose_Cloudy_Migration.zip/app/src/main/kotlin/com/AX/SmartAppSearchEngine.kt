package com.AX

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

data class AppInfo(val label: String, val pkg: String, val system: Boolean = false, val cls: String? = null)

data class SearchResult(val app: AppInfo, val score: Float, val source: String = "")

/**
 * Предрассчитанная модель приложения. Триграммы лежат в отсортированных [IntArray]
 * (хэши), а не в списках строк, чтобы не нагружать GC.
 *
 * [forms] — все написания названия (оригинал, латиница, кириллица, звучание из
 * [SmartAppSearchEngine.hardcodedSounds], без пробелов) и отдельные слова названия.
 */
class AppIndexModel(
    val app: AppInfo,
    val forms: Array<String>,
    val isToken: BooleanArray,
    val trigrams: Array<IntArray>,
    val phonetics: IntArray
)

/**
 * Гибридный поиск приложения по распознанной фразе.
 *
 * Каскад [search]:
 *  0. режим полного ключа ([Prefs.keyOnly]): сразу «Верховный суд», локальный поиск не используется;
 *  1. категории («мессенджер», «видеохостинг») → первое установленное пользовательское приложение;
 *  2. локальный поиск по ПОЛЬЗОВАТЕЛЬСКИМ приложениям: очистка фразы → варианты написания
 *     (translit, созвучия) → стемминг → бакеты первой буквы → оценка (прямое совпадение,
 *     взвешенный Дамерау-Левенштейн, триграммы, фонетический хэш);
 *  3. системные фразы ([SYSTEM_PHRASES]) и локальный поиск по СИСТЕМНЫМ приложениям;
 *  4. если локально null — фоновый вызов «Верховного суда» ([SupremeCourt], OpenRouter).
 *
 * Слова-команды «открой / запусти / старт» проверяет [Commands], сюда приходит уже название.
 */
class SmartAppSearchEngine {

    private class Snapshot(
        val models: Array<AppIndexModel>,
        val buckets: HashMap<Char, IntArray>,
        val exact: HashMap<String, Int>
    )

    private class QForm(val text: String, val trigrams: IntArray, val phonetic: Int)

    @Volatile
    private var userSnap = Snapshot(emptyArray(), HashMap(), HashMap())

    @Volatile
    private var sysSnap = Snapshot(emptyArray(), HashMap(), HashMap())

    val isReady: Boolean get() = userSnap.models.isNotEmpty() || sysSnap.models.isNotEmpty()

    /** Контекст приложения: нужен, чтобы спрашивать у системы, какое приложение выполняет роль («галерея», «камера»...). */
    @Volatile
    private var appCtx: Context? = null

    fun attach(ctx: Context) { appCtx = ctx.applicationContext }

    /** Роль (галерея, камера, телефон...), которую подразумевает фраза; null — это не общее слово функции. */
    private fun roleOf(core: String): AppRoles.Role? = AppRoles.match(core, this)

    /** Приложение, которое сама система назначила на роль. Не зависит от названия на ярлыке. */
    private fun roleApp(core: String): SearchResult? {
        val ctx = appCtx ?: return null
        val role = roleOf(core) ?: return null
        val app = AppRoles.resolve(ctx, role) ?: return null
        return SearchResult(app, 1f, "role")
    }

    /** Подсказка для ИИ: «галерея → Фотоснимки». Локальное решение не принимается, только подсказка. */
    private fun roleHint(core: String): String? {
        val role = roleOf(core) ?: return null
        val ctx = appCtx ?: return null
        val app = AppRoles.resolve(ctx, role) ?: return null
        return "Функция «${role.title}» выполняется приложением «${app.label}»"
    }

    /** Варианты написания фразы (оригинал, translit, созвучия, стемминг): для имён папок и контактов. */
    fun variantsOf(text: String): List<String> = expandVariants(normalize(text))

    /** Схожесть произнесённого слова/фразы и имени (контакт, папка), 0..1. */
    fun similarity(spoken: String, name: String): Float {
        val q = expandVariants(normalize(spoken)).map { QForm(it, trigramsOf(it), phoneticHash(it)) }
        if (q.isEmpty()) return 0f
        val m = buildModel(AppInfo(name, "")) ?: return 0f
        return scoreModel(q, m)
    }

    /** Все приложения для «Верховного суда»: сначала пользовательские (при одинаковом названии побеждают они). */
    private fun allApps(): List<AppInfo> =
        userSnap.models.map { it.app } + sysSnap.models.map { it.app }

    /** Тяжёлая индексация: запускайте из корутины, работает на Dispatchers.Default. */
    suspend fun buildIndex(apps: List<AppInfo>) = withContext(Dispatchers.Default) {
        indexAppsBlocking(apps)
    }

    /** То же самое без корутин (для вызова из рабочего потока). */
    fun indexAppsBlocking(apps: List<AppInfo>) {
        val (sys, user) = apps.partition { it.system }
        userSnap = buildSnapshot(user)
        sysSnap = buildSnapshot(sys)
    }

    // ================= Поиск =================

    /**
     * Полный каскад поиска (см. описание класса). Приостанавливаемая: локальная часть идёт
     * в Dispatchers.Default, сетевая («Верховный суд») — в Dispatchers.IO, UI не блокируется.
     */
    suspend fun search(userInput: String, useAi: Boolean = true): SearchResult? = withContext(Dispatchers.Default) {
        val core = extractCore(userInput)
        if (core.isEmpty()) return@withContext null

        // Режим полного ключа: только API, без локальных догадок.
        if (Prefs.keyOnly) {
            if (!useAi) return@withContext null
            AppLog.add("SEARCH", "«$core»: режим полного ключа, сразу API")
            return@withContext askCourt(core, roleHint(core))
        }

        // 1. Категории: «мессенджер», «видеохостинг» → установленное приложение пользователя.
        val category = categoryOf(core)
        if (category != null) {
            val hit = categoryApp(category)
            if (hit != null) {
                AppLog.add("SEARCH", "«$core» → ${hit.app.label} (категория, пользовательское)")
                return@withContext hit
            }
        }

        // 2a. Точное название среди пользовательских приложений.
        if (category == null) {
            exactLocal(userSnap, core)?.let {
                AppLog.add("SEARCH", "«$core» → ${it.app.label} (точное название)")
                return@withContext it.copy(source = "user")
            }
            // 2b. Общее слово функции («фото», «камера», «контакты»): приложение назначает сама система.
            roleApp(core)?.let {
                AppLog.add("SEARCH", "«$core» → ${it.app.label} (роль в системе)")
                return@withContext it
            }
        }

        // 2c. Пользовательские приложения — всегда раньше системных.
        if (category == null) {
            searchLocal(userSnap, core)?.let {
                AppLog.add("SEARCH", "«$core» → ${it.app.label} (пользовательское, ${"%.2f".format(Locale.US, it.score)})")
                return@withContext it.copy(source = "user")
            }
            // 3. Системные: фразы ассистента, затем обычный поиск по системным пакетам.
            resolveSystem(core)?.let {
                AppLog.add("SEARCH", "«$core» → ${it.app.label} (системное, по фразе)")
                return@withContext it
            }
            searchLocal(sysSnap, core)?.let {
                AppLog.add("SEARCH", "«$core» → ${it.app.label} (системное, ${"%.2f".format(Locale.US, it.score)})")
                return@withContext it.copy(source = "system")
            }
        }

        // 4. ИИ-резерв.
        if (!useAi) return@withContext null
        askCourt(core, roleHint(core))
    }

    private suspend fun askCourt(core: String, hint: String? = null): SearchResult? {
        val app = SupremeCourt.judge(core, rankedApps(core), hint) ?: return null
        AppLog.add("SEARCH", "«$core» → ${app.label} (API)")
        return SearchResult(app, COURT_SCORE, "api")
    }

    // ---- Категории ----

    private fun categoryOf(core: String): String? {
        val flat = core.replace(" ", "")
        return CATEGORY_KEYS.entries.firstOrNull { (k, _) -> flat.startsWith(k) }?.value
    }

    /** Первое установленное ПОЛЬЗОВАТЕЛЬСКОЕ приложение категории (порядок списка = приоритет). */
    private fun categoryApp(category: String): SearchResult? {
        val s = userSnap
        for (pkg in CATEGORY_PACKAGES[category] ?: return null) {
            val m = s.models.firstOrNull { it.app.pkg == pkg } ?: continue
            return SearchResult(m.app, 1f, "category")
        }
        return null
    }

    /**
     * Находит приложение по названию и запускает его через PackageManager
     * ([PackageManager.getLaunchIntentForPackage]). Блокирующий: вызывайте НЕ из UI-потока.
     */
    fun launchApp(context: Context, appName: String): Boolean {
        val hit = runBlocking { search(appName) } ?: return false
        return launchPackage(context, hit.app.pkg)
    }

    /** Запуск пакета (с запасными пакетами для системных). false — нет экрана запуска. */
    fun launchPackage(context: Context, pkg: String, cls: String? = null): Boolean {
        val pm = context.packageManager
        if (cls != null) {
            try {
                context.startActivity(
                    android.content.Intent(android.content.Intent.ACTION_MAIN)
                        .setClassName(pkg, cls)
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                return true
            } catch (e: Exception) {
            }
        }
        for (p in listOf(pkg) + (SYSTEM_FALLBACKS[pkg] ?: emptyList())) {
            val intent = pm.getLaunchIntentForPackage(p) ?: continue
            try {
                context.startActivity(intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                return true
            } catch (e: Exception) {
            }
        }
        return false
    }

    /** Системные пакеты, установленные на устройстве (нужны индексу, даже если нет иконки в лаунчере). */
    fun systemApps(pm: PackageManager): List<AppInfo> {
        val out = ArrayList<AppInfo>()
        for (pkg in SYSTEM_LABELS.keys + SYSTEM_FALLBACKS.values.flatten()) {
            try {
                val info = pm.getApplicationInfo(pkg, 0)
                out.add(AppInfo(pm.getApplicationLabel(info).toString(), pkg, true))
            } catch (e: PackageManager.NameNotFoundException) {
            }
        }
        return out
    }

    private fun resolveSystem(core: String): SearchResult? {
        val pkg = SYSTEM_PHRASES[core] ?: SYSTEM_PHRASES[core.replace(" ", "")] ?: return null
        return SearchResult(AppInfo(SYSTEM_LABELS[pkg] ?: core, pkg, true), 1f, "system")
    }

    /** Только точное совпадение названия (с учётом translit/созвучий/стемминга), без нечёткой оценки. */
    private fun exactLocal(s: Snapshot, userInput: String): SearchResult? {
        if (s.models.isEmpty()) return null
        for (v in expandVariants(extractCore(userInput))) {
            s.exact[v]?.let { return SearchResult(s.models[it].app, 1f) }
        }
        return null
    }

    /**
     * Список для ИИ: приложения, похожие на запрос, идут первыми (иначе нужное может не влезть в лимит
     * длины списка и модель его просто не увидит). Только порядок — решение остаётся за моделью.
     */
    private fun rankedApps(core: String): List<AppInfo> {
        val all = allApps()
        val q = expandVariants(core).map { QForm(it, trigramsOf(it), phoneticHash(it)) }
        if (q.isEmpty()) return all
        val scores = HashMap<String, Float>()
        for (s in listOf(userSnap, sysSnap)) for (m in s.models) scores[m.app.pkg] = scoreModel(q, m)
        return all.sortedByDescending { scores[it.pkg] ?: 0f }
    }

    /** Локальный поиск (без сети). Работает по бакету первой буквы. */
    private fun searchLocal(s: Snapshot, userInput: String): SearchResult? {
        if (s.models.isEmpty()) return null
        val core = extractCore(userInput)
        if (core.isEmpty()) return null

        val queries = expandVariants(core).map { QForm(it, trigramsOf(it), phoneticHash(it)) }
        if (queries.isEmpty()) return null

        // Мгновенное попадание по хэш-таблице.
        for (q in queries) {
            s.exact[q.text]?.let { return SearchResult(s.models[it].app, 1f) }
        }

        // Кандидаты из бакетов первых букв всех вариантов запроса.
        val seen = BooleanArray(s.models.size)
        var best = -1
        var bestScore = 0f
        for (q in queries) {
            val bucket = s.buckets[q.text[0]] ?: continue
            for (idx in bucket) {
                if (seen[idx]) continue
                seen[idx] = true
                val sc = scoreModel(queries, s.models[idx])
                if (sc > bestScore || (sc == bestScore && best >= 0 &&
                            s.models[idx].app.label.length < s.models[best].app.label.length)
                ) {
                    best = idx; bestScore = sc
                }
            }
        }
        // Запасной проход, если в бакетах ничего не нашлось (приложений обычно сотни).
        if (bestScore < THRESHOLD) {
            for (idx in s.models.indices) {
                if (seen[idx]) continue
                val sc = scoreModel(queries, s.models[idx])
                if (sc > bestScore) { best = idx; bestScore = sc }
            }
        }
        return if (best >= 0 && bestScore >= THRESHOLD) SearchResult(s.models[best].app, bestScore) else null
    }

    private fun scoreModel(queries: List<QForm>, m: AppIndexModel): Float {
        var best = 0f
        for (q in queries) {
            for (i in m.forms.indices) {
                var sc = pairScore(q, m, i)
                if (m.isToken[i]) sc *= 0.92f
                if (sc > best) best = sc
            }
        }
        return best
    }

    private fun pairScore(q: QForm, m: AppIndexModel, i: Int): Float {
        val f = m.forms[i]
        val qt = q.text
        if (qt == f) return 1f

        // Короткие слова (< 4 символов): без стемминга, триграмм и фонетики —
        // только прямое совпадение и Дамерау-Левенштейн.
        if (min(qt.length, f.length) < 4) {
            val d = weightedDl(qt, f)
            return if (d <= 1f) 0.9f - 0.2f * d else 0f
        }

        var s = 0f
        val ratio = min(qt.length, f.length) / max(qt.length, f.length).toFloat()
        if (f.startsWith(qt) || qt.startsWith(f)) {
            // Запрос — начало одного слова названия («фото» → «фотоснимки»): хорошее совпадение,
            // но слабее точного. Категории вроде «видеохостинг» обрабатываются отдельно (CATEGORY_KEYS).
            s = if (ratio >= 0.6f) 0.8f + 0.1f * ratio
            else if (min(qt.length, f.length) >= 4 && !qt.contains(' ') && !f.contains(' ')) 0.66f + 0.2f * ratio
            else 0.5f * ratio
        } else if (f.contains(qt) || qt.contains(f)) {
            s = if (ratio >= 0.6f) 0.75f else 0.5f * ratio
        }
        val dl = 1f - weightedDl(qt, f) / max(qt.length, f.length)
        val tri = dice(q.trigrams, m.trigrams[i])
        s = max(s, 0.5f * dl + 0.5f * tri)

        if (q.phonetic != 0 && q.phonetic == m.phonetics[i]) s = max(s, 0.85f)
        return s
    }

    // ================= Индексация =================

    private fun buildSnapshot(apps: List<AppInfo>): Snapshot {
        val models = ArrayList<AppIndexModel>(apps.size)
        val lists = HashMap<Char, ArrayList<Int>>()
        val exact = HashMap<String, Int>()
        for (app in apps) {
            val model = buildModel(app) ?: continue
            val idx = models.size
            models.add(model)

            // Бакеты: первая буква формы + все созвучные начальные согласные (К/Г, Б/П, Д/Т, З/С, А/О ...).
            val firsts = HashSet<Char>()
            for (f in model.forms) {
                val c = f.firstOrNull() ?: continue
                firsts.add(c)
                SOUND_GROUP[c]?.forEach { firsts.add(it) }
            }
            for (c in firsts) lists.getOrPut(c) { ArrayList() }.add(idx)

            for (i in model.forms.indices) if (!model.isToken[i]) exact.putIfAbsent(model.forms[i], idx)
        }
        val buckets = HashMap<Char, IntArray>(lists.size * 2)
        for ((c, l) in lists) buckets[c] = l.toIntArray()
        return Snapshot(models.toTypedArray(), buckets, exact)
    }

    private fun buildModel(app: AppInfo): AppIndexModel? {
        val base = normalize(app.label)
        if (base.isEmpty()) return null
        val full = expandVariants(base)

        val forms = ArrayList<String>()
        val tokenFlags = ArrayList<Boolean>()
        val seen = HashSet<String>()
        for (f in full) if (seen.add(f)) { forms.add(f); tokenFlags.add(false) }
        for (f in full) {
            for (t in f.split(' ')) {
                if (t.length >= 2 && t != f && seen.add(t)) { forms.add(t); tokenFlags.add(true) }
            }
        }
        val tri = Array(forms.size) { trigramsOf(forms[it]) }
        val ph = IntArray(forms.size) { phoneticHash(forms[it]) }
        return AppIndexModel(app, forms.toTypedArray(), tokenFlags.toBooleanArray(), tri, ph)
    }

    // ================= NER: суть команды =================

    /** Убирает слова-паразиты («пожалуйста», «приложение» ...) и оставляет название. */
    fun extractCore(input: String): String =
        normalize(input).split(' ').filter { it.isNotEmpty() && it !in STOP_WORDS }.joinToString(" ")

    fun normalize(s: String): String =
        s.lowercase(Locale.ROOT).replace('ё', 'е').replace(NON_WORD, " ").trim().replace(MANY_SPACES, " ")

    // ================= Варианты написания =================

    /** Все написания строки: оригинал, звучание из словаря, латиница, кириллица; кириллица со стеммингом. */
    private fun expandVariants(text: String): List<String> {
        val seeds = LinkedHashSet<String>()
        seeds.add(text)
        hardcodedSounds[text]?.let { seeds.add(it) }
        val words = text.split(' ')
        if (words.size > 1 && words.any { hardcodedSounds.containsKey(it) }) {
            seeds.add(words.joinToString(" ") { hardcodedSounds[it] ?: it })
        }

        val out = LinkedHashSet<String>()
        for (seed in seeds) {
            out.add(seed)
            if (seed.any(::isCyr)) {
                val lat = toLatin(seed)
                out.add(lat)
                if (lat.contains("ks")) out.add(lat.replace("ks", "x"))
            }
            if (seed.any(::isLat)) out.add(toCyrillic(seed))
        }
        val stemmed = LinkedHashSet<String>()
        for (v in out) stemmed.add(stemTokens(v))
        for (v in stemmed.toList()) if (v.contains(' ')) stemmed.add(v.replace(" ", ""))
        return stemmed.filter { it.isNotEmpty() }
    }

    // ================= Стемминг =================

    fun stemTokens(s: String): String =
        if (s.none(::isCyr)) s else s.split(' ').joinToString(" ") { stem(it) }

    /** Срезает падежные окончания. Слова короче 4 букв не трогаем. */
    private fun stem(w: String): String {
        if (w.length < 4 || w.none(::isCyr)) return w
        for (suf in SUFFIXES) {
            if (w.length - suf.length >= 3 && w.endsWith(suf)) return w.substring(0, w.length - suf.length)
        }
        return w
    }

    // ================= Триграммы =================

    private fun trigramsOf(s: String): IntArray {
        if (s.length < 4) return EMPTY
        val n = s.length - 2
        val arr = IntArray(n)
        for (i in 0 until n) arr[i] = (s[i].code * 31 + s[i + 1].code) * 31 + s[i + 2].code
        arr.sort()
        return arr
    }

    /** Коэффициент Дайса по отсортированным хэш-массивам. */
    private fun dice(a: IntArray, b: IntArray): Float {
        if (a.isEmpty() || b.isEmpty()) return 0f
        var i = 0
        var j = 0
        var inter = 0
        while (i < a.size && j < b.size) {
            when {
                a[i] == b[j] -> { inter++; i++; j++ }
                a[i] < b[j] -> i++
                else -> j++
            }
        }
        return 2f * inter / (a.size + b.size)
    }

    // ================= Дамерау-Левенштейн (взвешенный) =================

    /**
     * Вставка/удаление = 1, замена созвучных букв = 0.4, остальная замена = 1,
     * перестановка соседних букв = 0.7.
     */
    private fun weightedDl(a: String, b: String): Float {
        if (a == b) return 0f
        if (a.isEmpty()) return b.length.toFloat()
        if (b.isEmpty()) return a.length.toFloat()
        var prev2 = FloatArray(b.length + 1)
        var prev = FloatArray(b.length + 1) { it.toFloat() }
        var cur = FloatArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i.toFloat()
            for (j in 1..b.length) {
                val sub = when {
                    a[i - 1] == b[j - 1] -> 0f
                    similar(a[i - 1], b[j - 1]) -> 0.4f
                    else -> 1f
                }
                var v = min(min(prev[j] + 1f, cur[j - 1] + 1f), prev[j - 1] + sub)
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) {
                    v = min(v, prev2[j - 2] + 0.7f)
                }
                cur[j] = v
            }
            val t = prev2; prev2 = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    private fun similar(x: Char, y: Char): Boolean {
        val g = SOUND_GROUP[x] ?: return false
        return g.indexOf(y) >= 0
    }

    // ================= Билингвальный Metaphone =================

    /**
     * Фонетический код: кириллица транслитерируется, затем гласные отбрасываются,
     * звонкие → глухие, c/k/q/g → k, ph → f, sh/zh/sch → S. «Клод», «Глод» и «Claude» → «klt».
     * Для слов короче 4 символов не считается (0).
     */
    private fun phoneticHash(form: String): Int {
        val flat = form.replace(" ", "")
        if (flat.length < 4) return 0
        val lat = toLatin(flat)
        val sb = StringBuilder()
        fun put(c: Char) { if (sb.isEmpty() || sb[sb.length - 1] != c) sb.append(c) }
        var i = 0
        while (i < lat.length) {
            val c = lat[i]
            val n = if (i + 1 < lat.length) lat[i + 1] else ' '
            val n2 = if (i + 2 < lat.length) lat[i + 2] else ' '
            when {
                c == 's' && n == 'c' && n2 == 'h' -> { put('S'); i += 3; continue }
                c == 's' && n == 'h' || c == 'z' && n == 'h' -> { put('S'); i += 2; continue }
                c == 'c' && n == 'h' -> { put('C'); i += 2; continue }
                c == 'p' && n == 'h' -> { put('f'); i += 2; continue }
                c == 'k' && n == 'h' -> { put('h'); i += 2; continue }
                c == 'c' && n == 'k' -> { put('k'); i += 2; continue }
                c == 'c' && (n == 'e' || n == 'i' || n == 'y') -> put('s')
                c == 'c' || c == 'q' || c == 'g' || c == 'k' -> put('k')
                c == 'x' -> { put('k'); put('s') }
                c == 'w' || c == 'v' || c == 'f' -> put('f')
                c == 'b' || c == 'p' -> put('p')
                c == 'd' || c == 't' -> put('t')
                c == 'z' || c == 's' -> put('s')
                c in "aeiouy" -> if (sb.isEmpty()) put('a')
                c.isLetterOrDigit() -> put(c)
            }
            i++
        }
        if (sb.length < 3) return 0
        val h = sb.toString().hashCode()
        return if (h == 0) 1 else h
    }

    // ================= Транслитерация =================

    private fun isCyr(c: Char) = c in 'а'..'я' || c == 'ё'
    private fun isLat(c: Char) = c in 'a'..'z'

    private fun toLatin(s: String): String {
        val sb = StringBuilder()
        for (c in s) sb.append(RU2LAT[c] ?: c.toString())
        return sb.toString()
    }

    private fun toCyrillic(s: String): String {
        val sb = StringBuilder()
        var i = 0
        outer@ while (i < s.length) {
            for ((k, v) in LAT2RU_MULTI) {
                if (s.startsWith(k, i)) { sb.append(v); i += k.length; continue@outer }
            }
            val c = s[i]
            if (c == 'c' && i + 1 < s.length && s[i + 1] in "eiy") sb.append('с')
            else sb.append(LAT2RU[c] ?: c.toString())
            i++
        }
        return sb.toString()
    }

    // ================= Данные =================

    /** Ручные созвучия (в обе стороны): «claude» ↔ «клод», «youtube» ↔ «ютуб». */
    val hardcodedSounds: Map<String, String> = HashMap<String, String>().also { m ->
        val pairs = listOf(
            "claude" to "клод", "youtube" to "ютуб", "whatsapp" to "ватсап", "telegram" to "телеграм",
            "instagram" to "инстаграм", "chrome" to "хром", "google" to "гугл", "gmail" to "джимейл",
            "tiktok" to "тикток", "viber" to "вайбер", "skype" to "скайп", "zoom" to "зум",
            "spotify" to "спотифай", "netflix" to "нетфликс", "discord" to "дискорд",
            "yandex" to "яндекс", "alice" to "алиса", "sberbank" to "сбербанк", "max" to "макс",
            "vk" to "вк", "ok" to "ок", "twitter" to "твиттер", "facebook" to "фейсбук",
            "chatgpt" to "чатгпт", "gemini" to "джемини", "firefox" to "фаерфокс", "opera" to "опера",
            "camera" to "камера", "settings" to "настройки", "calculator" to "калькулятор",
            "clock" to "часы", "gallery" to "галерея", "contacts" to "контакты", "phone" to "телефон",
            "messages" to "сообщения", "mail" to "почта", "maps" to "карты", "music" to "музыка",
            "browser" to "браузер", "files" to "файлы", "calendar" to "календарь", "notes" to "заметки",
            "weather" to "погода", "store" to "магазин", "photos" to "фото", "recorder" to "диктофон",
            "play market" to "плей маркет", "play store" to "плей маркет", "drive" to "диск",
            "translate" to "переводчик", "taxi" to "такси", "bank" to "банк"
        )
        for ((en, ru) in pairs) { m[en] = ru; m[ru] = en }

        // Системные пакеты Android: com.google.android.packageinstaller
        // («Package installer» / «Установщик пакетов») и односторонние синонимы.
        m["package installer"] = "установщик пакетов"
        m["установщик пакетов"] = "package installer"
        for (alias in listOf(
            "менеджер пакетов", "установщик приложений", "установщик", "package manager", "packageinstaller"
        )) m[alias] = "package installer"
    }

    /** Начало слова (без пробелов) → категория. «видео хостинг» / «видеохостинг» / «мессенджер». */
    private val CATEGORY_KEYS = linkedMapOf(
        "видеохостинг" to "video",
        "видеохостинга" to "video",
        "мессенджер" to "messenger",
        "месенджер" to "messenger",
        "мессенжер" to "messenger"
    )

    /** Категория → пакеты по приоритету (берётся первый установленный пользовательский). */
    private val CATEGORY_PACKAGES = mapOf(
        "video" to listOf(
            "com.google.android.youtube", "app.revanced.android.youtube", "com.vanced.android.youtube",
            "ru.rutube.app", "com.vk.vkvideo", "com.google.android.apps.youtube.music"
        ),
        "messenger" to listOf(
            "org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram",
            "com.whatsapp", "com.whatsapp.w4b", "ru.oneme.app", "com.viber.voip",
            "com.vkontakte.android", "com.discord", "org.thoughtcrime.securesms"
        )
    )

    /** Системные фразы: проверяются ПОСЛЕ пользовательских приложений, но раньше системного нечёткого поиска. */
    private val SYSTEM_PHRASES: Map<String, String> = HashMap<String, String>().also { m ->
        fun put(pkg: String, vararg phrases: String) { for (p in phrases) m[p] = pkg }
        put(
            "com.google.android.packageinstaller",
            "установщик пакетов", "установщика пакетов", "менеджер пакетов", "менеджера пакетов",
            "установщик приложений", "установщик", "package installer", "packageinstaller", "package manager"
        )
        put("com.android.settings", "настройки", "настройки телефона", "settings")
        put("com.android.vending", "плей маркет", "плэй маркет", "гугл плей", "google play", "play market", "play store")
    }

    private val SYSTEM_LABELS = mapOf(
        "com.google.android.packageinstaller" to "Установщик пакетов",
        "com.android.settings" to "Настройки",
        "com.android.vending" to "Play Маркет"
    )

    /** На AOSP-прошивках установщик живёт в другом пакете. */
    private val SYSTEM_FALLBACKS = mapOf(
        "com.google.android.packageinstaller" to listOf("com.android.packageinstaller")
    )

    private companion object {
        const val THRESHOLD = 0.62f
        const val COURT_SCORE = 0.7f
        val EMPTY = IntArray(0)
        val NON_WORD = Regex("[^\\p{L}\\p{N}]+")
        val MANY_SPACES = Regex("\\s+")

        val STOP_WORDS = hashSetOf(
            // Команды запуска («открой», «запусти», «старт») здесь НЕ чистятся: их проверяет
            // Commands.appQuery, а сюда приходит уже только название приложения.
            "пожалуйста", "пожалуй", "плиз", "пж", "приложение", "приложуха",
            "программа", "программу", "мне", "ну", "давай", "джарвис", "будь", "добр", "добра",
            "быстро", "срочно", "сейчас", "в", "на", "по", "ка", "мой", "мою", "мои", "моё", "мое", "а", "и",
            "please", "app", "the"
        )

        // От длинных окончаний к коротким.
        val SUFFIXES = listOf(
            "ами", "ями", "ого", "его", "ому", "ему", "ыми", "ими", "ах", "ях", "ам", "ям", "ом", "ем",
            "ой", "ей", "ый", "ий", "ая", "яя", "ое", "ее", "ов", "ев", "ую", "юю", "ою", "ею",
            "у", "ю", "а", "я", "ы", "и", "е", "о", "ь", "й"
        )

        /** Группы созвучных букв (кириллица и латиница вместе). */
        val SOUND_GROUP: Map<Char, String> = HashMap<Char, String>().also { m ->
            for (g in listOf("кгckgqхh", "бпbp", "дтdt", "зсzsc", "аоao", "вwvфf", "иеiey")) {
                for (c in g) m[c] = g
            }
        }

        val RU2LAT = mapOf(
            'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ж' to "zh",
            'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n",
            'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f",
            'х' to "h", 'ц' to "c", 'ч' to "ch", 'ш' to "sh", 'щ' to "sh", 'ъ' to "", 'ы' to "y",
            'ь' to "", 'э' to "e", 'ю' to "yu", 'я' to "ya"
        )
        val LAT2RU_MULTI = listOf(
            "sch" to "щ", "sh" to "ш", "ch" to "ч", "zh" to "ж", "yu" to "ю", "ya" to "я",
            "ts" to "ц", "kh" to "х", "ph" to "ф", "ee" to "и", "oo" to "у", "ck" to "к",
            "ou" to "у", "th" to "т", "qu" to "кв"
        )
        val LAT2RU = mapOf(
            'a' to "а", 'b' to "б", 'c' to "к", 'd' to "д", 'e' to "е", 'f' to "ф", 'g' to "г",
            'h' to "х", 'i' to "и", 'j' to "дж", 'k' to "к", 'l' to "л", 'm' to "м", 'n' to "н",
            'o' to "о", 'p' to "п", 'q' to "к", 'r' to "р", 's' to "с", 't' to "т", 'u' to "у",
            'v' to "в", 'w' to "в", 'x' to "кс", 'y' to "й", 'z' to "з"
        )
    }
}
