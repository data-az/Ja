package com.AX

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject

/**
 * «Верховный суд» — NLU через API OpenRouter (поиск приложения по фразе).
 *
 * Режимы:
 *  - обычный ([Prefs.supremeOn]): вызывается ТОЛЬКО когда локальный поиск ничего не нашёл;
 *  - «полный ключ» ([Prefs.keyOnly]): локальный поиск пропускается.
 *
 * Сеть — через [Net] (OkHttp, браузерные заголовки, свой DNS, таймауты 15/15/10 с).
 * Каждый шаг пишется в логи (уровень API). Команда не может «зависнуть»: общий предел [HARD_TIMEOUT_MS].
 */
object SupremeCourt {

    private const val ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"
    private const val KEY_ENDPOINT = "https://openrouter.ai/api/v1/auth/key"
    private const val HF_ENDPOINT = "https://router.huggingface.co/v1/chat/completions"
    private fun cfEndpoint(account: String) =
        "https://api.cloudflare.com/client/v4/accounts/$account/ai/v1/chat/completions"

    const val DEFAULT_CF_MODEL = "@cf/meta/llama-3.1-8b-instruct"
    const val DEFAULT_HF_MODEL = "meta-llama/Llama-3.1-8B-Instruct"

    /** Роутер бесплатных моделей OpenRouter; можно заменить любым id в настройках. */
    const val DEFAULT_MODEL = "openrouter/free"

    private const val MAX_TOKENS = 100
    private const val MAX_APPS_CHARS = 12000
    private const val MAX_INPUT_CHARS = 200
    private const val HARD_TIMEOUT_MS = 20_000L

    /** Последняя причина неудачи (для сообщения пользователю). */
    @Volatile
    var lastError: String? = null
        private set

    /**
     * Одно сообщение с правилами, списком и фразой. [structured] — режим JSON (ответ {"app": "..."}),
     * иначе модель просят вывести только название.
     */
    private fun prompt(structured: Boolean, names: List<String>, userInput: String, roleHint: String?): String {
        val format = if (structured) "Ответ — JSON вида {\"app\": \"название из списка\"}."
        else "Выведи ТОЛЬКО оригинальное название приложения из списка и больше ничего. Без знаков препинания и объяснений."
        val none = if (structured) "строку NONE в поле app" else "строго слово: NONE"
        return """
Ты — часть голосового ассистента. Твоя задача — сопоставить фразу пользователя с одним из приложений из списка.
$format
Правила:
- Название выбирай ТОЛЬКО из списка, ровно в том написании, как в списке.
- Фраза может называть ФУНКЦИЮ, а не название: «фото», «снимки», «картинки» — это галерея или приложение с фото; «звонилка» — приложение для звонков.
- Название на ярлыке может отличаться от сказанного (например, «фото» → «Фотоснимки»). Выбирай по смыслу, а не по созвучию.
- Сокращения и сленг расшифровывай: «тг» — Telegram, «вк» — VK, «опенаи» — ChatGPT.
- Не выбирай приложение только потому, что оно похоже по звучанию на часть фразы.
- Если подходящего приложения нет, выведи $none.
${if (roleHint != null) "Подсказка системы: $roleHint\n" else ""}
Список приложений (самые вероятные первыми): ${names.joinToString(", ")}
Фраза пользователя: $userInput
${if (structured) "JSON:" else "Ответ:"}""".trimIndent()
    }

    /** Схема для JSON Mode: поле `app` принимает ТОЛЬКО значения из [names] (плюс NONE). */
    private fun responseFormat(names: List<String>): JSONObject {
        val values = JSONArray()
        for (n in names) values.put(n)
        values.put("NONE")
        val schema = JSONObject()
            .put("type", "object")
            .put("properties", JSONObject().put("app", JSONObject().put("type", "string").put("enum", values)))
            .put("required", JSONArray().put("app"))
            .put("additionalProperties", false)
        return JSONObject()
            .put("type", "json_schema")
            .put("json_schema", JSONObject().put("name", "app_choice").put("strict", true).put("schema", schema))
    }

    /** Один ИИ-провайдер с OpenAI-совместимым /chat/completions. */
    private class Provider(val id: String, val title: String, val url: String, val key: String, val model: String)

    /** Настроенные провайдеры: выбранный в «Приоритете» первым, остальные — запасные. */
    private fun providers(): List<Provider> {
        val list = ArrayList<Provider>()
        if (Prefs.supremeKey.isNotBlank())
            list.add(Provider("openrouter", "OpenRouter", ENDPOINT, Prefs.supremeKey.trim(),
                Prefs.supremeModel.ifBlank { DEFAULT_MODEL }))
        if (Prefs.cfToken.isNotBlank() && Prefs.cfAccount.isNotBlank())
            list.add(Provider("cloudflare", "Cloudflare", cfEndpoint(Prefs.cfAccount.trim()), Prefs.cfToken.trim(),
                Prefs.cfModel.ifBlank { DEFAULT_CF_MODEL }))
        if (Prefs.hfKey.isNotBlank())
            list.add(Provider("huggingface", "Hugging Face", HF_ENDPOINT, Prefs.hfKey.trim(),
                Prefs.hfModel.ifBlank { DEFAULT_HF_MODEL }))
        val first = Prefs.provider
        return if (first == "auto") list else list.sortedByDescending { it.id == first }
    }

    /** Есть ли хоть один рабочий набор ключей (OpenRouter, Cloudflare или Hugging Face). */
    val hasAnyKey: Boolean get() = providers().isNotEmpty()

    val enabled: Boolean get() = (Prefs.supremeOn || Prefs.keyOnly) && hasAnyKey

    /** Ключ для логов: sk-or-…abcd (N симв.). Целиком ключ в лог не попадает. */
    private fun mask(k: String): String = when {
        k.isBlank() -> "(пусто)"
        k.length <= 10 -> "••••• (${k.length} симв.)"
        else -> "${k.take(6)}…${k.takeLast(4)} (${k.length} симв.)"
    }

    fun maskedKey(): String = mask(Prefs.supremeKey)

    /** Строка состояния всех ключей для настроек. */
    fun keysSummary(): String =
        "OpenRouter: ${mask(Prefs.supremeKey)}\nCloudflare: ${mask(Prefs.cfToken)}" +
            (if (Prefs.cfAccount.isBlank()) " (нет Account ID)" else "") +
            "\nHugging Face: ${mask(Prefs.hfKey)}"

    private sealed class Answer {
        class Found(val app: AppInfo) : Answer()
        object None : Answer()
        class Failed(val why: String) : Answer()
    }

    /** Возвращает приложение из [apps] (сначала пользовательские) или null; причина — в [lastError]. */
    suspend fun judge(userInput: String, apps: List<AppInfo>, roleHint: String? = null): AppInfo? {
        lastError = null
        if (!Prefs.supremeOn && !Prefs.keyOnly) {
            AppLog.add("API", "Пропуск: «Верховный суд» выключен в настройках")
            return null
        }
        val chain = providers()
        if (chain.isEmpty()) {
            lastError = "API-ключ не введён"
            AppLog.add("ERR", "API: ни один ключ не введён, запрос не отправлен")
            return null
        }
        if (apps.isEmpty() || userInput.isBlank()) return null

        val byName = LinkedHashMap<String, AppInfo>()
        for (a in apps) byName.putIfAbsent(a.label.trim().lowercase(), a)

        // Названия, которые видит модель: они же — enum в JSON-схеме.
        val names = ArrayList<String>()
        var chars = 0
        for (a in byName.values) {
            val l = a.label.trim()
            if (l.isEmpty()) continue
            if (chars + l.length > MAX_APPS_CHARS) break
            names.add(l)
            chars += l.length + 2
        }

        // Предобработка: «тг» → Telegram, «опенаи» → ChatGPT и т.д. (список замен — в QueryAliases).
        val pre = QueryAliases.preprocess(userInput.take(MAX_INPUT_CHARS), names)
        AppLog.add("API", "Запрос после предобработки: «${pre.text}»" +
            if (pre.changes.isEmpty()) " (замен нет)" else " (замены: ${pre.changes.joinToString(", ")})")
        val rq = Req(pre.text, names, byName, roleHint)

        // Провайдеры по очереди: сеть/ключ/лимит у одного не работают, пробуем следующего.
        val errors = ArrayList<String>()
        for (p in chain) {
            when (val r = ask(p, rq)) {
                is Answer.Found -> return r.app
                is Answer.None -> {
                    lastError = "модель не нашла подходящего приложения"
                    AppLog.add("API", "${p.title}: $lastError")
                    return null
                }
                is Answer.Failed -> {
                    errors.add("${p.title}: ${r.why}")
                    if (chain.last() !== p) AppLog.add("API", "${p.title} не ответил, пробую следующего")
                }
            }
        }
        lastError = errors.joinToString("; ")
        return null
    }

    /** Подготовленный запрос: текст после предобработки, список названий (он же enum) и таблица для поиска ответа. */
    private class Req(val query: String, val names: List<String>, val byName: Map<String, AppInfo>, val roleHint: String?)

    /** Итог одной попытки. Retry — можно повторить без JSON-режима, Fatal — повтор бесполезен. */
    private sealed class Attempt {
        class Done(val answer: Answer) : Attempt()
        class Retry(val why: String) : Attempt()
        class Fatal(val why: String) : Attempt()
    }

    /** HTTP-коды, при которых повтор без JSON-режима не поможет (ключ, баланс, лимит, нет модели). */
    private val NO_RETRY_CODES = setOf(401, 402, 403, 404, 429)

    /**
     * Работает с любой моделью: сначала JSON Mode (enum из списка приложений), и если модель или провайдер
     * его не поддерживает, вернула пустоту или чужое название — второй запрос обычным текстом.
     * Результат всегда проверяется по списку приложений. Не падает: сбой — это [Answer.Failed] с причиной.
     */
    private suspend fun ask(p: Provider, rq: Req): Answer {
        var why = "нет ответа"
        for (structured in booleanArrayOf(true, false)) {
            when (val a = attempt(p, rq, structured)) {
                is Attempt.Done -> return a.answer
                is Attempt.Fatal -> return failed(p, a.why)
                is Attempt.Retry -> {
                    why = a.why
                    AppLog.add("API", "${p.title}: JSON-режим не дал результата ($why), пробую обычный текст")
                }
            }
        }
        return failed(p, "модель ${p.model} не справилась: $why")
    }

    private suspend fun attempt(p: Provider, rq: Req, structured: Boolean): Attempt {
        fun bad(why: String): Attempt =
            if (structured) Attempt.Retry(why) else Attempt.Fatal("модель ${p.model} не справилась: $why")

        val body = JSONObject()
            .put("model", p.model)
            .put("max_tokens", MAX_TOKENS)
            .put("temperature", 0)
            .put("messages", JSONArray().put(JSONObject().put("role", "user")
                .put("content", prompt(structured, rq.names, rq.query, rq.roleHint))))
        if (structured) body.put("response_format", responseFormat(rq.names))

        val mode = if (structured) "JSON-режим, enum из ${rq.names.size}" else "обычный текст"
        AppLog.add("API", "→ ${p.title} | модель ${p.model} | $mode | запрос: «${rq.query.take(60)}» | ключ ${mask(p.key)}")
        val t0 = System.currentTimeMillis()
        val res = try {
            withTimeoutOrNull(HARD_TIMEOUT_MS) { Net.postJson(p.url, body.toString(), p.key) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Throwable) {
            HttpResult(-1, "", "${e.javaClass.simpleName}: ${e.message}")
        }
        val ms = System.currentTimeMillis() - t0

        if (res == null) return Attempt.Fatal("таймаут ${HARD_TIMEOUT_MS / 1000} с, сервер не ответил")
        if (res.error != null) return Attempt.Fatal("${res.error} ($ms мс)")
        if (!res.ok) {
            val msg = "HTTP ${res.code}${hint(res.code)}: ${serverMessage(res.body)} ($ms мс)"
            return if (structured && res.code !in NO_RETRY_CODES) Attempt.Retry(msg) else Attempt.Fatal(msg)
        }

        val root = try {
            JSONObject(res.body)
        } catch (e: Exception) {
            return bad("не разобрал ответ сервера: ${e.message}; начало: ${res.body.take(200)}")
        }
        AiResponseParser.errorOf(root)?.let { return bad("ошибка в ответе: $it") }
        val ex = AiResponseParser.extract(root)
            ?: return bad("пустой ответ: в полях ${AiResponseParser.FIELDS_HINT} нет текста")
        AppLog.add("API", "${p.title} ← из поля ${ex.field}: «${ex.text.take(120)}» ($ms мс, модель ${root.optString("model", p.model)})")

        val answer = AiResponseParser.answerText(ex.text)
        if (answer.isEmpty()) return bad("пустой ответ")
        val found = match(answer, rq.byName) ?: return bad("ответ «$answer» не из списка приложений")
        if (found is Answer.Found) AppLog.add("API", "${p.title}: выбрано «${found.app.label}»")
        return Attempt.Done(found)
    }

    /** Название от модели → приложение из списка. null — такого приложения нет. */
    private fun match(answer: String, byName: Map<String, AppInfo>): Answer? {
        if (answer.equals("NONE", ignoreCase = true)) return Answer.None
        val low = answer.lowercase()
        byName[low]?.let { return Answer.Found(it) }
        // Модель могла сократить или дополнить название. Берём самое длинное совпадение, а не первое по списку.
        return byName.entries
            .filter { (n, _) -> n.length >= 4 && low.length >= 4 && (low.contains(n) || n.contains(low)) }
            .maxByOrNull { it.key.length }
            ?.let { Answer.Found(it.value) }
    }

    private fun failed(p: Provider, msg: String): Answer {
        lastError = "${p.title}: $msg"
        AppLog.add("ERR", "API ${p.title}: $msg")
        return Answer.Failed(msg)
    }

    private fun hint(code: Int) = when (code) {
        401 -> " (ключ отклонён: проверьте, что скопирован целиком)"
        402 -> " (нет кредитов на аккаунте)"
        403 -> " (доступ запрещён: защита Cloudflare/регион; проверьте WARP)"
        404 -> " (модель не найдена или нет доступных провайдеров)"
        429 -> " (лимит запросов исчерпан)"
        else -> ""
    }

    private fun serverMessage(body: String): String {
        if (body.isBlank()) return "пустой ответ сервера"
        return try {
            AiResponseParser.errorOf(JSONObject(body))?.takeIf { it.isNotBlank() } ?: body.take(300)
        } catch (e: Exception) {
            body.take(300)
        }
    }

    /**
     * Проверка всех введённых ключей (кнопка в настройках). Блокирующий — вызывать вне UI-потока.
     * OpenRouter — запрос к /auth/key; Cloudflare и Hugging Face — настоящий мини-запрос к модели,
     * так проверяются сразу ключ, Account ID и имя модели.
     */
    fun checkKey(): String {
        val lines = ArrayList<String>()
        if (Prefs.supremeKey.isNotBlank()) lines.add("OpenRouter: " + checkOpenRouter())
        for (p in providers()) {
            if (p.id != "openrouter") lines.add("${p.title}: " + checkChat(p))
        }
        if (Prefs.cfToken.isNotBlank() && Prefs.cfAccount.isBlank()) lines.add("Cloudflare: введите Account ID")
        if (Prefs.cfToken.isBlank() && Prefs.cfAccount.isNotBlank()) lines.add("Cloudflare: введите API-токен")
        if (lines.isEmpty()) {
            AppLog.add("ERR", "API: проверка — ни один ключ не введён")
            return "Ключи не введены"
        }
        return lines.joinToString("\n")
    }

    private fun checkChat(p: Provider): String {
        AppLog.add("API", "Проверка ${p.title}: ключ ${mask(p.key)}, модель ${p.model}")
        val body = JSONObject()
            .put("model", p.model)
            .put("max_tokens", 8)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", "Ответь одним словом: ок")))
            .toString()
        val t0 = System.currentTimeMillis()
        val res = runBlocking { withTimeoutOrNull(HARD_TIMEOUT_MS) { Net.postJson(p.url, body, p.key) } }
        val ms = System.currentTimeMillis() - t0
        val text = when {
            res == null -> "не проверен: таймаут"
            res.error != null -> "нет связи: ${res.error}"
            !res.ok -> "не работает: HTTP ${res.code}${hint(res.code)}: ${serverMessage(res.body)}"
            else -> "работает ✓ ($ms мс)"
        }
        AppLog.add(if (text.startsWith("работает")) "OK" else "ERR", "API ${p.title}: $text")
        return text
    }

    private fun checkOpenRouter(): String {
        AppLog.add("API", "Проверка ключа ${maskedKey()}")
        val t0 = System.currentTimeMillis()
        val key = Prefs.supremeKey.trim()
        val res = runBlocking { withTimeoutOrNull(HARD_TIMEOUT_MS) { Net.get(KEY_ENDPOINT, key) } }
        val ms = System.currentTimeMillis() - t0
        val text = when {
            res == null -> "не проверен: общий таймаут"
            res.error != null -> "нет связи: ${res.error}"
            !res.ok -> "не работает: HTTP ${res.code}${hint(res.code)}: ${serverMessage(res.body)}"
            else -> try {
                val data = JSONObject(res.body).optJSONObject("data")
                val free = data?.optBoolean("is_free_tier", false) == true
                val usage = data?.optDouble("usage", 0.0) ?: 0.0
                val limit = if (data == null || data.isNull("limit")) "без лимита" else "лимит ${data.optDouble("limit")}"
                "работает ✓ (${if (free) "бесплатный тариф" else "платный"}, потрачено $usage, $limit)"
            } catch (e: Exception) {
                "принят (HTTP ${res.code}), но ответ не разобран"
            }
        }
        AppLog.add(if (text.startsWith("работает")) "OK" else "ERR", "API OpenRouter: $text ($ms мс)")
        return text
    }
}
