package com.AX

import org.json.JSONArray
import org.json.JSONObject

/**
 * Универсальный разбор ответа Cloudflare Workers AI (и OpenAI-совместимых API).
 * Разные модели кладут текст в разные поля, поэтому поля перебираются по очереди.
 * Класс чистый (без Android-зависимостей и логов): логирует вызывающий код.
 */
object AiResponseParser {

    /** [text] — найденный текст, [field] — путь поля, откуда он взят (для логов). */
    class Extracted(val text: String, val field: String)

    /** Порядок поиска. Первые три — как в Cloudflare `/ai/run`, дальше — OpenAI-формат без обёртки `result`. */
    private val PATHS = listOf(
        "result.response",
        "result.choices[0].message.content",
        "result.answer",
        "choices[0].message.content",
        "choices[0].text",
        "response",
        "answer"
    )

    /** Для сообщений об ошибке. */
    val FIELDS_HINT: String = PATHS.take(4).joinToString(", ")

    /** Первое непустое поле из [PATHS] или null, если текста нет нигде. */
    fun extract(root: JSONObject): Extracted? {
        for (path in PATHS) {
            val text = textOf(valueAt(root, path)).trim()
            if (text.isNotEmpty()) return Extracted(text, path)
        }
        return null
    }

    /** Сообщение об ошибке из тела ответа (OpenAI `error`, Cloudflare `errors[]`) или null. */
    fun errorOf(root: JSONObject): String? {
        val e = root.opt("error")
        if (e is JSONObject) return e.optString("message").ifBlank { e.toString() }
        if (e is String && e.isNotBlank()) return e
        val list = root.optJSONArray("errors")
        if (list != null && list.length() > 0) {
            val first = list.opt(0)
            return if (first is JSONObject) first.optString("message").ifBlank { first.toString() } else first.toString()
        }
        if (root.has("success") && !root.optBoolean("success", true)) return "success=false"
        return null
    }

    /**
     * Из сырого текста модели получает чистое название приложения:
     * убирает <think>…</think>, ```-ограждения, достаёт `app` из JSON, снимает кавычки и «Ответ:».
     */
    fun answerText(raw: String): String {
        var s = raw.replace(Regex("(?s)<think>.*?</think>"), " ").trim()
        s = s.replace(Regex("(?s)^```[a-zA-Z]*\\s*"), "").replace(Regex("```\\s*$"), "").trim()

        val from = s.indexOf('{')
        val to = s.lastIndexOf('}')
        if (from >= 0 && to > from) {
            try {
                val o = JSONObject(s.substring(from, to + 1))
                val v = pickString(o)
                if (v != null) return clean(v)
            } catch (_: Exception) {
                // не JSON — разбираем как обычный текст
            }
        }
        // Строка в кавычках или начало фразы вида «Ответ: Telegram».
        s = s.lineSequence().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: ""
        s = s.replace(Regex("^(ответ|answer|app|приложение)\\s*[:\\-—]\\s*", RegexOption.IGNORE_CASE), "")
        return clean(s)
    }

    private fun clean(s: String) = s.trim().trim('"', '\'', '«', '»', '`', '.', ',', '!', ';', ' ', '\n', '\r')

    /** Поле `app`, а если модель назвала его иначе — любое подходящее или первая строка JSON. */
    private fun pickString(o: JSONObject): String? {
        for (k in listOf("app", "application", "name", "answer", "result", "choice", "title")) {
            val v = o.opt(k)
            if (v is String && v.isNotBlank()) return v
        }
        val it = o.keys()
        while (it.hasNext()) {
            val v = o.opt(it.next())
            if (v is String && v.isNotBlank()) return v
        }
        return null
    }

    /** Идёт по пути вида `result.choices[0].message.content`. Нет поля — null. */
    private fun valueAt(root: JSONObject, path: String): Any? {
        var cur: Any? = root
        for (part in path.split('.')) {
            val name = part.substringBefore('[')
            if (cur !is JSONObject) return null
            cur = cur.opt(name)
            var rest = part.substringAfter('[', "")
            while (rest.isNotEmpty()) {
                val idx = rest.substringBefore(']').toIntOrNull() ?: return null
                cur = (cur as? JSONArray)?.opt(idx)
                rest = rest.substringAfter(']').substringAfter('[', "")
            }
            if (cur == null || cur == JSONObject.NULL) return null
        }
        return cur
    }

    /**
     * Значение поля → текст. Строка — как есть; объект — JSON-строкой (JSON Mode у Cloudflare иногда
     * отдаёт уже разобранный объект); массив — склейка частей `{type:text,text:…}` или строк.
     */
    private fun textOf(v: Any?): String = when (v) {
        null, JSONObject.NULL -> ""
        is String -> v
        is JSONObject -> v.toString()
        is JSONArray -> (0 until v.length()).joinToString("") { i ->
            when (val p = v.opt(i)) {
                is String -> p
                is JSONObject -> p.optString("text")
                else -> ""
            }
        }
        else -> v.toString()
    }
}
