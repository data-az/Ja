package com.AX

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * DSP-изменение тональности голоса прямо над PCM [FloatArray] (до отправки в AudioTrack).
 *
 * Алгоритм: ресемплинг в [pitch] раз (меняет высоту, но и длительность) → WSOLA
 * (растяжение по времени без изменения высоты), возвращающее исходную длительность.
 *
 *  pitch = 1.0f  — звук без изменений (эталон модели);
 *  pitch < 1.0f  — ниже, «басовитый» металлический Jarvis;
 *  pitch > 1.0f  — выше.
 */
object PitchShifter {

    const val DEFAULT = 1.0f
    const val MIN = 0.5f
    const val MAX = 2.0f

    fun shift(input: FloatArray, pitch: Float, sampleRate: Int): FloatArray {
        val p = pitch.coerceIn(MIN, MAX)
        if (abs(p - DEFAULT) < 0.001f || input.size < 64) return input

        val resampled = resample(input, p)
        val restored = wsolaStretch(resampled, p, sampleRate, input.size)
        for (i in restored.indices) restored[i] = restored[i].coerceIn(-1f, 1f)
        return restored
    }

    /** Чтение входа с шагом [ratio] (линейная интерполяция): высота × ratio, длина / ratio. */
    private fun resample(x: FloatArray, ratio: Float): FloatArray {
        val outLen = ((x.size - 1) / ratio).toInt() + 1
        val out = FloatArray(outLen)
        for (i in 0 until outLen) {
            val pos = i * ratio
            val i0 = pos.toInt()
            val frac = pos - i0
            val a = x[i0]
            val b = if (i0 + 1 < x.size) x[i0 + 1] else a
            out[i] = a + (b - a) * frac
        }
        return out
    }

    /** WSOLA: растягивает [x] в [factor] раз; результат подгоняется к [targetLen] отсчётам. */
    private fun wsolaStretch(x: FloatArray, factor: Float, sampleRate: Int, targetLen: Int): FloatArray {
        val frame = max(256, (sampleRate / 20) and 1.inv())   // ~50 мс, чётное
        val hopS = frame / 2                                    // шаг синтеза
        val hopA = hopS / factor                                // шаг анализа (дробный)
        val tol = frame / 4                                     // допуск поиска совпадения
        val overlap = frame - hopS

        val window = FloatArray(frame) { (0.5 - 0.5 * cos(2.0 * PI * it / frame)).toFloat() }
        val out = FloatArray(targetLen + frame)
        val norm = FloatArray(targetLen + frame)

        fun addFrame(src: Int, dst: Int) {
            for (i in 0 until frame) {
                val s = src + i
                val v = if (s in x.indices) x[s] else 0f
                out[dst + i] += v * window[i]
                norm[dst + i] += window[i]
            }
        }

        var prevPos = 0
        addFrame(0, 0)
        var k = 1
        while (k * hopS < targetLen) {
            val nominal = (k * hopA).roundToInt()
            if (nominal >= x.size) break
            // «Естественное продолжение» предыдущего кадра — эталон для поиска лучшего места.
            val refStart = prevPos + hopS
            var bestPos = nominal.coerceIn(0, max(0, x.size - 1))
            var bestCorr = Float.NEGATIVE_INFINITY
            val from = max(0, nominal - tol)
            val to = min(max(0, x.size - overlap - 1), nominal + tol)
            var cand = from
            while (cand <= to) {
                var c = 0f
                var i = 0
                while (i < overlap) {
                    val r = refStart + i
                    val rv = if (r in x.indices) x[r] else 0f
                    c += rv * x[cand + i]
                    i += 2                                      // прореживание ускоряет поиск
                }
                if (c > bestCorr) { bestCorr = c; bestPos = cand }
                cand += 1
            }
            addFrame(bestPos, k * hopS)
            prevPos = bestPos
            k++
        }

        val result = FloatArray(targetLen)
        for (i in 0 until targetLen) result[i] = if (norm[i] > 1e-4f) out[i] / norm[i] else 0f
        return result
    }
}
