package com.AX

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.Random
import java.nio.FloatBuffer
import java.nio.LongBuffer
import java.util.Locale
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Локальный синтез речи: модель Piper (VITS, ONNX) через onnxruntime-android.
 *
 * Подходит ru_RU-ruslan-medium.onnx + tokens.txt (csukuangfj/vits-piper-ru_RU-ruslan-medium).
 *
 * ВАЖНО: Piper понимает не буквы, а ФОНЕМЫ espeak-ng (`привет` → `prʲɪvʲˈet`). Поэтому поток такой:
 *   текст → [RuPhonemizer] (фонемы IPA) → id по tokens.txt → ONNX → PCM [FloatArray]
 *        → [PitchShifter] (Prefs.pitch) → AudioTrack.
 *
 * Раскладка id как в Piper: `^` (BOS), затем после КАЖДОЙ фонемы вставляется `_` (PAD), в конце `$` (EOS).
 * Вход модели: `input` int64 [1,N], `input_lengths` int64 [1], `scales` float [3] (noise, length, noise_w),
 * `sid` int64 [1] — только у многоголосых моделей. Выход: float [1,1,1,T], частота обычно 22050 Гц.
 *
 * Файлы (порядок поиска): `filesDir/silero/` (импорт из приложения) → `Android/data/com.AX/files/silero/`
 * → `assets/silero/`. Имена: silero_tts.onnx, tokens.txt, необязательно stress.txt (свои ударения,
 * слово на строку со знаком «+» перед ударной гласной: `прив+ет`) и model.json (sample_rate, scales).
 *
 * Все события пишутся в лог «Звук» ([AppLog.sound]).
 */
object Voice {

    private const val MODEL_FILE = "silero_tts.onnx"
    private const val TOKENS_FILE = "tokens.txt"
    private const val STRESS_FILE = "stress.txt"
    private const val CONFIG_FILE = "model.json"
    private const val DEFAULT_RATE = 22050
    private const val MAX_CHUNK = 220

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lock = Any()          // трек воспроизведения (короткие операции, в т.ч. из UI-потока)
    private val sessionLock = Any()   // загрузка модели (долго, только фоновые потоки)

    private lateinit var appCtx: Context
    private var env: OrtEnvironment? = null
    private var session: OrtSession? = null
    private var symbols: Map<Char, Long> = emptyMap()
    private var padId = 0L
    private var bosId = 1L
    private var eosId = 2L

    @Volatile
    var sampleRate: Int = DEFAULT_RATE
        private set
    // Значения модели по умолчанию (model.json / метаданные). Пользовательские множители — Prefs.voice.
    private var baseNoise = 0.667f
    private var baseLength = 1.0f
    private var baseNoiseW = 0.8f

    /** Число голосов модели (0 — неизвестно или модель одноголосая). */
    @Volatile
    var speakers: Int = 0
        private set

    /** Есть ли у модели вход speaker id. */
    @Volatile
    var hasSpeakerInput: Boolean = false
        private set

    /** Последняя озвученная реплика после всех эффектов — для экспорта в WAV. */
    @Volatile
    private var lastOutput: FloatArray? = null

    /** Кэш «сырого» синтеза (до тональности и эффектов): повторные реплики и подбор эффектов — мгновенно. */
    private val cache = object : LinkedHashMap<String, FloatArray>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, FloatArray>?): Boolean = size > 8
    }

    /** Параметры одного прогона модели. */
    private class Synth(val length: Float, val noise: Float, val noiseW: Float, val sid: Long)

    private var job: Job? = null
    private var track: AudioTrack? = null

    @Volatile
    var lastError: String? = null
        private set

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
    }

    /** Есть ли файлы модели (проверка дешёвая, модель при этом не грузится). */
    fun hasModelFiles(): Boolean = findFile(MODEL_FILE) != null && findFile(TOKENS_FILE) != null

    val isReady: Boolean get() = Prefs.ttsOn && hasModelFiles()

    fun stateText(): String {
        val hasModel = findFile(MODEL_FILE) != null
        val hasTokens = findFile(TOKENS_FILE) != null
        return when {
            !hasModel && !hasTokens ->
                "Нет модели. Нажмите «Импортировать файлы голоса» и выберите .onnx и tokens.txt"
            !hasModel -> "Нет файла модели (.onnx). Нажмите «Импортировать файлы голоса»"
            !hasTokens -> "Нет tokens.txt. Нажмите «Импортировать файлы голоса»"
            lastError != null -> "Ошибка: $lastError"
            else -> "Модель найдена (Piper, $sampleRate Гц" +
                (if (hasSpeakerInput) ", голосов: ${if (speakers > 0) speakers else "?"}" else "") +
                "). Подробности — в логах, вкладка «Звук»"
        }
    }

    /** Сброс загруженной сессии: после замены файлов модель перечитается при следующей реплике. */
    fun reload() {
        stop()
        synchronized(sessionLock) {
            runCatching { session?.close() }
            session = null
            symbols = emptyMap()
            lastError = null
        }
        synchronized(cache) { cache.clear() }
    }

    /**
     * Импорт выбранных пользователем файлов: `*.onnx` → silero_tts.onnx, `*.txt` → tokens.txt
     * (имя со словом «stress» → stress.txt), `*.json` → model.json.
     * Блокирующий (копирование десятков МБ) — вызывать вне UI-потока. Возвращает текст для экрана.
     */
    fun importFiles(uris: List<Uri>): String {
        val dir = File(appCtx.filesDir, "silero").apply { mkdirs() }
        val done = ArrayList<String>()
        val skipped = ArrayList<String>()
        for (uri in uris) {
            val name = displayName(uri) ?: uri.lastPathSegment.orEmpty()
            val lower = name.lowercase(Locale.ROOT)
            val target = when {
                lower.endsWith(".onnx") -> MODEL_FILE
                lower.endsWith(".json") -> CONFIG_FILE
                lower.endsWith(".txt") && lower.contains("stress") -> STRESS_FILE
                lower.endsWith(".txt") -> TOKENS_FILE
                else -> { skipped.add(name); continue }
            }
            try {
                val tmp = File(dir, "$target.tmp")
                val input = appCtx.contentResolver.openInputStream(uri)
                    ?: throw java.io.IOException("файл не открывается")
                input.use { src -> tmp.outputStream().use { src.copyTo(it) } }
                val dst = File(dir, target)
                if (dst.exists()) dst.delete()
                if (!tmp.renameTo(dst)) throw java.io.IOException("не удалось сохранить $target")
                done.add("$name → $target (${dst.length() / 1024} КБ)")
                AppLog.sound("OK", "Импорт: $name → $target, ${dst.length()} байт, папка ${dir.absolutePath}", "импорт $name")
            } catch (e: Exception) {
                skipped.add("$name (${e.message})")
                AppLog.sound("ERR", "Импорт: $name — ${e.javaClass.simpleName}: ${e.message}", "импорт $name не удался")
            }
        }
        reload()
        val sb = StringBuilder()
        if (done.isNotEmpty()) sb.append("Импортировано: ").append(done.joinToString("; ")).append('\n')
        if (skipped.isNotEmpty()) sb.append("Пропущено (нужны .onnx и .txt): ").append(skipped.joinToString("; ")).append('\n')
        sb.append(stateText())
        return sb.toString()
    }

    private fun displayName(uri: Uri): String? = try {
        appCtx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }

    /**
     * Озвучивает [text] в фоне. Предыдущая реплика прерывается.
     * [params] — снимок настроек голоса (по умолчанию текущие из Prefs). [force] — играть, даже если озвучка выключена
     * (кнопки проверки в настройках).
     */
    fun speak(text: String, params: VoiceParams = Prefs.voice.copy(), force: Boolean = false) {
        if (!((force || Prefs.ttsOn) && hasModelFiles())) {
            AppLog.sound(
                "INFO",
                "Озвучка пропущена: голос ${if (Prefs.ttsOn) "включён" else "выключен"}, " +
                    "модель ${if (findFile(MODEL_FILE) != null) "есть" else "нет"}, " +
                    "tokens ${if (findFile(TOKENS_FILE) != null) "есть" else "нет"}",
                "озвучка пропущена"
            )
            return
        }
        if (text.isBlank()) return
        stop()
        job = scope.launch {
            try {
                AppLog.sound("INFO", "Запрос на озвучку: «$text» (${text.length} симв.)\n   параметры: ${params.describeChanges()}", "озвучиваю «${text.take(40)}»")
                val t0 = System.currentTimeMillis()
                val raw = synthesizeAll(text, params)
                if (raw == null || raw.isEmpty()) {
                    AppLog.sound(
                        "ERR",
                        "Синтез не дал звука: ${lastError ?: "из текста не получилось ни одной фонемы"}",
                        "синтез не дал звука"
                    )
                    return@launch
                }
                val t1 = System.currentTimeMillis()
                val shaped = PitchShifter.shift(raw, params["pitch"], sampleRate)
                val t2 = System.currentTimeMillis()
                val out = VoiceFx.process(shaped, sampleRate, params)
                lastOutput = out
                val seconds = out.size / sampleRate.toFloat()
                AppLog.sound(
                    "INFO",
                    "Готово: синтез ${t1 - t0} мс, тональность ×${"%.2f".format(Locale.US, params["pitch"])} ${t2 - t1} мс, " +
                        "эффекты ${System.currentTimeMillis() - t2} мс, ${"%.2f".format(Locale.US, seconds)} с звука, " +
                        "${out.size} отсчётов @ $sampleRate Гц",
                    "синтез ${t1 - t0} мс, ${"%.1f".format(Locale.US, seconds)} с"
                )
                play(out)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                lastError = e.message
                AppLog.sound("ERR", "${e.javaClass.simpleName}: ${e.message}", "ошибка озвучки: ${e.message}")
            }
        }
    }

    /** Сохраняет последнюю реплику (со всеми эффектами) в WAV. Возвращает текст для экрана. */
    fun saveLastWav(): String {
        val pcm = lastOutput ?: return "Пока нечего сохранять: сначала проиграйте фразу"
        return try {
            val dir = File(appCtx.getExternalFilesDir(null), "voice").apply { mkdirs() }
            val f = File(dir, "jarvis_${System.currentTimeMillis() / 1000}.wav")
            VoiceFx.writeWav(f, pcm, sampleRate)
            AppLog.sound("OK", "WAV сохранён: ${f.absolutePath} (${f.length() / 1024} КБ)", "WAV сохранён")
            "Сохранено: ${f.absolutePath}"
        } catch (e: Exception) {
            AppLog.sound("ERR", "WAV не сохранён: ${e.message}", "WAV не сохранён")
            "Не удалось сохранить: ${e.message}"
        }
    }

    /** Грузит модель заранее (в фоне), чтобы первая реплика не ждала пару секунд. */
    fun warmUp() {
        if (!Prefs.ttsOn || !hasModelFiles()) return
        scope.launch { runCatching { ensureSession() } }
    }

    fun stop() {
        job?.cancel()
        synchronized(lock) {
            track?.let { runCatching { it.stop() }; it.release() }
            track = null
        }
    }

    // ---------- Синтез ----------

    /** Режет текст на абзацы и предложения, синтезирует каждое и склеивает с паузами из настроек. */
    private fun synthesizeAll(text: String, params: VoiceParams): FloatArray? {
        val s = ensureSession() ?: return null
        val lively = params["lively"]
        val speed = params["speed"].coerceAtLeast(0.2f)
        val sid = params["speaker"].toInt().let { if (speakers > 0) it.coerceIn(0, speakers - 1) else it }.toLong()
        val pauseS = params["pauseS"]
        val pauseP = params["pauseP"]

        // Кэшируем только детерминированный синтез (без случайности между фразами).
        val key = if (lively <= 0.001f)
            "$text|$speed|${params["noise"]}|${params["noisew"]}|$sid|$pauseS|$pauseP" else null
        if (key != null) {
            val hit = synchronized(cache) { cache[key] }
            if (hit != null) {
                AppLog.sound("INFO", "Синтез взят из кэша (${hit.size} отсчётов)", "синтез из кэша")
                return hit
            }
        }

        val sentGap = FloatArray((sampleRate * pauseS / 1000f).toInt())
        val paraGap = FloatArray((sampleRate * pauseP / 1000f).toInt())
        val plan = ArrayList<Pair<Int, String>>()
        val paragraphs = text.split(Regex("\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
        for ((pi, para) in paragraphs.withIndex()) for (c in splitText(para)) plan.add(pi to c)

        val rnd = Random()
        fun jitter(amp: Float) = 1f + (rnd.nextFloat() - 0.5f) * 2f * amp * lively
        val parts = ArrayList<FloatArray>()
        var prevPara = -1
        for ((n, item) in plan.withIndex()) {
            val (pi, chunk) = item
            val syn = Synth(
                length = baseLength / speed * jitter(0.15f),
                noise = (params["noise"].takeIf { it > 0.005f } ?: baseNoise) * jitter(0.25f),
                noiseW = (params["noisew"].takeIf { it > 0.005f } ?: baseNoiseW) * jitter(0.25f),
                sid = sid
            )
            val pcm = synthesizeChunk(s, chunk, n + 1, plan.size, syn) ?: continue
            if (parts.isNotEmpty()) {
                val g = if (pi != prevPara) paraGap else sentGap
                if (g.isNotEmpty()) parts.add(g)
            }
            parts.add(pcm)
            prevPara = pi
        }
        if (parts.isEmpty()) return null
        val out = FloatArray(parts.sumOf { it.size })
        var pos = 0
        for (p in parts) { p.copyInto(out, pos); pos += p.size }
        normalize(out)
        if (key != null) synchronized(cache) { cache[key] = out }
        return out
    }

    private fun splitText(text: String): List<String> {
        val sentences = text.replace('\n', ' ').split(Regex("(?<=[.!?;])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        for (sent in sentences) {
            var rest = sent
            while (rest.length > MAX_CHUNK) {
                var cut = rest.lastIndexOf(',', MAX_CHUNK)
                if (cut < 40) cut = rest.lastIndexOf(' ', MAX_CHUNK)
                if (cut < 20) cut = MAX_CHUNK
                out.add(rest.substring(0, cut + 1).trim())
                rest = rest.substring(cut + 1).trim()
            }
            if (rest.isNotEmpty()) out.add(rest)
        }
        return out
    }

    private fun synthesizeChunk(s: OrtSession, chunk: String, index: Int, total: Int, syn: Synth): FloatArray? {
        val e = env ?: return null
        val prepared = RuPhonemizer.normalized(chunk)
        val phonemes = RuPhonemizer.phonemize(chunk)
        AppLog.sound(
            "INFO",
            "Часть $index/$total: «$chunk»\n   после подстановки: «$prepared»\n   фонемы: $phonemes",
            null
        )
        if (phonemes.isEmpty()) return null

        val ids = ArrayList<Long>(phonemes.length * 2 + 3)
        val unknown = LinkedHashSet<Char>()
        ids.add(bosId)
        for (ch in phonemes) {
            val id = symbols[ch]
            if (id == null) { unknown.add(ch); continue }
            ids.add(id)
            ids.add(padId)
        }
        ids.add(eosId)
        if (unknown.isNotEmpty()) {
            AppLog.sound(
                "ERR",
                "Символы, которых нет в tokens.txt (пропущены): " +
                    unknown.joinToString(" ") { "«$it» U+%04X".format(it.code) },
                "нет символов в tokens: ${unknown.joinToString("")}"
            )
        }
        if (ids.size <= 3) return null
        val idArr = ids.toLongArray()

        val tensors = ArrayList<OnnxTensor>()
        try {
            val t0 = System.currentTimeMillis()
            val inputs = buildInputs(e, s, idArr, syn, tensors)
            s.run(inputs).use { result ->
                val value = result[0].value
                val pcm = flatten(value)
                val ms = System.currentTimeMillis() - t0
                if (pcm == null || pcm.isEmpty()) {
                    AppLog.sound("ERR", "ONNX вернул не float-массив: ${value?.javaClass?.name}", "ONNX без звука")
                    return null
                }
                var peak = 0f
                var sum = 0.0
                for (v in pcm) { val a = abs(v); if (a > peak) peak = a; sum += v.toDouble() * v }
                val rms = sqrt(sum / pcm.size).toFloat()
                AppLog.sound(
                    if (peak < 0.005f) "ERR" else "INFO",
                    "Часть $index: ONNX $ms мс, токенов ${idArr.size}, отсчётов ${pcm.size} " +
                        "(noise=${"%.2f".format(Locale.US, syn.noise)} length=${"%.2f".format(Locale.US, syn.length)} " +
                        "noise_w=${"%.2f".format(Locale.US, syn.noiseW)} sid=${syn.sid}) " +
                        "(${"%.2f".format(Locale.US, pcm.size / sampleRate.toFloat())} с), " +
                        "пик ${"%.3f".format(Locale.US, peak)}, RMS ${"%.4f".format(Locale.US, rms)}" +
                        if (peak < 0.005f) " — ТИШИНА на выходе модели" else "",
                    null
                )
                return pcm
            }
        } finally {
            tensors.forEach { runCatching { it.close() } }
        }
    }

    /** Доводит громкость до приятной: тихую запись подтягивает, громкую не трогает. */
    private fun normalize(pcm: FloatArray) {
        var peak = 0f
        for (v in pcm) { val a = abs(v); if (a > peak) peak = a }
        if (peak < 0.01f) return
        val gain = if (peak < 0.7f) 0.9f / peak else if (peak > 0.98f) 0.98f / peak else 1f
        if (gain != 1f) for (i in pcm.indices) pcm[i] = (pcm[i] * gain).coerceIn(-1f, 1f)
    }

    private fun buildInputs(
        e: OrtEnvironment,
        s: OrtSession,
        ids: LongArray,
        syn: Synth,
        keep: MutableList<OnnxTensor>
    ): Map<String, OnnxTensor> {
        val map = LinkedHashMap<String, OnnxTensor>()
        var tokensAssigned = false
        for (name in s.inputNames) {
            val n = name.lowercase(Locale.ROOT)
            val t = when {
                n.contains("scale") ->
                    OnnxTensor.createTensor(e, FloatBuffer.wrap(floatArrayOf(syn.noise, syn.length, syn.noiseW)), longArrayOf(3))
                n.contains("len") ->
                    OnnxTensor.createTensor(e, LongBuffer.wrap(longArrayOf(ids.size.toLong())), longArrayOf(1))
                n.contains("sid") || n.contains("speaker") ->
                    OnnxTensor.createTensor(e, LongBuffer.wrap(longArrayOf(syn.sid)), longArrayOf(1))
                !tokensAssigned -> {
                    tokensAssigned = true
                    OnnxTensor.createTensor(e, LongBuffer.wrap(ids), longArrayOf(1, ids.size.toLong()))
                }
                else -> continue
            }
            keep.add(t)
            map[name] = t
        }
        return map
    }

    /** Любой вложенности float-массив → плоский FloatArray. */
    private fun flatten(v: Any?): FloatArray? = when (v) {
        is FloatArray -> v
        is Array<*> -> {
            val parts = v.mapNotNull { flatten(it) }
            val out = FloatArray(parts.sumOf { it.size })
            var pos = 0
            for (p in parts) { p.copyInto(out, pos); pos += p.size }
            out
        }
        else -> null
    }

    // ---------- Загрузка модели ----------

    private fun ensureSession(): OrtSession? = synchronized(sessionLock) {
        session?.let { return it }
        val model = findFile(MODEL_FILE) ?: return null
        val tokens = findFile(TOKENS_FILE) ?: return null
        return try {
            val t0 = System.currentTimeMillis()
            val e = OrtEnvironment.getEnvironment()
            env = e
            parseTokens(tokens.readLines(Charsets.UTF_8))
            findFile(STRESS_FILE)?.let { f ->
                val lines = f.readLines(Charsets.UTF_8)
                RuPhonemizer.setUserDictionary(lines)
                AppLog.sound("INFO", "Словарь ударений stress.txt: ${lines.size} строк", null)
            }
            sampleRate = DEFAULT_RATE
            baseNoise = 0.667f; baseLength = 1.0f; baseNoiseW = 0.8f
            speakers = 0
            val opts = OrtSession.SessionOptions()
            runCatching { opts.setIntraOpNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(1, 4)) }
            val sess = e.createSession(model.absolutePath, opts)

            // Частота и параметры: model.json → метаданные модели → 22050 Гц.
            var rateSource = "по умолчанию"
            runCatching {
                val meta = sess.metadata.customMetadata
                meta["sample_rate"]?.toIntOrNull()?.let { sampleRate = it; rateSource = "метаданные модели" }
                meta["noise_scale"]?.toFloatOrNull()?.let { baseNoise = it }
                meta["length_scale"]?.toFloatOrNull()?.let { baseLength = it }
                meta["noise_w"]?.toFloatOrNull()?.let { baseNoiseW = it }
            }
            findFile(CONFIG_FILE)?.let { f ->
                val json = f.readText(Charsets.UTF_8)
                Regex("\"sample_rate\"\\s*:\\s*(\\d+)").find(json)?.groupValues?.get(1)?.toIntOrNull()
                    ?.let { sampleRate = it; rateSource = "model.json" }
                Regex("\"noise_scale\"\\s*:\\s*([0-9.]+)").find(json)?.groupValues?.get(1)?.toFloatOrNull()?.let { baseNoise = it }
                Regex("\"length_scale\"\\s*:\\s*([0-9.]+)").find(json)?.groupValues?.get(1)?.toFloatOrNull()?.let { baseLength = it }
                Regex("\"noise_w\"\\s*:\\s*([0-9.]+)").find(json)?.groupValues?.get(1)?.toFloatOrNull()?.let { baseNoiseW = it }
            }

            hasSpeakerInput = sess.inputNames.any { n ->
                val l = n.lowercase(Locale.ROOT)
                l.contains("sid") || l.contains("speaker")
            }
            runCatching {
                sess.metadata.customMetadata["num_speakers"]?.toIntOrNull()?.let { speakers = it }
            }
            findFile(CONFIG_FILE)?.let { f ->
                Regex("\"num_speakers\"\\s*:\\s*(\\d+)").find(f.readText(Charsets.UTF_8))
                    ?.groupValues?.get(1)?.toIntOrNull()?.let { speakers = it }
            }
            if (!hasSpeakerInput) speakers = 0

            val ins = sess.inputInfo.entries.joinToString("; ") { (n, info) ->
                val ti = info.info as? TensorInfo
                "$n ${ti?.type ?: "?"} ${ti?.shape?.contentToString() ?: ""}"
            }
            val outs = sess.outputInfo.entries.joinToString("; ") { (n, info) ->
                val ti = info.info as? TensorInfo
                "$n ${ti?.type ?: "?"} ${ti?.shape?.contentToString() ?: ""}"
            }
            AppLog.sound(
                "OK",
                "Модель загружена за ${System.currentTimeMillis() - t0} мс: ${model.name} (${model.length() / 1024} КБ)\n" +
                    "   входы: $ins\n   выходы: $outs\n" +
                    "   частота $sampleRate Гц ($rateSource), scales: noise=$baseNoise length=$baseLength noise_w=$baseNoiseW\n" +
                    "   tokens.txt: ${symbols.size} символов, pad=$padId bos=$bosId eos=$eosId",
                "модель загружена, $sampleRate Гц"
            )
            session = sess
            lastError = null
            sess
        } catch (ex: Throwable) {
            lastError = ex.message
            AppLog.sound("ERR", "Не удалось загрузить модель: ${ex.javaClass.simpleName}: ${ex.message}", "модель не загрузилась")
            null
        }
    }

    /**
     * tokens.txt от sherpa-onnx: строка «символ id» (для пробела — «  3»).
     * Если id в строке нет, id = номер строки (старый формат: один символ на строку).
     */
    private fun parseTokens(lines: List<String>) {
        val map = HashMap<Char, Long>()
        for ((index, raw) in lines.withIndex()) {
            val line = raw.trimEnd('\r', '\n')
            if (line.isEmpty()) continue
            val sp = line.lastIndexOf(' ')
            val id = if (sp >= 0) line.substring(sp + 1).toLongOrNull() else null
            val symbol: Char
            val tokenId: Long
            if (id != null) {
                val sym = line.substring(0, sp)
                symbol = if (sym.isEmpty()) ' ' else sym[0]
                tokenId = id
            } else {
                symbol = line[0]
                tokenId = index.toLong()
            }
            map[symbol] = tokenId
        }
        symbols = map
        padId = map['_'] ?: 0L
        bosId = map['^'] ?: 1L
        eosId = map['$'] ?: 2L
    }

    /** Ищет файл: импорт из приложения → внешний каталог приложения → assets (копия в cacheDir). */
    private fun findFile(name: String): File? {
        val imported = File(appCtx.filesDir, "silero/$name")
        if (imported.isFile) return imported
        val ext = File(appCtx.getExternalFilesDir(null), "silero/$name")
        if (ext.isFile) return ext
        val fromAssets = File(appCtx.cacheDir, "silero_assets/$name")
        if (fromAssets.isFile) return fromAssets
        return try {
            appCtx.assets.open("silero/$name").use { input ->
                fromAssets.parentFile?.mkdirs()
                fromAssets.outputStream().use { input.copyTo(it) }
            }
            fromAssets
        } catch (e: Exception) {
            null
        }
    }

    // ---------- Воспроизведение ----------

    /**
     * AudioTrack в режиме STREAM, 16 бит: надёжно на любых прошивках. Трек стартует до записи данных,
     * в конце ждём, пока проиграются все кадры. Всё подробно пишется в лог «Звук».
     */
    private suspend fun play(pcm: FloatArray) {
        val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val sysVol = am?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: -1
        val sysMax = am?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: -1
        if (sysVol == 0) {
            AppLog.sound("ERR", "Громкость МЕДИА в системе = 0 (0/$sysMax): звук не будет слышен. Прибавьте громкость кнопками телефона", "громкость медиа = 0")
        }

        val pcm16 = ShortArray(pcm.size) { (pcm[it].coerceIn(-1f, 1f) * 32767f).toInt().toShort() }
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val bufBytes = maxOf(minBuf * 2, sampleRate)   // ~0,5 с буфера
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(bufBytes)
            .build()
        synchronized(lock) { track = t }
        val started = System.currentTimeMillis()
        try {
            if (t.state != AudioTrack.STATE_INITIALIZED) {
                AppLog.sound("ERR", "AudioTrack не инициализирован (state=${t.state}, minBuf=$minBuf)", "AudioTrack не запустился")
                return
            }
            val v = Prefs.soundVolume.coerceAtLeast(0.2f)
            t.setVolume(v)
            t.play()
            AppLog.sound(
                "INFO",
                "AudioTrack: state=${t.state}, play=${t.playState}, $sampleRate Гц, буфер $bufBytes Б (min $minBuf), " +
                    "громкость трека ${"%.2f".format(Locale.US, v)}, медиа системы $sysVol/$sysMax",
                null
            )
            var off = 0
            while (off < pcm16.size) {
                currentCoroutineContext().ensureActive()
                val n = t.write(pcm16, off, minOf(4096, pcm16.size - off), AudioTrack.WRITE_BLOCKING)
                if (n <= 0) {
                    AppLog.sound("ERR", "AudioTrack.write вернул $n (на отсчёте $off из ${pcm16.size})", "ошибка записи в AudioTrack")
                    break
                }
                off += n
            }
            // Ждём, пока проиграются все записанные кадры (с запасом по времени на случай сбоя).
            val deadline = System.currentTimeMillis() + pcm16.size * 1000L / sampleRate + 2000
            while (t.playbackHeadPosition < off && System.currentTimeMillis() < deadline) {
                currentCoroutineContext().ensureActive()
                delay(30)
            }
            delay(100)
            val head = t.playbackHeadPosition
            val ok = head >= off - sampleRate / 20
            AppLog.sound(
                if (ok) "OK" else "ERR",
                "Воспроизведено: записано $off из ${pcm16.size} отсчётов, проиграно $head, " +
                    "заняло ${System.currentTimeMillis() - started} мс" + if (ok) "" else " — звук не доиграл (системный сбой или перехват аудио)",
                if (ok) "проиграно за ${System.currentTimeMillis() - started} мс" else "звук не доиграл"
            )
        } catch (e: IllegalStateException) {
            // Трек освободил stop(): реплику прервали намеренно.
            AppLog.sound("INFO", "Воспроизведение прервано (новая реплика или остановка)", "озвучка прервана")
        } finally {
            synchronized(lock) {
                if (track === t) {
                    runCatching { t.stop() }
                    t.release()
                    track = null
                }
            }
        }
    }
}
