package com.AX

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class JarvisAccessibility : AccessibilityService() {

    override fun onServiceConnected() {
        Prefs.init(this)
        instance = this
        AppLog.add("INFO", "Служба доступности включена")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    companion object {
        @Volatile
        var instance: JarvisAccessibility? = null
    }
}