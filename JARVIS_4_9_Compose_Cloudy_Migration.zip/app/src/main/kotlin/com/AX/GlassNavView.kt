package com.AX

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.dynamicanimation.animation.DynamicAnimation
import androidx.dynamicanimation.animation.SpringAnimation
import androidx.dynamicanimation.animation.SpringForce

/**
 * Стеклянная нижняя панель на чистых View (без BottomNavigationView).
 * Высота задаётся снаружи (64dp) и не добавляет внутренних отступов Material.
 * Пилюля выбранной вкладки едет по пружине (androidx.dynamicanimation).
 */
class GlassNavView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : FrameLayout(context, attrs, defStyle) {

    private class Slot(val id: Int, val title: String, val icon: Int)

    private val slots = listOf(
        Slot(R.id.nav_home, "Главная", R.drawable.ic_nav_home),
        Slot(R.id.nav_logs, "Логи", R.drawable.ic_nav_logs),
        Slot(R.id.nav_settings, "Настройки", R.drawable.ic_nav_settings)
    )

    private val dp = resources.displayMetrics.density
    private val inset = 6 * dp
    private val pillInset = 4 * dp
    private var slotWidth = 0f
    private var selectedIndex = 0

    private val slotIcons = ArrayList<ImageView>()
    private val slotLabels = ArrayList<TextView>()

    private val indicator = View(context).apply {
        background = ContextCompat.getDrawable(context, R.drawable.glass_indicator)
    }

    private val springX = SpringAnimation(indicator, DynamicAnimation.TRANSLATION_X).apply {
        spring = SpringForce()
            .setStiffness(SpringForce.STIFFNESS_MEDIUM)
            .setDampingRatio(SpringForce.DAMPING_RATIO_LOW_BOUNCY)
    }

    private val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }

    /** Вызывается при смене вкладки (тапом или программно). */
    var onItemSelected: ((Int) -> Unit)? = null

    var selectedItemId: Int
        get() = slots[selectedIndex].id
        set(value) = select(value, notify = true)

    init {
        val tint = ContextCompat.getColorStateList(context, R.color.glass_nav_item)
        val iconSize = (22 * dp).toInt()

        addView(indicator, LayoutParams(0, LayoutParams.MATCH_PARENT).apply {
            topMargin = inset.toInt()
            bottomMargin = inset.toInt()
        })
        addView(row, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT).apply {
            setMargins(inset.toInt(), inset.toInt(), inset.toInt(), inset.toInt())
        })

        slots.forEach { slot ->
            val icon = ImageView(context).apply {
                setImageResource(slot.icon)
                imageTintList = tint
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }
            val label = TextView(context).apply {
                text = slot.title
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(tint)
                letterSpacing = 0.02f
            }
            val cell = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
                addView(icon, LinearLayout.LayoutParams(iconSize, iconSize))
                addView(label, LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
                setOnClickListener { selectedItemId = slot.id }
            }
            SpringPress.attach(cell)
            row.addView(cell, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f))
            slotIcons += icon
            slotLabels += label
        }
        updateSelectedViews()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        slotWidth = (w - 2 * inset) / slots.size
        val lp = indicator.layoutParams as LayoutParams
        lp.width = (slotWidth - 2 * pillInset).toInt()
        indicator.layoutParams = lp
        springX.cancel()
        indicator.translationX = targetX(selectedIndex)
    }

    private fun targetX(index: Int): Float = inset + pillInset + index * slotWidth

    private fun select(id: Int, notify: Boolean) {
        val index = slots.indexOfFirst { it.id == id }
        if (index < 0 || index == selectedIndex) return
        selectedIndex = index
        updateSelectedViews()
        if (slotWidth > 0f) springX.animateToFinalPosition(targetX(index))
        if (notify) onItemSelected?.invoke(slots[index].id)
    }

    private fun updateSelectedViews() {
        slotIcons.forEachIndexed { i, v -> v.isSelected = i == selectedIndex }
        slotLabels.forEachIndexed { i, v -> v.isSelected = i == selectedIndex }
    }
}
