package com.AX

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * «Реактор»: свечение, кольцо с насечками, три вращающиеся дуги и ядро.
 * Во время прослушивания реагирует на громкость голоса (см. [setLevel]).
 * Анимация идёт покадрово, пока вид виден на экране.
 */
class ReactorView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    /** Идёт запись голоса: реактор ярче и пульсирует от громкости. */
    var listening = false

    /** Распознавание / выполнение команды: фиолетовый цвет и быстрое вращение. */
    var busy = false

    private var level = 0f
    private var levelSmooth = 0f
    private var mix = 0f
    private var time = 0f
    private var spin = 0f
    private var lastFrame = 0L

    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()

    private var radius = 0f
    private var ticks = FloatArray(0)
    private var glowShader: Shader? = null
    private var coreShader: Shader? = null
    private var shaderTint = 0

    private val ringScale = floatArrayOf(0.80f, 0.64f, 0.50f)
    private val ringSweep = floatArrayOf(110f, 70f, 140f)
    private val ringWidth = floatArrayOf(3.2f, 2.6f, 2.2f)

    /** Громкость из onRmsChanged (примерно от -2 до 10 дБ). */
    fun setLevel(rmsDb: Float) {
        level = ((rmsDb + 2f) / 12f).coerceIn(0f, 1f)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        radius = min(w, h) / 2f
        glowShader = null
        coreShader = null

        val count = 72
        val outer = radius * 0.97f
        ticks = FloatArray(count * 4)
        for (i in 0 until count) {
            val a = i * 2.0 * PI / count
            val c = cos(a).toFloat()
            val s = sin(a).toFloat()
            val len = if (i % 6 == 0) radius * 0.07f else radius * 0.035f
            ticks[i * 4] = c * outer
            ticks[i * 4 + 1] = s * outer
            ticks[i * 4 + 2] = c * (outer - len)
            ticks[i * 4 + 3] = s * (outer - len)
        }
    }

    override fun onDetachedFromWindow() {
        lastFrame = 0L
        super.onDetachedFromWindow()
    }

    private fun buildShaders(tint: Int) {
        glowShader = RadialGradient(
            0f, 0f, radius,
            intArrayOf(
                ColorUtils.setAlphaComponent(tint, 0x70),
                ColorUtils.setAlphaComponent(tint, 0x1C),
                ColorUtils.setAlphaComponent(tint, 0x00)
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        coreShader = RadialGradient(
            0f, 0f, radius * 0.17f,
            intArrayOf(Color.WHITE, tint),
            floatArrayOf(0.15f, 1f),
            Shader.TileMode.CLAMP
        )
        shaderTint = tint
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (radius <= 0f) return

        val now = SystemClock.uptimeMillis()
        val dt = if (lastFrame == 0L) 0f else ((now - lastFrame) / 1000f).coerceAtMost(0.05f)
        lastFrame = now
        time += dt
        spin += dt * (24f + 70f * mix + if (busy) 120f else 0f)
        mix += ((if (listening) 1f else 0f) - mix) * 0.08f
        levelSmooth += ((if (listening) level else 0f) - levelSmooth) * 0.18f

        val amp = levelSmooth
        val breathe = sin(time * 3.1f)
        val tint = if (busy) COLOR_BUSY else ColorUtils.blendARGB(COLOR_IDLE, COLOR_ACTIVE, mix)
        if (glowShader == null || coreShader == null || shaderTint != tint) buildShaders(tint)

        canvas.save()
        canvas.translate(width / 2f, height / 2f)

        // свечение
        val glowScale = 1f + 0.03f * breathe + 0.12f * amp
        canvas.save()
        canvas.scale(glowScale, glowScale)
        paint.style = Paint.Style.FILL
        paint.shader = glowShader
        paint.alpha = ((0.55f + 0.45f * mix) * 255f).toInt()
        canvas.drawCircle(0f, 0f, radius, paint)
        paint.shader = null
        canvas.restore()

        // кольцо с насечками
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.BUTT
        paint.strokeWidth = 1.4f * density
        paint.color = ColorUtils.setAlphaComponent(tint, 0x66)
        canvas.save()
        canvas.rotate(-spin * 0.25f)
        canvas.drawLines(ticks, paint)
        canvas.restore()

        // три кольца с вращающимися дугами
        for (i in 0..2) {
            val r = radius * ringScale[i]
            paint.strokeCap = Paint.Cap.BUTT
            paint.strokeWidth = density
            paint.color = ColorUtils.setAlphaComponent(tint, 0x26)
            canvas.drawCircle(0f, 0f, r, paint)

            paint.strokeCap = Paint.Cap.ROUND
            paint.strokeWidth = ringWidth[i] * density
            paint.color = ColorUtils.setAlphaComponent(tint, 0xE6 - i * 0x30)
            oval.set(-r, -r, r, r)
            val dir = if (i % 2 == 0) 1f else -1f
            val start = spin * (1f + i * 0.7f) * dir + i * 120f
            canvas.drawArc(oval, start, ringSweep[i], false, paint)
            canvas.drawArc(oval, start + 180f, ringSweep[i] * 0.35f, false, paint)
        }

        // кольцо громкости
        val levelAlpha = (mix * (0x30 + 0xA0 * amp)).toInt().coerceIn(0, 255)
        paint.strokeCap = Paint.Cap.BUTT
        paint.strokeWidth = 2f * density
        paint.color = ColorUtils.setAlphaComponent(tint, levelAlpha)
        canvas.drawCircle(0f, 0f, radius * (0.28f + 0.10f * amp), paint)

        // тонкое кольцо вокруг ядра
        paint.strokeWidth = density
        paint.color = ColorUtils.setAlphaComponent(tint, 0x90)
        canvas.drawCircle(0f, 0f, radius * 0.22f, paint)

        // ядро
        val coreScale = 1f + 0.06f * breathe + 0.30f * amp
        canvas.save()
        canvas.scale(coreScale, coreScale)
        paint.style = Paint.Style.FILL
        paint.shader = coreShader
        paint.alpha = 255
        canvas.drawCircle(0f, 0f, radius * 0.17f, paint)
        paint.shader = null
        canvas.restore()

        canvas.restore()
        postInvalidateOnAnimation()
    }

    private companion object {
        const val COLOR_IDLE = 0xFF2CA7C9.toInt()
        const val COLOR_ACTIVE = 0xFF4DE3FF.toInt()
        const val COLOR_BUSY = 0xFF9B8CFF.toInt()
    }
}
