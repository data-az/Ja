package com.AX

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore

/**
 * Роли приложений: «фото», «камера», «контакты»... — это не названия, а ФУНКЦИИ.
 *
 * Раньше приложение искалось только по подписи под иконкой. Но у галереи подпись может быть
 * «Фотоснимки», «Галерея», «Google Фото», «Mi Галерея», и никакая нечёткая оценка строк
 * не угадает, что «фото» — это именно она (а промах уходил к случайному приложению).
 * Теперь на такие слова отвечает сама Android: какое приложение назначено на эту функцию.
 */
object AppRoles {

    class Role(
        val id: String,
        /** Название функции для подсказки модели и логов. */
        val title: String,
        /** Слова, которыми функцию называют вслух (лягут в стемминг при сравнении). */
        val phrases: List<String>,
        /** Интенты в порядке приоритета: первый, на который система нашла приложение, побеждает. */
        val intents: () -> List<Intent>
    )

    private fun main(category: String) = Intent(Intent.ACTION_MAIN).addCategory(category)

    // Названия категорий — строками: часть констант появилась в новых API, а строка работает везде.
    private val roles: List<Role> = listOf(
        Role(
            "gallery", "галерея",
            listOf(
                "фото", "фотки", "фотографии", "фотография", "фотоснимки", "фотоальбом", "снимки",
                "галерея", "картинки", "изображения", "альбом", "gallery", "photos", "pictures", "images"
            )
        ) {
            listOf(
                main("android.intent.category.APP_GALLERY"),
                Intent(Intent.ACTION_VIEW).setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
            )
        },
        Role(
            "camera", "камера",
            listOf("камера", "фотоаппарат", "camera", "снять фото")
        ) {
            listOf(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
        },
        Role(
            "phone", "телефон (набор номера)",
            listOf("телефон", "звонилка", "дозвонщик", "набор номера", "dialer", "phone")
        ) {
            listOf(Intent(Intent.ACTION_DIAL))
        },
        Role(
            "contacts", "контакты",
            listOf("контакты", "телефонная книга", "адресная книга", "записная книжка", "contacts")
        ) {
            listOf(
                main("android.intent.category.APP_CONTACTS"),
                Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)
            )
        },
        Role(
            "messages", "сообщения (SMS)",
            listOf("сообщения", "смс", "sms", "messages", "messaging")
        ) {
            listOf(main("android.intent.category.APP_MESSAGING"), Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")))
        },
        Role(
            "browser", "браузер",
            listOf("браузер", "интернет", "веб", "web", "browser")
        ) {
            listOf(main("android.intent.category.APP_BROWSER"), Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")))
        },
        Role("calculator", "калькулятор", listOf("калькулятор", "calculator")) {
            listOf(main("android.intent.category.APP_CALCULATOR"))
        },
        Role("calendar", "календарь", listOf("календарь", "calendar")) {
            listOf(main("android.intent.category.APP_CALENDAR"))
        },
        Role("email", "почта", listOf("почта", "email", "e-mail", "емейл", "имейл")) {
            listOf(main("android.intent.category.APP_EMAIL"))
        },
        Role("maps", "карты", listOf("карты", "навигация", "навигатор", "maps")) {
            listOf(main("android.intent.category.APP_MAPS"))
        },
        Role("music", "музыка", listOf("музыка", "плеер", "музыкальный плеер", "music")) {
            listOf(main("android.intent.category.APP_MUSIC"))
        },
        Role(
            "files", "файлы",
            listOf("файлы", "проводник", "файловый менеджер", "диспетчер файлов", "files", "file manager")
        ) {
            listOf(main("android.intent.category.APP_FILES"))
        },
        Role("clock", "часы / будильник", listOf("часы", "будильник", "будильники", "таймер", "секундомер", "clock", "alarm")) {
            listOf(Intent(AlarmClock.ACTION_SHOW_ALARMS))
        },
        Role("weather", "погода", listOf("погода", "weather")) {
            listOf(main("android.intent.category.APP_WEATHER"))
        }
    )

    /** Фраза → роль. Сравнение по основам слов: «галерею», «фотки», «контактов» тоже находятся. */
    fun match(core: String, engine: SmartAppSearchEngine): Role? {
        val q = engine.stemTokens(engine.normalize(core)).replace(" ", "")
        if (q.isEmpty()) return null
        for (r in roles) {
            for (p in r.phrases) {
                val stemmed = engine.stemTokens(engine.normalize(p)).replace(" ", "")
                if (same(stemmed, q)) return r
            }
        }
        return null
    }

    /** Основы слов совпадают; разница в 1–2 буквы на конце допустима («галерею» → «галер», «галерея» → «галере»). */
    private fun same(a: String, b: String): Boolean {
        if (a == b) return true
        if (minOf(a.length, b.length) < 4 || kotlin.math.abs(a.length - b.length) > 2) return false
        return a.startsWith(b) || b.startsWith(a)
    }

    /**
     * Приложение, которое система назначила на роль. Сначала выбор «по умолчанию»; если его нет —
     * прошивочное приложение, затем любое. Возвращает null, если на роль нет ни одного приложения.
     */
    fun resolve(ctx: Context, role: Role): AppInfo? {
        val pm = ctx.packageManager
        for (intent in role.intents()) {
            try {
                // Выбор по умолчанию (если пользователь его делал).
                val def = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo
                if (def != null && def.packageName != "android" && !def.packageName.startsWith("com.android.internal")) {
                    return info(pm, def.packageName, def.name.takeIf { intent.action == Intent.ACTION_MAIN })
                }
                val all = pm.queryIntentActivities(intent, 0)
                    .mapNotNull { it.activityInfo }
                    .filter { it.exported && it.packageName != "android" }
                if (all.isEmpty()) continue
                // Прошивочное приложение надёжнее: оно и есть «галерея» этого телефона.
                val pick = all.firstOrNull { isSystem(it.applicationInfo) } ?: all.first()
                return info(pm, pick.packageName, pick.name.takeIf { intent.action == Intent.ACTION_MAIN })
            } catch (e: Exception) {
                // Нет доступа к пакету или ошибка PackageManager: пробуем следующий интент.
            }
        }
        return null
    }

    private fun isSystem(ai: ApplicationInfo): Boolean = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0

    /** [cls] задаём только для MAIN-интентов: активность просмотра без данных открывать нельзя, запускаем пакет целиком. */
    private fun info(pm: PackageManager, pkg: String, cls: String?): AppInfo {
        val ai = pm.getApplicationInfo(pkg, 0)
        return AppInfo(pm.getApplicationLabel(ai).toString(), pkg, isSystem(ai), cls)
    }
}
