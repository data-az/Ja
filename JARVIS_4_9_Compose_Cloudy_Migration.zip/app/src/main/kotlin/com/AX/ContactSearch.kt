package com.AX

import android.content.Context
import android.provider.ContactsContract

/**
 * Поиск контакта по произнесённому имени: «позвони маме», «позвони Ивану Петрову».
 * Падежи («маме», «Ивану»), порядок слов («Петров Иван»), латиница («Alex» ↔ «Алекс») и
 * небольшие ошибки распознавания обрабатываются общим движком сравнения строк.
 */
object ContactSearch {

    class Phone(val number: String, val type: Int, val primary: Boolean)

    class Contact(val id: Long, val name: String, val phones: List<Phone>)

    class Match(val contact: Contact, val score: Float)

    /** Слова, которые не часть имени: «позвони пожалуйста на номер контакту маша». */
    private val NOISE = setOf(
        "пожалуйста", "пожалуй", "плиз", "мне", "на", "номер", "номеру", "по", "имени", "контакту",
        "контакт", "абоненту", "джарвис", "ка", "давай", "ну", "быстро", "срочно", "сейчас", "и", "а"
    )

    private const val MIN_SCORE = 0.78f

    /** Все контакты с номерами (один контакт — одна запись, номера без дублей). */
    fun load(ctx: Context): List<Contact> {
        val names = LinkedHashMap<Long, String>()
        val phones = LinkedHashMap<Long, ArrayList<Phone>>()
        val proj = arrayOf(
            ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER,
            ContactsContract.CommonDataKinds.Phone.TYPE,
            ContactsContract.CommonDataKinds.Phone.IS_SUPER_PRIMARY
        )
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, proj, null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val name = c.getString(1) ?: continue
                val number = c.getString(2)?.trim().orEmpty()
                if (number.isEmpty()) continue
                names.putIfAbsent(id, name)
                val list = phones.getOrPut(id) { ArrayList() }
                val digits = number.filter { it.isDigit() }
                if (list.none { p -> p.number.filter { it.isDigit() } == digits }) {
                    list.add(Phone(number, c.getInt(3), c.getInt(4) != 0))
                }
            }
        }
        return names.map { (id, n) -> Contact(id, n, phones[id].orEmpty()) }
    }

    /** Имя из фразы после слова «позвони» (без служебных слов). */
    fun spokenName(rest: String): String =
        Commands.engine.normalize(rest).split(' ').filter { it.isNotEmpty() && it !in NOISE }.joinToString(" ")

    /** Лучшие совпадения по убыванию оценки (только выше порога). */
    fun find(contacts: List<Contact>, spoken: String): List<Match> {
        val words = spoken.split(' ').filter { it.isNotEmpty() }
        if (words.isEmpty()) return emptyList()
        val engine = Commands.engine
        val out = ArrayList<Match>()
        for (c in contacts) {
            val nameWords = engine.normalize(c.name).split(' ').filter { it.isNotEmpty() }
            if (nameWords.isEmpty()) continue
            // Каждое сказанное слово должно найтись среди слов имени (в любом порядке).
            var sum = 0f
            var ok = true
            for (w in words) {
                var best = 0f
                for (nw in nameWords) {
                    val s = engine.similarity(w, nw)
                    if (s > best) best = s
                }
                if (best < MIN_SCORE) { ok = false; break }
                sum += best
            }
            if (!ok) continue
            val avg = sum / words.size
            // Чем больше слов имени осталось неназванными, тем слабее: «Иван» → «Иван Петров» чуть хуже, чем «Иван».
            val coverage = words.size.toFloat() / nameWords.size
            out.add(Match(c, avg * (0.93f + 0.07f * coverage.coerceAtMost(1f))))
        }
        return out.sortedByDescending { it.score }
    }

    /** Какой номер набрать: основной → мобильный → первый. */
    fun pickNumber(c: Contact): String? {
        c.phones.firstOrNull { it.primary }?.let { return it.number }
        c.phones.firstOrNull { it.type == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE }?.let { return it.number }
        return c.phones.firstOrNull()?.number
    }

}
