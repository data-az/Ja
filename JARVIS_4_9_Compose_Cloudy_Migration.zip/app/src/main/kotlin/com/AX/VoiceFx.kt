package com.AX

import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * ВСЯ кастомизация голоса описана ОДНИМ списком [VoiceSpec.all].
 *
 * Чтобы добавить новый параметр: допишите строку Param(...) в [VoiceSpec.all] и прочитайте его
 * в [VoiceFx.process] (или в Voice.synthesizeAll) через `p["ключ"]`. Ползунок на экране,
 * сохранение, пресеты, копирование/вставка, «случайный голос» и сброс подхватятся сами.
 */
class Param(
    val key: String,
    val group: String,
    val title: String,
    val hint: String,
    val min: Float,
    val max: Float,
    val def: Float,
    val step: Float,
    /** true — рисуется переключателем (значение 0/1). */
    val toggle: Boolean = false,
    /** Насколько параметр меняется кнопкой «Случайный» (0 — не трогать). */
    val random: Float = 0f,
    val fmt: (Float) -> String = { String.format(Locale.US, "%.2f", it) }
)

object VoiceSpec {
    const val G_SYNTH = "Синтез и темп"
    const val G_TONE = "Тон и вибрато"
    const val G_EQ = "Эквалайзер и фильтры"
    const val G_CHAR = "Характер голоса"
    const val G_SPACE = "Эхо и пространство"
    const val G_DYN = "Динамика и выход"

    val groups = listOf(G_SYNTH, G_TONE, G_EQ, G_CHAR, G_SPACE, G_DYN)

    private fun f1(v: Float) = String.format(Locale.US, "%.1f", v)
    private fun f2(v: Float) = String.format(Locale.US, "%.2f", v)
    private fun n0(v: Float) = v.roundToInt().toString()
    private fun pct(v: Float) = "${(v * 100f).roundToInt()}%"
    private fun db(v: Float) = String.format(Locale.US, "%+.1f дБ", v)
    private fun ms(v: Float) = "${v.roundToInt()} мс"

    val all: List<Param> = listOf(
        // ---------- Синтез (влияет на саму модель Piper) ----------
        Param("speed", G_SYNTH, "Скорость речи", "1.0 — как у модели. Меняет темп без изменения высоты (через length_scale)",
            0.5f, 2.0f, 1.0f, 0.01f, random = 0.12f) { "${f2(it)}×" },
        Param("noise", G_SYNTH, "Живость интонации (noise_scale)", "Больше — выразительнее и «рваннее», меньше — ровно и монотонно. 0 = как в модели",
            0f, 1.5f, 0f, 0.01f, random = 0.15f) { if (it < 0.005f) "авто" else f2(it) },
        Param("noisew", G_SYNTH, "Ритм слогов (noise_w)", "Разброс длительности звуков: больше — естественнее, меньше — «как робот». 0 = как в модели",
            0f, 1.5f, 0f, 0.01f, random = 0.15f) { if (it < 0.005f) "авто" else f2(it) },
        Param("speaker", G_SYNTH, "Номер голоса (speaker id)", "Только для многоголосых моделей. У одноголосой игнорируется",
            0f, 99f, 0f, 1f) { n0(it) },
        Param("lively", G_SYNTH, "Случайность от фразы к фразе", "Каждое предложение чуть по-разному по темпу и интонации — меньше «машинности»",
            0f, 1f, 0f, 0.01f, random = 0.2f) { pct(it) },
        Param("pauseS", G_SYNTH, "Пауза между предложениями", "Тишина после точки, «?» и «!»",
            0f, 1500f, 180f, 10f) { ms(it) },
        Param("pauseP", G_SYNTH, "Пауза между абзацами", "Тишина на переносе строки в тексте ответа",
            0f, 3000f, 400f, 10f) { ms(it) },

        // ---------- Тон ----------
        Param("pitch", G_TONE, "Тональность (общая)", "Ниже 1.0 — бас и металл, выше — тоньше. В скобках полутоны",
            PitchShifter.MIN, PitchShifter.MAX, 1.0f, 0.01f, random = 0.22f) {
            String.format(Locale.US, "%.2f× (%+.1f пт)", it, 12f * (ln(it) / ln(2f)))
        },
        Param("vibDepth", G_TONE, "Вибрато: глубина", "Лёгкое «дрожание» высоты, как у певца или синтезатора",
            0f, 100f, 0f, 1f, random = 0.25f) { "${n0(it)} цент" },
        Param("vibRate", G_TONE, "Вибрато: частота", "Скорость дрожания, Гц",
            0.5f, 12f, 5.5f, 0.1f) { "${f1(it)} Гц" },

        // ---------- Эквалайзер ----------
        Param("hp", G_EQ, "Срез низов (high-pass)", "Убирает гул ниже этой частоты. 0 — выкл",
            0f, 500f, 0f, 5f, random = 0.15f) { if (it < 20f) "выкл" else "${n0(it)} Гц" },
        Param("lp", G_EQ, "Срез верхов (low-pass)", "Убирает «шипение» выше этой частоты. 0 — выкл",
            0f, 11000f, 0f, 50f, random = 0.1f) { if (it < 800f) "выкл" else "${n0(it)} Гц" },
        Param("lowDb", G_EQ, "Низы (полка)", "Бас и «грудь» голоса",
            -15f, 15f, 0f, 0.5f, random = 0.35f) { db(it) },
        Param("lowHz", G_EQ, "Низы: частота полки", "До какой частоты действует регулятор низов",
            60f, 400f, 140f, 5f) { "${n0(it)} Гц" },
        Param("midDb", G_EQ, "Середина (колокол)", "Разборчивость, «нос» и телефонность",
            -15f, 15f, 0f, 0.5f, random = 0.35f) { db(it) },
        Param("midHz", G_EQ, "Середина: частота", "Центр колокола",
            200f, 5000f, 1200f, 50f, random = 0.1f) { "${n0(it)} Гц" },
        Param("midQ", G_EQ, "Середина: добротность", "Больше — уже полоса, резче «резонанс»",
            0.3f, 5f, 1f, 0.05f) { f2(it) },
        Param("highDb", G_EQ, "Верхи (полка)", "Чёткость согласных и «воздух»",
            -15f, 15f, 0f, 0.5f, random = 0.35f) { db(it) },
        Param("highHz", G_EQ, "Верхи: частота полки", "От какой частоты действует регулятор верхов",
            2500f, 9000f, 5500f, 100f) { "${n0(it)} Гц" },

        // ---------- Характер ----------
        Param("robotMix", G_CHAR, "Робот (кольцевой модулятор)", "Классический «далековский» голос. Количество эффекта",
            0f, 1f, 0f, 0.01f, random = 0.5f) { pct(it) },
        Param("robotHz", G_CHAR, "Робот: частота несущей", "Низкая (20–80) — рычание, высокая (200+) — звон",
            20f, 500f, 70f, 1f, random = 0.3f) { "${n0(it)} Гц" },
        Param("metalMix", G_CHAR, "Металл (резонатор)", "Короткий резонанс — голос «из железа», фирменный Jarvis",
            0f, 1f, 0f, 0.01f, random = 0.5f) { pct(it) },
        Param("metalMs", G_CHAR, "Металл: задержка", "Меньше — тоньше и звонче, больше — «бочка»",
            0.5f, 20f, 3f, 0.1f, random = 0.3f) { "${f1(it)} мс" },
        Param("metalFb", G_CHAR, "Металл: резонанс", "Сколько звенит. Выше 0.85 — уже свист",
            0f, 0.95f, 0.6f, 0.01f, random = 0.2f) { f2(it) },
        Param("chorusMix", G_CHAR, "Двойной голос (хорус)", "Подмешивает чуть расстроенные копии — «объём» и «двойник»",
            0f, 1f, 0f, 0.01f, random = 0.5f) { pct(it) },
        Param("chorusMs", G_CHAR, "Хорус: глубина", "Насколько копии «плавают» по времени",
            1f, 25f, 8f, 0.5f, random = 0.2f) { "${f1(it)} мс" },
        Param("chorusRate", G_CHAR, "Хорус: скорость", "Как быстро плавают копии",
            0.1f, 4f, 0.8f, 0.05f) { "${f2(it)} Гц" },
        Param("drive", G_CHAR, "Перегруз: сила", "Насыщение лампового типа. Работает вместе с «Перегруз: количество»",
            1f, 20f, 1f, 0.1f, random = 0.15f) { f1(it) },
        Param("distMix", G_CHAR, "Перегруз: количество", "0 — чистый звук",
            0f, 1f, 0f, 0.01f, random = 0.4f) { pct(it) },
        Param("bits", G_CHAR, "Разрядность (битовая «каша»)", "16 — выкл. Меньше — цифровой хрип, как у старой рации",
            4f, 16f, 16f, 1f, random = 0.1f) { if (it >= 16f) "выкл" else "${n0(it)} бит" },
        Param("down", G_CHAR, "Понижение частоты дискретизации", "1 — выкл. Больше — «жестяной» звук",
            1f, 16f, 1f, 1f, random = 0.1f) { if (it <= 1f) "выкл" else "÷${n0(it)}" },
        Param("hiss", G_CHAR, "Шум эфира", "Лёгкое шипение под голосом. Минимум — выкл",
            -70f, -20f, -70f, 1f, random = 0.1f) { if (it <= -69f) "выкл" else "${n0(it)} дБ" },

        // ---------- Пространство ----------
        Param("echoMix", G_SPACE, "Эхо: количество", "Повторы голоса",
            0f, 1f, 0f, 0.01f, random = 0.4f) { pct(it) },
        Param("echoMs", G_SPACE, "Эхо: интервал", "Время между повторами",
            40f, 900f, 250f, 10f, random = 0.2f) { ms(it) },
        Param("echoFb", G_SPACE, "Эхо: затухание", "Сколько повторов слышно",
            0f, 0.85f, 0.35f, 0.01f, random = 0.2f) { f2(it) },
        Param("revMix", G_SPACE, "Реверберация: количество", "Эффект помещения: от кабинета до пещеры",
            0f, 1f, 0f, 0.01f, random = 0.5f) { pct(it) },
        Param("revSize", G_SPACE, "Реверберация: размер", "Больше — просторнее и длиннее хвост",
            0f, 1f, 0.5f, 0.01f, random = 0.3f) { pct(it) },
        Param("revDamp", G_SPACE, "Реверберация: глухость", "Больше — хвост темнее и мягче",
            0f, 1f, 0.5f, 0.01f, random = 0.2f) { pct(it) },
        Param("tail", G_SPACE, "Доп. тишина в конце", "Чтобы хвост эха не обрезался. Хвост эха/реверберации добавляется сам",
            0f, 3000f, 0f, 50f) { ms(it) },

        // ---------- Динамика и выход ----------
        Param("compThr", G_DYN, "Компрессор: порог", "Выравнивает громкость: тихое подтягивает, громкое прижимает. Максимум — выкл",
            -40f, 0f, 0f, 1f, random = 0.15f) { if (it > -0.5f) "выкл" else "${n0(it)} дБ" },
        Param("compRatio", G_DYN, "Компрессор: степень", "Больше — жёстче прижимает",
            1f, 20f, 3f, 0.5f) { "${f1(it)}:1" },
        Param("compMakeup", G_DYN, "Компрессор: подъём громкости", "Компенсация после сжатия",
            0f, 18f, 0f, 0.5f) { db(it) },
        Param("peak", G_DYN, "Нормализация пика", "Подгоняет самую громкую точку к этому уровню. 0 — выкл",
            0f, 1f, 0.95f, 0.01f) { if (it < 0.01f) "выкл" else f2(it) },
        Param("gain", G_DYN, "Усиление после всего", "Итоговая громкость относительно нормализации (лимитер защитит от хруста)",
            -12f, 12f, 0f, 0.5f) { db(it) },
        Param("limiter", G_DYN, "Мягкий лимитер", "Не даёт звуку хрипеть при больших усилениях",
            0f, 1f, 1f, 1f, toggle = true) { if (it > 0.5f) "вкл" else "выкл" },
        Param("fadeIn", G_DYN, "Плавное начало", "Убирает щелчок в начале реплики",
            0f, 500f, 3f, 1f) { ms(it) },
        Param("fadeOut", G_DYN, "Плавный конец", "Убирает щелчок в конце реплики",
            0f, 1000f, 20f, 5f) { ms(it) }
    )

    val byKey: Map<String, Param> = all.associateBy { it.key }
}

/** Набор значений всех параметров. Хранятся только отличия от значений по умолчанию. */
class VoiceParams {
    private val map = HashMap<String, Float>()

    operator fun get(key: String): Float = map[key] ?: VoiceSpec.byKey[key]?.def ?: 0f

    operator fun set(key: String, v: Float) {
        val sp = VoiceSpec.byKey[key] ?: return
        map[key] = v.coerceIn(sp.min, sp.max)
    }

    fun copy(): VoiceParams = VoiceParams().also { it.map.putAll(map) }

    fun reset() = map.clear()

    fun resetGroup(group: String) {
        for (sp in VoiceSpec.all) if (sp.group == group) map.remove(sp.key)
    }

    fun resetKey(key: String) { map.remove(key) }

    fun isDefault(key: String): Boolean {
        val sp = VoiceSpec.byKey[key] ?: return true
        return abs(this[key] - sp.def) < 1e-4f
    }

    /** «ключ=значение» только для изменённых параметров — для журнала. */
    fun describeChanges(): String {
        val parts = VoiceSpec.all.filter { !isDefault(it.key) }.map { "${it.key}=${it.fmt(this[it.key])}" }
        return if (parts.isEmpty()) "без изменений (чистая модель)" else parts.joinToString(", ")
    }

    fun toJson(): String {
        val o = JSONObject()
        for ((k, v) in map) if (!isDefault(k)) o.put(k, v.toDouble())
        return o.toString()
    }

    /** Случайно «шевелит» параметры вокруг текущих значений. [amount] 0.2 — чуть-чуть, 0.7 — сильно. */
    fun randomize(amount: Float, rnd: Random = Random()) {
        for (sp in VoiceSpec.all) {
            if (sp.random <= 0f) continue
            val span = sp.max - sp.min
            val delta = (rnd.nextFloat() * 2f - 1f) * amount * sp.random * span
            var v = this[sp.key] + delta
            if (sp.step > 0f) v = (v / sp.step).roundToInt() * sp.step
            this[sp.key] = v
        }
    }

    companion object {
        /** null — если это не JSON. Неизвестные ключи пропускаются. */
        fun fromJson(s: String?): VoiceParams? {
            if (s.isNullOrBlank()) return null
            return try {
                val o = JSONObject(s)
                val p = VoiceParams()
                val keys = o.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    if (VoiceSpec.byKey.containsKey(k)) p[k] = o.getDouble(k).toFloat()
                }
                p
            } catch (e: Exception) {
                null
            }
        }
    }
}

/** Готовые и пользовательские пресеты. Пользовательские лежат в Prefs.voicePresets (JSON). */
object VoicePresets {

    val builtin: LinkedHashMap<String, Map<String, Float>> = linkedMapOf(
        "Чистый" to emptyMap<String, Float>(),
        "Джарвис" to mapOf(
            "pitch" to 0.88f, "hp" to 70f, "lowDb" to 4f, "lowHz" to 150f,
            "midDb" to 2f, "midHz" to 2200f, "highDb" to 2.5f, "highHz" to 6000f,
            "metalMix" to 0.18f, "metalMs" to 2.5f, "metalFb" to 0.55f,
            "chorusMix" to 0.22f, "chorusMs" to 8f, "chorusRate" to 0.6f,
            "revMix" to 0.1f, "revSize" to 0.35f, "revDamp" to 0.6f,
            "compThr" to -22f, "compRatio" to 3.5f, "compMakeup" to 4f
        ),
        "Пятница" to mapOf(
            "pitch" to 1.1f, "speed" to 1.05f, "lowDb" to -2f, "highDb" to 3f, "highHz" to 6500f,
            "chorusMix" to 0.12f, "revMix" to 0.08f,
            "compThr" to -20f, "compRatio" to 2.5f, "compMakeup" to 3f
        ),
        "Робот" to mapOf(
            "pitch" to 0.92f, "robotMix" to 0.55f, "robotHz" to 60f,
            "metalMix" to 0.35f, "metalMs" to 4f, "metalFb" to 0.6f, "bits" to 12f, "lp" to 6500f
        ),
        "Дарт" to mapOf(
            "pitch" to 0.62f, "speed" to 0.9f, "lowDb" to 6f, "drive" to 3f, "distMix" to 0.25f,
            "revMix" to 0.2f, "revSize" to 0.6f, "compThr" to -25f, "compRatio" to 4f
        ),
        "Рация" to mapOf(
            "hp" to 350f, "lp" to 3200f, "midDb" to 5f, "midHz" to 1800f, "midQ" to 1.2f,
            "drive" to 4f, "distMix" to 0.35f, "bits" to 10f, "down" to 2f, "hiss" to -42f,
            "compThr" to -28f, "compRatio" to 6f, "compMakeup" to 6f
        ),
        "Пещера" to mapOf(
            "speed" to 0.95f, "revMix" to 0.45f, "revSize" to 0.9f, "revDamp" to 0.35f,
            "echoMix" to 0.25f, "echoMs" to 320f, "echoFb" to 0.45f, "tail" to 1500f
        ),
        "Бас" to mapOf(
            "pitch" to 0.7f, "lowDb" to 8f, "lowHz" to 120f, "highDb" to -2f,
            "compThr" to -24f, "compRatio" to 3f, "compMakeup" to 3f
        ),
        "Мульт" to mapOf(
            "pitch" to 1.45f, "speed" to 1.1f, "lively" to 0.3f, "chorusMix" to 0.1f
        )
    )

    fun build(m: Map<String, Float>): VoiceParams = VoiceParams().also { p -> m.forEach { (k, v) -> p[k] = v } }

    private fun readAll(): JSONObject = try {
        JSONObject(Prefs.voicePresets)
    } catch (e: Exception) {
        JSONObject()
    }

    fun customNames(): List<String> {
        val o = readAll()
        val out = ArrayList<String>()
        val keys = o.keys()
        while (keys.hasNext()) out.add(keys.next())
        return out.sorted()
    }

    fun loadCustom(name: String): VoiceParams? = VoiceParams.fromJson(readAll().optJSONObject(name)?.toString())

    fun saveCustom(name: String, p: VoiceParams) {
        val o = readAll()
        o.put(name, JSONObject(p.toJson()))
        Prefs.voicePresets = o.toString()
    }

    fun deleteCustom(name: String) {
        val o = readAll()
        o.remove(name)
        Prefs.voicePresets = o.toString()
    }
}

/**
 * Цепочка эффектов над готовым PCM. Порядок:
 * вибрато → фильтры/эквалайзер → компрессор → робот → металл → хорус → перегруз → биткраш →
 * эхо → реверберация → шум → нормализация → усиление → лимитер → fade.
 * Исходный массив НЕ изменяется (он может лежать в кэше синтеза).
 */
object VoiceFx {

    fun process(input: FloatArray, sr: Int, p: VoiceParams): FloatArray {
        if (input.isEmpty()) return input

        var tailMs = p["tail"]
        if (p["echoMix"] > 0.005f) tailMs = max(tailMs, p["echoMs"] * (1f + 5f * p["echoFb"]))
        if (p["revMix"] > 0.005f) tailMs = max(tailMs, 500f + 2000f * p["revSize"])
        val tail = (sr * tailMs / 1000f).toInt().coerceIn(0, sr * 8)
        val x = input.copyOf(input.size + tail)

        vibrato(x, sr, p)
        eq(x, sr, p)
        compress(x, sr, p)
        robot(x, sr, p)
        metal(x, sr, p)
        chorus(x, sr, p)
        drive(x, p)
        crush(x, p)
        echo(x, sr, p)
        reverb(x, sr, p)
        hiss(x, p)

        // Нормализация пика → усиление → лимитер.
        val target = p["peak"]
        if (target > 0.01f) {
            var pk = 0f
            for (v in x) { val a = abs(v); if (a > pk) pk = a }
            if (pk > 0.01f) {
                val g = (target / pk).coerceAtMost(8f)
                for (i in x.indices) x[i] *= g
            }
        }
        val gain = 10.0.pow(p["gain"] / 20.0).toFloat()
        if (abs(gain - 1f) > 0.001f) for (i in x.indices) x[i] *= gain
        val soft = p["limiter"] > 0.5f
        for (i in x.indices) x[i] = if (soft) softClip(x[i]) else x[i].coerceIn(-1f, 1f)

        // Fade in/out.
        val fi = (sr * p["fadeIn"] / 1000f).toInt().coerceAtMost(x.size)
        for (i in 0 until fi) x[i] *= i / fi.toFloat()
        val fo = (sr * p["fadeOut"] / 1000f).toInt().coerceAtMost(x.size)
        for (i in 0 until fo) x[x.size - 1 - i] *= i / fo.toFloat()
        return x
    }

    private fun softClip(v: Float): Float {
        val a = abs(v)
        if (a < 0.8f) return v
        val o = (0.8f + 0.2f * tanh((a - 0.8f) / 0.2f)).coerceAtMost(1f)
        return if (v < 0f) -o else o
    }

    /** Чтение массива в дробной позиции (линейная интерполяция), края — по ближайшему отсчёту. */
    private fun readFrac(a: FloatArray, pos: Double): Float {
        if (pos <= 0.0) return a[0]
        val i = pos.toInt()
        if (i >= a.size - 1) return a[a.size - 1]
        val f = (pos - i).toFloat()
        return a[i] + (a[i + 1] - a[i]) * f
    }

    // ---------- Вибрато ----------
    private fun vibrato(x: FloatArray, sr: Int, p: VoiceParams) {
        val cents = p["vibDepth"]
        if (cents < 0.5f) return
        val rate = p["vibRate"].toDouble()
        val dev = 2.0.pow(cents / 1200.0) - 1.0
        val amp = dev * sr / (2.0 * PI * rate)       // амплитуда модуляции задержки, отсчётов
        val src = x.copyOf()
        for (n in x.indices) {
            val d = amp * (1.0 + sin(2.0 * PI * rate * n / sr))
            x[n] = readFrac(src, n - d)
        }
    }

    // ---------- Эквалайзер и фильтры ----------
    private fun eq(x: FloatArray, sr: Int, p: VoiceParams) {
        val nyq = sr * 0.45
        val chain = ArrayList<Biquad>()
        if (p["hp"] >= 20f) chain.add(Biquad.highpass(sr, p["hp"].toDouble().coerceAtMost(nyq), 0.707))
        if (p["lp"] >= 800f) chain.add(Biquad.lowpass(sr, p["lp"].toDouble().coerceAtMost(nyq), 0.707))
        if (abs(p["lowDb"]) > 0.05f) chain.add(Biquad.lowShelf(sr, p["lowHz"].toDouble().coerceAtMost(nyq), p["lowDb"].toDouble()))
        if (abs(p["midDb"]) > 0.05f) chain.add(Biquad.peaking(sr, p["midHz"].toDouble().coerceAtMost(nyq), p["midDb"].toDouble(), p["midQ"].toDouble()))
        if (abs(p["highDb"]) > 0.05f) chain.add(Biquad.highShelf(sr, p["highHz"].toDouble().coerceAtMost(nyq), p["highDb"].toDouble()))
        if (chain.isEmpty()) return
        for (n in x.indices) {
            var v = x[n]
            for (f in chain) v = f.run(v)
            x[n] = v
        }
    }

    // ---------- Компрессор ----------
    private fun compress(x: FloatArray, sr: Int, p: VoiceParams) {
        val thr = p["compThr"]
        if (thr > -0.5f) return
        val ratio = p["compRatio"].toDouble()
        val makeup = p["compMakeup"].toDouble()
        val atk = exp(-1.0 / (0.005 * sr))
        val rel = exp(-1.0 / (0.08 * sr))
        var env = 0.0
        for (n in x.indices) {
            val a = abs(x[n]).toDouble()
            env = if (a > env) atk * env + (1 - atk) * a else rel * env + (1 - rel) * a
            val envDb = 20.0 * log10(max(env, 1e-6))
            val over = envDb - thr
            val gr = if (over > 0) over * (1.0 - 1.0 / ratio) else 0.0
            x[n] = (x[n] * 10.0.pow((makeup - gr) / 20.0)).toFloat()
        }
    }

    // ---------- Робот (кольцевой модулятор) ----------
    private fun robot(x: FloatArray, sr: Int, p: VoiceParams) {
        val mix = p["robotMix"]
        if (mix < 0.005f) return
        val w = 2.0 * PI * p["robotHz"] / sr
        for (n in x.indices) {
            val m = sin(w * n).toFloat()
            x[n] = x[n] * (1f - mix) + x[n] * m * mix
        }
    }

    // ---------- Металл (рекурсивный гребенчатый фильтр) ----------
    private fun metal(x: FloatArray, sr: Int, p: VoiceParams) {
        val mix = p["metalMix"]
        if (mix < 0.005f) return
        val d = max(1, (p["metalMs"] * sr / 1000f).toInt())
        val fb = p["metalFb"]
        val scale = 1f - fb * 0.5f
        val y = FloatArray(x.size)
        for (n in x.indices) {
            val prev = if (n >= d) y[n - d] else 0f
            y[n] = x[n] + fb * prev
        }
        for (n in x.indices) x[n] = x[n] * (1f - mix) + y[n] * scale * mix
    }

    // ---------- Хорус (две плавающие копии) ----------
    private fun chorus(x: FloatArray, sr: Int, p: VoiceParams) {
        val mix = p["chorusMix"]
        if (mix < 0.005f) return
        val depth = p["chorusMs"].toDouble()
        val base = max(depth + 1.0, 8.0)
        val rate = p["chorusRate"].toDouble()
        val src = x.copyOf()
        for (n in x.indices) {
            val t = n.toDouble() / sr
            val d1 = (base + depth * sin(2.0 * PI * rate * t)) * sr / 1000.0
            val d2 = (base * 1.3 + depth * sin(2.0 * PI * rate * 1.13 * t + 2.1)) * sr / 1000.0
            x[n] = src[n] + mix * 0.7f * (readFrac(src, n - d1) + readFrac(src, n - d2))
        }
    }

    // ---------- Перегруз ----------
    private fun drive(x: FloatArray, p: VoiceParams) {
        val mix = p["distMix"]
        if (mix < 0.005f) return
        val drv = p["drive"].toDouble()
        val norm = tanh(drv)
        for (n in x.indices) {
            val d = (tanh(x[n] * drv) / norm).toFloat()
            x[n] = x[n] * (1f - mix) + d * mix
        }
    }

    // ---------- Биткраш и понижение частоты ----------
    private fun crush(x: FloatArray, p: VoiceParams) {
        val bits = p["bits"].roundToInt()
        val down = max(1, p["down"].roundToInt())
        if (bits >= 16 && down <= 1) return
        val levels = 2f.pow(bits - 1)
        var held = 0f
        for (n in x.indices) {
            if (n % down == 0) {
                held = if (bits < 16) (x[n] * levels).roundToInt() / levels else x[n]
            }
            x[n] = held
        }
    }

    // ---------- Эхо ----------
    private fun echo(x: FloatArray, sr: Int, p: VoiceParams) {
        val mix = p["echoMix"]
        if (mix < 0.005f) return
        val d = max(1, (p["echoMs"] * sr / 1000f).toInt())
        val fb = p["echoFb"]
        val buf = FloatArray(d)
        var idx = 0
        for (n in x.indices) {
            val delayed = buf[idx]
            buf[idx] = x[n] + delayed * fb
            idx = (idx + 1) % d
            x[n] = x[n] + delayed * mix
        }
    }

    // ---------- Реверберация (Schroeder/Freeverb) ----------
    private class Comb(len: Int, private val fb: Float, private val damp: Float) {
        private val buf = FloatArray(len)
        private var idx = 0
        private var store = 0f
        fun run(x: Float): Float {
            val out = buf[idx]
            store = out * (1f - damp) + store * damp
            buf[idx] = x + store * fb
            idx = (idx + 1) % buf.size
            return out
        }
    }

    private class AllPass(len: Int) {
        private val buf = FloatArray(len)
        private var idx = 0
        fun run(x: Float): Float {
            val b = buf[idx]
            val out = -x + b
            buf[idx] = x + b * 0.5f
            idx = (idx + 1) % buf.size
            return out
        }
    }

    private fun reverb(x: FloatArray, sr: Int, p: VoiceParams) {
        val mix = p["revMix"]
        if (mix < 0.005f) return
        val size = p["revSize"]
        val scale = sr / 44100.0 * (0.7 + 0.6 * size)
        val fb = 0.7f + 0.28f * size
        val damp = p["revDamp"] * 0.4f
        val combs = intArrayOf(1116, 1188, 1277, 1356, 1422, 1491).map {
            Comb(max(8, (it * scale).toInt()), fb, damp)
        }
        val aps = intArrayOf(556, 441, 341, 225).map { AllPass(max(8, (it * sr / 44100.0).toInt())) }
        for (n in x.indices) {
            val inp = x[n] * 0.15f
            var s = 0f
            for (c in combs) s += c.run(inp)
            for (a in aps) s = a.run(s)
            x[n] = x[n] * (1f - mix * 0.5f) + s * mix
        }
    }

    // ---------- Шум ----------
    private fun hiss(x: FloatArray, p: VoiceParams) {
        val db = p["hiss"]
        if (db <= -69f) return
        val a = 10.0.pow(db / 20.0).toFloat()
        val rnd = Random(1234)
        for (n in x.indices) x[n] += (rnd.nextFloat() * 2f - 1f) * a
    }

    // ---------- Biquad (формулы RBJ Audio EQ Cookbook) ----------
    private class Biquad(b0: Double, b1: Double, b2: Double, a0: Double, a1: Double, a2: Double) {
        private val c0 = b0 / a0
        private val c1 = b1 / a0
        private val c2 = b2 / a0
        private val d1 = a1 / a0
        private val d2 = a2 / a0
        private var z1 = 0.0
        private var z2 = 0.0

        fun run(x: Float): Float {
            val xd = x.toDouble()
            val y = c0 * xd + z1
            z1 = c1 * xd - d1 * y + z2
            z2 = c2 * xd - d2 * y
            return y.toFloat()
        }

        companion object {
            fun highpass(sr: Int, f: Double, q: Double): Biquad {
                val w = 2.0 * PI * f / sr; val c = kotlin.math.cos(w); val al = sin(w) / (2 * q)
                return Biquad((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al)
            }

            fun lowpass(sr: Int, f: Double, q: Double): Biquad {
                val w = 2.0 * PI * f / sr; val c = kotlin.math.cos(w); val al = sin(w) / (2 * q)
                return Biquad((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al)
            }

            fun peaking(sr: Int, f: Double, db: Double, q: Double): Biquad {
                val a = 10.0.pow(db / 40.0)
                val w = 2.0 * PI * f / sr; val c = kotlin.math.cos(w); val al = sin(w) / (2 * q)
                return Biquad(1 + al * a, -2 * c, 1 - al * a, 1 + al / a, -2 * c, 1 - al / a)
            }

            fun lowShelf(sr: Int, f: Double, db: Double): Biquad {
                val a = 10.0.pow(db / 40.0)
                val w = 2.0 * PI * f / sr; val c = kotlin.math.cos(w); val s = sin(w)
                val tsa = 2 * sqrt(a) * (s / 2 * sqrt(2.0))
                return Biquad(
                    a * ((a + 1) - (a - 1) * c + tsa),
                    2 * a * ((a - 1) - (a + 1) * c),
                    a * ((a + 1) - (a - 1) * c - tsa),
                    (a + 1) + (a - 1) * c + tsa,
                    -2 * ((a - 1) + (a + 1) * c),
                    (a + 1) + (a - 1) * c - tsa
                )
            }

            fun highShelf(sr: Int, f: Double, db: Double): Biquad {
                val a = 10.0.pow(db / 40.0)
                val w = 2.0 * PI * f / sr; val c = kotlin.math.cos(w); val s = sin(w)
                val tsa = 2 * sqrt(a) * (s / 2 * sqrt(2.0))
                return Biquad(
                    a * ((a + 1) + (a - 1) * c + tsa),
                    -2 * a * ((a - 1) + (a + 1) * c),
                    a * ((a + 1) + (a - 1) * c - tsa),
                    (a + 1) - (a - 1) * c + tsa,
                    2 * ((a - 1) - (a + 1) * c),
                    (a + 1) - (a - 1) * c - tsa
                )
            }
        }
    }

    // ---------- Экспорт ----------
    /** Сохраняет PCM как WAV 16 бит моно. */
    fun writeWav(file: File, pcm: FloatArray, sr: Int) {
        val dataLen = pcm.size * 2
        val data = ByteBuffer.allocate(dataLen).order(ByteOrder.LITTLE_ENDIAN)
        for (v in pcm) data.putShort((v.coerceIn(-1f, 1f) * 32767f).toInt().toShort())
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + dataLen); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1)
        h.putInt(sr); h.putInt(sr * 2); h.putShort(2); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(dataLen)
        file.outputStream().use { it.write(h.array()); it.write(data.array()) }
    }
}
