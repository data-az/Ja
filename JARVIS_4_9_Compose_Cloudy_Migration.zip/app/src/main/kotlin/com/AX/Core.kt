package com.AX

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Раздел журнала. На вкладке «Все» показываются записи всех разделов, но в кратком виде. */
enum class LogCat(val title: String) {
    SOUND("ЗВУК"),
    CMD("КОМАНДА"),
    API("API")
}

/**
 * [text] — полная запись (вкладки «Звук», «Команды», «API»);
 * [brief] — короткая версия для вкладки «Все» (если не задана, берётся начало [text]).
 */
data class LogLine(
    val time: String,
    val level: String,
    val text: String,
    val cat: LogCat = LogCat.CMD,
    val brief: String? = null
)

/**
 * [needPerms] — разрешения, без которых команда не выполнена: приложение запросит их и повторит [retry].
 */
data class Reply(
    val ok: Boolean,
    val text: String,
    val exit: Boolean = false,
    val needPerms: Array<String>? = null,
    val retry: String? = null
)

object AppLog {
    private const val MAX_LINES = 800
    private const val BRIEF_LEN = 90

    val lines = ArrayList<LogLine>()
    var listener: (() -> Unit)? = null
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val main = Handler(Looper.getMainLooper())

    /** Старый вызов: раздел определяется по уровню и началу текста. */
    fun add(level: String, text: String) = put(autoCat(level, text), level, text, null)

    /** Звук: озвучка, модель, AudioTrack, готовые wav-звуки. */
    fun sound(level: String, text: String, brief: String? = null) = put(LogCat.SOUND, level, text, brief)

    /** Команды: распознавание речи, выполнение, поиск приложений/контактов/папок. */
    fun cmd(level: String, text: String, brief: String? = null) = put(LogCat.CMD, level, text, brief)

    /** Сеть и ИИ-провайдеры. */
    fun api(level: String, text: String, brief: String? = null) = put(LogCat.API, level, text, brief)

    private fun autoCat(level: String, text: String): LogCat = when {
        level == "API" || text.startsWith("API") || text.startsWith("DNS") -> LogCat.API
        text.startsWith("TTS") || text.startsWith("Silero") || text.startsWith("Звук") -> LogCat.SOUND
        else -> LogCat.CMD
    }

    private fun put(cat: LogCat, level: String, text: String, brief: String?) {
        if (!Prefs.logEnabled) return
        val line = LogLine(fmt.format(Date()), level, text, cat, brief)
        main.post {
            lines.add(line)
            if (lines.size > MAX_LINES) lines.removeAt(0)
            listener?.invoke()
        }
    }

    /** Краткий вид строки для вкладки «Все». */
    fun briefOf(line: LogLine): String {
        line.brief?.let { return it }
        val first = line.text.lineSequence().firstOrNull().orEmpty()
        return if (first.length > BRIEF_LEN) first.take(BRIEF_LEN - 1) + "…" else first
    }

    fun clear() {
        lines.clear()
        listener?.invoke()
    }
}

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    }

    var soundOn: Boolean
        get() = sp.getBoolean("sound", true)
        set(v) { sp.edit().putBoolean("sound", v).apply() }

    /** Громкость звуков ассистента, 0..1. */
    var soundVolume: Float
        get() = sp.getFloat("volume", 0.6f)
        set(v) { sp.edit().putFloat("volume", v.coerceIn(0f, 1f)).apply() }

    var logEnabled: Boolean
        get() = sp.getBoolean("log", true)
        set(v) { sp.edit().putBoolean("log", v).apply() }

    var logTime: Boolean
        get() = sp.getBoolean("logtime", true)
        set(v) { sp.edit().putBoolean("logtime", v).apply() }

    var offline: Boolean
        get() = sp.getBoolean("offline", true)
        set(v) { sp.edit().putBoolean("offline", v).apply() }

    // ---- Верховный суд (OpenRouter) ----
    var supremeOn: Boolean
        get() = sp.getBoolean("court_on", false)
        set(v) { sp.edit().putBoolean("court_on", v).apply() }

    /** «Режим полного ключа»: приложения ищутся ТОЛЬКО через API-ключ, локальный поиск отключён. */
    var keyOnly: Boolean
        get() = sp.getBoolean("key_only", false)
        set(v) { sp.edit().putBoolean("key_only", v).apply() }

    var supremeKey: String
        get() = sp.getString("court_key", "") ?: ""
        set(v) { sp.edit().putString("court_key", v.trim()).apply() }

    var supremeModel: String
        get() = sp.getString("court_model", SupremeCourt.DEFAULT_MODEL) ?: SupremeCourt.DEFAULT_MODEL
        set(v) { sp.edit().putString("court_model", v.trim()).apply() }

    // ---- Cloudflare Workers AI: нужны Account ID и API-токен ----
    var cfAccount: String
        get() = sp.getString("cf_account", "") ?: ""
        set(v) { sp.edit().putString("cf_account", v.trim()).apply() }

    var cfToken: String
        get() = sp.getString("cf_token", "") ?: ""
        set(v) { sp.edit().putString("cf_token", v.trim()).apply() }

    var cfModel: String
        get() = sp.getString("cf_model", SupremeCourt.DEFAULT_CF_MODEL) ?: SupremeCourt.DEFAULT_CF_MODEL
        set(v) { sp.edit().putString("cf_model", v.trim()).apply() }

    // ---- Hugging Face ----
    var hfKey: String
        get() = sp.getString("hf_key", "") ?: ""
        set(v) { sp.edit().putString("hf_key", v.trim()).apply() }

    var hfModel: String
        get() = sp.getString("hf_model", SupremeCourt.DEFAULT_HF_MODEL) ?: SupremeCourt.DEFAULT_HF_MODEL
        set(v) { sp.edit().putString("hf_model", v.trim()).apply() }

    /** Кого спрашивать первым: auto | openrouter | cloudflare | huggingface. Остальные — запасные. */
    var provider: String
        get() = sp.getString("provider", "auto") ?: "auto"
        set(v) { sp.edit().putString("provider", v).apply() }

    // ---- Голос (Piper TTS + DSP) ----
    var ttsOn: Boolean
        get() = sp.getBoolean("tts_on", false)
        set(v) { sp.edit().putBoolean("tts_on", v).apply() }

    /** Движок озвучки: "piper" (встроенный) или "ruvoice" (системный RuVoice TTS). */
    var ttsEngine: String
        get() = sp.getString("tts_engine", "piper") ?: "piper"
        set(v) { sp.edit().putString("tts_engine", v).apply() }

    /** Имя выбранного голоса RuVoice (aidar, baya, kseniya, xenia, eugene…). */
    var ruVoiceName: String
        get() = sp.getString("ruvoice_name", "") ?: ""
        set(v) { sp.edit().putString("ruvoice_name", v).apply() }

    private var voiceCache: VoiceParams? = null

    /**
     * Все настройки голоса (см. [VoiceSpec]) одним объектом. Хранится JSON-ом в «voice_fx».
     * Старая настройка «pitch» подхватывается один раз при первом запуске новой версии.
     */
    val voice: VoiceParams
        @Synchronized get() {
            voiceCache?.let { return it }
            val p = VoiceParams.fromJson(sp.getString("voice_fx", null)) ?: VoiceParams()
            if (!sp.contains("voice_fx") && sp.contains("pitch")) p["pitch"] = sp.getFloat("pitch", 1f)
            voiceCache = p
            return p
        }

    /** Записать текущие значения [voice] на диск (вызывать после изменений). */
    @Synchronized
    fun saveVoice() {
        sp.edit().putString("voice_fx", voice.toJson()).apply()
    }

    /** Заменить все настройки голоса целиком (пресет, вставка из буфера) и сохранить. */
    @Synchronized
    fun replaceVoice(p: VoiceParams) {
        voiceCache = p
        saveVoice()
    }

    /** Пользовательские пресеты голоса: JSON «имя → параметры». */
    var voicePresets: String
        get() = sp.getString("voice_presets", "{}") ?: "{}"
        set(v) { sp.edit().putString("voice_presets", v).apply() }

    /** Произносить тестовую фразу после каждой правки ползунка. */
    var voiceAutoPreview: Boolean
        get() = sp.getBoolean("voice_autopreview", true)
        set(v) { sp.edit().putBoolean("voice_autopreview", v).apply() }

    var voiceTestPhrase: String
        get() = sp.getString("voice_test_phrase", "Системы в норме. Джарвис к вашим услугам.")
            ?: "Системы в норме. Джарвис к вашим услугам."
        set(v) { sp.edit().putString("voice_test_phrase", v).apply() }

    /** Коэффициент тональности (оставлен для голосовых команд «голос выше/ниже»). */
    var pitch: Float
        get() = voice["pitch"]
        set(v) { voice["pitch"] = v; saveVoice() }

    /** Сброс тональности в исходное состояние (1.0f). */
    fun resetPitch() { pitch = PitchShifter.DEFAULT }
}
