package com.AX

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice as SystemVoice

/**
 * Озвучка через системный движок RuVoice TTS (пакет ru.kost.ruvoice).
 * Голоса ставятся в самом RuVoice; здесь выбирается движок и голос.
 */
object RuVoiceTts {
    const val PACKAGE = "ru.kost.ruvoice"

    private var tts: TextToSpeech? = null

    @Volatile
    var ready = false
        private set

    var lastError: String? = null
        private set

    /** Подключает движок (асинхронно). [onReady] получает true, если RuVoice ответил. */
    @Synchronized
    fun init(ctx: Context, onReady: (Boolean) -> Unit = {}) {
        if (tts != null) {
            onReady(ready)
            return
        }
        tts = TextToSpeech(
            ctx.applicationContext,
            TextToSpeech.OnInitListener { status ->
                ready = status == TextToSpeech.SUCCESS
                lastError = if (ready) null else "RuVoice не отвечает (код $status)"
                if (ready) applySavedVoice()
                onReady(ready)
            },
            PACKAGE
        )
    }

    /** Русские голоса, установленные в RuVoice. */
    fun voices(): List<SystemVoice> {
        val engine = tts ?: return emptyList()
        return engine.voices.orEmpty()
            .filter { it.locale.language == "ru" }
            .sortedBy { it.name }
    }

    /** Выбирает голос по имени и запоминает его. */
    fun selectVoice(name: String): Boolean {
        val engine = tts ?: return false
        val voice = voices().firstOrNull { it.name == name } ?: return false
        Prefs.ruVoiceName = name
        return engine.setVoice(voice) == TextToSpeech.SUCCESS
    }

    private fun applySavedVoice() {
        val name = Prefs.ruVoiceName
        if (name.isNotEmpty()) selectVoice(name)
    }

    fun speak(text: String) {
        val engine = tts
        if (engine == null || !ready) {
            AppLog.sound("ERR", "RuVoice не готов: ${lastError ?: "движок не подключён"}", "RuVoice не готов")
            return
        }
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis-${System.nanoTime()}")
    }

    fun stop() {
        tts?.stop()
    }
}
