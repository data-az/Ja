package com.AX

import android.os.Environment
import java.io.File
import java.util.Locale

/**
 * Поиск папок по ВСЕМУ хранилищу (а не только в корне).
 *
 * «открой папку А»                     — ищет папку А на любой глубине;
 * «открой папку А в папке Б»           — ищет А внутри ЛЮБОЙ папки с именем Б (во всех папках Б);
 * «открой папку А в папке Б в папке В» — цепочка: А внутри Б, Б внутри В (на любой глубине между ними).
 */
object FolderSearch {

    class Hit(val dir: File, val score: Float, val depth: Int)

    class Result(val hits: List<Hit>, val scanned: Int, val timedOut: Boolean)

    private class Entry(val path: String, val name: String, val depth: Int)

    private class Index(val entries: List<Entry>, val roots: List<File>, val builtAt: Long, val timedOut: Boolean)

    private const val MAX_DEPTH = 14
    private const val MAX_DIRS = 250_000
    private const val SCAN_BUDGET_MS = 9_000L
    private const val CACHE_MS = 60_000L
    private const val THRESHOLD = 0.82f

    @Volatile
    private var cache: Index? = null

    /** Системные каталоги, куда нет смысла (и доступа) заходить. */
    private val SKIP_NAMES = setOf(".thumbnails", ".trash", ".cache", "lost.dir", ".android_secure")

    /** Устные названия стандартных папок Android → их реальные имена. Ключи — в нижнем регистре, без окончаний. */
    private val ALIASES: Map<String, List<String>> = mapOf(
        "загрузк" to listOf("download", "downloads"),
        "скачанн" to listOf("download", "downloads"),
        "документ" to listOf("documents", "docs"),
        "картинк" to listOf("pictures"),
        "изображени" to listOf("pictures"),
        "фото" to listOf("pictures", "dcim", "photos"),
        "фотографи" to listOf("pictures", "dcim", "photos"),
        "камер" to listOf("camera", "dcim"),
        "музык" to listOf("music"),
        "видео" to listOf("movies", "video", "videos"),
        "фильм" to listOf("movies"),
        "скриншот" to listOf("screenshots"),
        "рингтон" to listOf("ringtones"),
        "мелоди" to listOf("ringtones", "music"),
        "будильник" to listOf("alarms"),
        "подкаст" to listOf("podcasts"),
        "уведомлени" to listOf("notifications")
    )

    fun invalidate() { cache = null }

    /** Корни: внутренняя память и SD-карты/флешки (/storage/XXXX-XXXX). */
    fun roots(): List<File> {
        val list = ArrayList<File>()
        list.add(Environment.getExternalStorageDirectory())
        File("/storage").listFiles()?.forEach {
            if (it.isDirectory && it.name != "emulated" && it.name != "self" && it.canRead()) list.add(it)
        }
        return list
    }

    /**
     * [chain] — имена от внутренней папки к внешней: «А в Б в В» → [А, Б, В].
     * Блокирующий: вызывайте из рабочего потока.
     */
    fun find(chain: List<String>): Result {
        val idx = index()
        if (chain.isEmpty()) return Result(emptyList(), idx.entries.size, idx.timedOut)

        val engine = Commands.engine
        // Для каждого имени цепочки считаем совпадения по всем уникальным именам папок один раз.
        val scoreCache = HashMap<String, Float>()
        fun matches(name: String): List<Pair<Entry, Float>> {
            val q = Query(name, engine)
            scoreCache.clear()
            val out = ArrayList<Pair<Entry, Float>>()
            for (e in idx.entries) {
                val sc = scoreCache.getOrPut(e.name) { q.score(e.name) }
                if (sc >= THRESHOLD) out.add(e to sc)
            }
            return out
        }

        // Самая внешняя папка цепочки — отправная точка, дальше спускаемся к искомой.
        val outer = chain.reversed()
        var current = matches(outer[0])
        for (i in 1 until outer.size) {
            val ancestors = current.map { it.first.path }.toHashSet()
            val next = matches(outer[i])
            // Оставляем те, у кого хотя бы один предок (на любом уровне вверх) — найденная внешняя папка.
            current = next.filter { (e, _) -> hasAncestorIn(e.path, ancestors) }
        }

        val hits = current
            .map { (e, sc) -> Hit(File(e.path), sc, e.depth) }
            .sortedWith(
                compareByDescending<Hit> { it.score }
                    .thenBy { it.depth }
                    .thenBy { it.dir.absolutePath.length }
                    .thenBy { it.dir.absolutePath }
            )
        return Result(hits, idx.entries.size, idx.timedOut)
    }

    private fun hasAncestorIn(path: String, ancestors: Set<String>): Boolean {
        var p = path.substringBeforeLast('/', "")
        while (p.isNotEmpty()) {
            if (p in ancestors) return true
            p = p.substringBeforeLast('/', "")
        }
        return false
    }

    // ================= Индекс всех папок =================

    @Synchronized
    private fun index(): Index {
        val c = cache
        if (c != null && System.currentTimeMillis() - c.builtAt < CACHE_MS) return c
        val built = scan(roots())
        cache = built
        return built
    }

    private fun scan(roots: List<File>): Index {
        val t0 = System.currentTimeMillis()
        val out = ArrayList<Entry>(4096)
        var timedOut = false
        val stack = ArrayDeque<Pair<File, Int>>()
        for (r in roots) stack.addLast(r to 0)
        while (stack.isNotEmpty()) {
            if (out.size >= MAX_DIRS || System.currentTimeMillis() - t0 > SCAN_BUDGET_MS) { timedOut = true; break }
            val (dir, depth) = stack.removeLast()
            val kids = dir.listFiles() ?: continue
            for (k in kids) {
                val n = k.name
                if (n.startsWith(".") || n.lowercase(Locale.ROOT) in SKIP_NAMES) continue
                if (!k.isDirectory) continue
                // Android/data и Android/obb закрыты системой, а внутри только пакеты приложений.
                if (depth == 0 && n == "Android") continue
                out.add(Entry(k.absolutePath, n, depth + 1))
                if (depth + 1 < MAX_DEPTH) stack.addLast(k to depth + 1)
            }
        }
        AppLog.add("SEARCH", "Папки: проиндексировано ${out.size} за ${System.currentTimeMillis() - t0} мс" + if (timedOut) " (прервано по лимиту)" else "")
        return Index(out, roots, System.currentTimeMillis(), timedOut)
    }

    // ================= Сравнение имён =================

    /** Запрос: варианты написания (translit, стемминг, синонимы стандартных папок). */
    private class Query(val spoken: String, val engine: SmartAppSearchEngine) {
        val norm = engine.normalize(spoken)
        val variants: Set<String> = LinkedHashSet<String>().also { set ->
            set.addAll(engine.variantsOf(spoken))
            val stem = engine.stemTokens(norm)
            for ((k, names) in ALIASES) {
                if (stem.startsWith(k) || stem.replace(" ", "").startsWith(k)) {
                    for (n in names) set.addAll(engine.variantsOf(n))
                }
            }
        }

        fun score(dirName: String): Float {
            val nv = engine.variantsOf(dirName)
            if (nv.isEmpty()) return 0f
            // 1. Полное совпадение любой пары вариантов.
            for (v in nv) if (v in variants) return 1f
            // 2. Совпало слово названия: «документы» в «Мои документы».
            var best = 0f
            for (v in nv) {
                if (!v.contains(' ')) continue
                for (t in v.split(' ')) if (t.length >= 3 && t in variants) best = maxOf(best, 0.9f)
            }
            if (best > 0f) return best
            // 3. Нечёткое сравнение — только для правдоподобных кандидатов (длина близка, слово не короче 4).
            val ref = norm.replace(" ", "")
            val target = engine.normalize(dirName).replace(" ", "")
            if (ref.length < 4 || target.length < 4) return 0f
            if (kotlin.math.abs(ref.length - target.length) > 3) return 0f
            val sim = engine.similarity(spoken, dirName)
            return if (sim >= THRESHOLD) sim * 0.96f else 0f
        }
    }

    // ================= Разбор фразы =================

    private val CHAIN_SPLIT = Regex(
        "\\s+(?:в|во|внутри|из)\\s+(?:всех\\s+)?(?:папке|папку|папки|папках|папка|директории|каталоге|каталог)\\s+",
        RegexOption.IGNORE_CASE
    )

    /** «А в папке Б в папке В» → [А, Б, В]. Пустые части отбрасываются. */
    fun parseChain(text: String): List<String> =
        text.trim().split(CHAIN_SPLIT).map { it.trim() }.filter { it.isNotEmpty() }
}
