package com.AX

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Экран «Голос»: строится целиком из [VoiceSpec.all], в XML ничего дублировать не нужно.
 *
 *  • Пресеты (встроенные + свои), «Случайный» (удержание — сильнее), «Сбросить всё», «Оригинал» (A/B без эффектов).
 *  • Копировать / Вставить настройки (JSON через буфер обмена), сохранить последнюю реплику в WAV.
 *  • Группы сворачиваются; удержание заголовка группы — сброс группы.
 *  • Тап по значению параметра — точный ввод числа (и сброс одного параметра).
 *  • Автопрослушивание: после каждой правки произносится тестовая фраза.
 */
object VoiceUi {

    /** Строит экран в [host]. Возвращает функцию, перечитывающую значения из Prefs (например в onResume). */
    fun build(host: LinearLayout, onState: () -> Unit): () -> Unit {
        val ctx = host.context
        host.removeAllViews()
        val refreshers = ArrayList<() -> Unit>()
        fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
        fun refreshAll() = refreshers.forEach { it() }

        fun speakTest(raw: Boolean) {
            if (!Voice.hasModelFiles()) {
                toast(ctx, "Модель голоса не найдена")
                return
            }
            val phrase = Prefs.voiceTestPhrase.ifBlank { "Системы в норме. Джарвис к вашим услугам." }
            Voice.speak(phrase, if (raw) VoiceParams() else Prefs.voice.copy(), force = true)
            onState()
        }

        fun changed() {
            Prefs.saveVoice()
            if (Prefs.voiceAutoPreview) speakTest(false)
        }

        fun applyAll(p: VoiceParams) {
            Prefs.replaceVoice(p)
            refreshAll()
            if (Prefs.voiceAutoPreview) speakTest(false)
        }

        // ---------- Пресеты ----------
        val presetRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        fun fillPresets() {
            presetRow.removeAllViews()
            for ((name, map) in VoicePresets.builtin) {
                presetRow.addView(chip(ctx, name, { applyAll(VoicePresets.build(map)) }))
            }
            for (name in VoicePresets.customNames()) {
                presetRow.addView(chip(ctx, "★ $name", {
                    VoicePresets.loadCustom(name)?.let { applyAll(it) }
                }, {
                    AlertDialog.Builder(ctx)
                        .setTitle("Удалить пресет «$name»?")
                        .setPositiveButton("Удалить") { _, _ -> VoicePresets.deleteCustom(name); fillPresets() }
                        .setNegativeButton("Отмена", null)
                        .show()
                    true
                }))
            }
        }
        fillPresets()

        host.addView(label(ctx, "ПРЕСЕТЫ  (★ свои: удержание — удалить)"))
        host.addView(HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(dp(12), 0, dp(12), dp(4))
            addView(presetRow)
        })

        // ---------- Действия ----------
        val actions = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(chip(ctx, "▶ Проверить", { speakTest(false) }))
        actions.addView(chip(ctx, "Оригинал (A/B)", { speakTest(true) }))
        actions.addView(chip(ctx, "Случайный", {
            Prefs.voice.randomize(0.35f); applyAll(Prefs.voice)
        }, {
            Prefs.voice.randomize(0.8f); applyAll(Prefs.voice); true
        }))
        actions.addView(chip(ctx, "Сбросить всё", {
            AlertDialog.Builder(ctx)
                .setTitle("Сбросить все настройки голоса?")
                .setPositiveButton("Сбросить") { _, _ -> applyAll(VoiceParams()) }
                .setNegativeButton("Отмена", null)
                .show()
        }))
        actions.addView(chip(ctx, "Сохранить пресет", {
            val et = EditText(ctx).apply {
                hint = "Название"
                inputType = InputType.TYPE_CLASS_TEXT
                setPadding(dp(20), dp(12), dp(20), dp(12))
            }
            AlertDialog.Builder(ctx)
                .setTitle("Сохранить как пресет")
                .setView(et)
                .setPositiveButton("Сохранить") { _, _ ->
                    val name = et.text.toString().trim().take(24)
                    if (name.isNotEmpty()) {
                        VoicePresets.saveCustom(name, Prefs.voice.copy())
                        fillPresets()
                        toast(ctx, "Пресет «$name» сохранён")
                    }
                }
                .setNegativeButton("Отмена", null)
                .show()
        }))
        actions.addView(chip(ctx, "Копировать", {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("jarvis voice", Prefs.voice.toJson()))
            toast(ctx, "Настройки голоса скопированы")
        }))
        actions.addView(chip(ctx, "Вставить", {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString()
            val p = VoiceParams.fromJson(text)
            if (p == null) toast(ctx, "В буфере нет настроек голоса") else { applyAll(p); toast(ctx, "Настройки применены") }
        }))
        actions.addView(chip(ctx, "Сохранить WAV", { toast(ctx, Voice.saveLastWav()) }))
        host.addView(HorizontalScrollView(ctx).apply {
            isHorizontalScrollBarEnabled = false
            setPadding(dp(12), dp(4), dp(12), dp(4))
            addView(actions)
        })
        host.addView(hint(ctx, "«Случайный»: тап — слегка, удержание — сильно. Заголовок группы: тап — свернуть, удержание — сбросить группу. " +
            "Тап по значению — ввести точное число."))

        // ---------- Тестовая фраза и автопрослушивание ----------
        host.addView(EditText(ctx, null, 0, R.style.Jarvis_Input).apply {
            hint = "Тестовая фраза"
            setText(Prefs.voiceTestPhrase)
            doAfterTextChanged { Prefs.voiceTestPhrase = it?.toString().orEmpty() }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)).apply {
                setMargins(dp(16), dp(8), dp(16), dp(4))
            }
        })
        host.addView(switchRow(ctx, "Автопрослушивание", "После каждой правки произносить тестовую фразу", Prefs.voiceAutoPreview) {
            Prefs.voiceAutoPreview = it
        })

        // ---------- Группы параметров ----------
        for ((gi, group) in VoiceSpec.groups.withIndex()) {
            val params = VoiceSpec.all.filter { it.group == group }
            if (params.isEmpty()) continue
            val body = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                visibility = if (gi == 1) View.VISIBLE else View.GONE   // «Тон» открыт сразу
            }
            val head = TextView(ctx, null, 0, R.style.Jarvis_RowTitle)
            fun updateHead() {
                val open = body.visibility == View.VISIBLE
                val diff = params.count { !Prefs.voice.isDefault(it.key) }
                head.text = (if (open) "▾  " else "▸  ") + group + if (diff > 0) "  ·  изменено: $diff" else ""
                head.setTextColor(ContextCompat.getColor(ctx, if (diff > 0) R.color.accent else R.color.text))
            }
            head.setPadding(dp(16), dp(16), dp(16), dp(10))
            head.setOnClickListener {
                body.visibility = if (body.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                updateHead()
            }
            head.setOnLongClickListener {
                Prefs.voice.resetGroup(group)
                Prefs.saveVoice()
                refreshAll()
                toast(ctx, "Группа «$group» сброшена")
                true
            }
            refreshers.add { updateHead() }
            host.addView(divider(ctx))
            host.addView(head)
            for (p in params) {
                body.addView(if (p.toggle) toggleRow(ctx, p, refreshers) { changed(); updateHead() }
                else sliderRow(ctx, p, refreshers) { changed(); updateHead() })
            }
            host.addView(body)
            updateHead()
        }
        host.addView(View(ctx), LinearLayout.LayoutParams(1, dp(8)))
        refreshAll()
        return { refreshAll() }
    }

    // ---------- Строки ----------

    private fun sliderRow(ctx: Context, p: Param, refreshers: MutableList<() -> Unit>, onDone: () -> Unit): View {
        fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(6), dp(16), 0)
        }
        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(ctx, null, 0, R.style.Jarvis_RowTitle).apply {
            text = p.title
            textSize = 14f
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val value = TextView(ctx).apply {
            setTextColor(ContextCompat.getColor(ctx, R.color.accent))
            textSize = 14f
            setPadding(dp(10), dp(6), 0, dp(6))
        }
        head.addView(title)
        head.addView(value)
        box.addView(head)
        box.addView(TextView(ctx, null, 0, R.style.Jarvis_RowSub).apply { text = p.hint })

        val steps = ((p.max - p.min) / p.step).roundToInt()
        val seek = SeekBar(ctx).apply {
            max = steps
            setPadding(0, dp(8), 0, dp(6))
        }
        box.addView(seek)

        fun toValue(progress: Int) = (p.min + progress * p.step).coerceIn(p.min, p.max)
        fun show() { value.text = p.fmt(Prefs.voice[p.key]) }
        fun refresh() {
            seek.progress = ((Prefs.voice[p.key] - p.min) / p.step).roundToInt().coerceIn(0, steps)
            show()
        }
        refreshers.add { refresh() }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                Prefs.voice[p.key] = toValue(progress)
                show()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { onDone() }
        })

        // Тап по значению: точный ввод / сброс.
        value.setOnClickListener {
            val et = EditText(ctx).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
                setText(num(Prefs.voice[p.key]))
                setSelectAllOnFocus(true)
                setPadding(dp(20), dp(12), dp(20), dp(12))
            }
            AlertDialog.Builder(ctx)
                .setTitle(p.title)
                .setMessage(
                    "Диапазон: ${num(p.min)} … ${num(p.max)}, по умолчанию: ${num(p.def)}"
                )
                .setView(et)
                .setPositiveButton("OK") { _, _ ->
                    et.text.toString().replace(',', '.').toFloatOrNull()?.let {
                        Prefs.voice[p.key] = it
                        refresh(); onDone()
                    }
                }
                .setNeutralButton("По умолчанию") { _, _ ->
                    Prefs.voice.resetKey(p.key)
                    refresh(); onDone()
                }
                .setNegativeButton("Отмена", null)
                .show()
        }
        return box
    }

    private fun toggleRow(ctx: Context, p: Param, refreshers: MutableList<() -> Unit>, onDone: () -> Unit): View {
        val sw = switchRow(ctx, p.title, p.hint, Prefs.voice[p.key] > 0.5f) {
            Prefs.voice[p.key] = if (it) 1f else 0f
            onDone()
        }
        refreshers.add {
            val s = sw.findViewWithTag<SwitchCompat>("sw")
            val want = Prefs.voice[p.key] > 0.5f
            if (s != null && s.isChecked != want) {
                // Без повторного срабатывания: временно снимаем слушатель.
                s.setOnCheckedChangeListener(null)
                s.isChecked = want
                s.setOnCheckedChangeListener { _, on -> Prefs.voice[p.key] = if (on) 1f else 0f; onDone() }
            }
        }
        return sw
    }

    private fun switchRow(ctx: Context, title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit): View {
        fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val col = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        col.addView(TextView(ctx, null, 0, R.style.Jarvis_RowTitle).apply { text = title; textSize = 14f })
        col.addView(TextView(ctx, null, 0, R.style.Jarvis_RowSub).apply { text = sub })
        val sw = SwitchCompat(ctx).apply {
            tag = "sw"
            isChecked = checked
            thumbTintList = ContextCompat.getColorStateList(ctx, R.color.switch_thumb)
            trackTintList = ContextCompat.getColorStateList(ctx, R.color.switch_track)
            setOnCheckedChangeListener { _, on -> onChange(on) }
        }
        row.addView(col)
        row.addView(sw, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginStart = dp(12)
        })
        return row
    }

    // ---------- Мелочи ----------

    private fun chip(ctx: Context, text: String, onClick: () -> Unit, onLong: (() -> Boolean)? = null): TextView =
        TextView(ctx, null, 0, R.style.Jarvis_Chip).apply {
            this.text = text
            setOnClickListener { onClick() }
            onLong?.let { h -> setOnLongClickListener { h() } }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginEnd = (8 * ctx.resources.displayMetrics.density).toInt()
            }
        }

    private fun label(ctx: Context, text: String): TextView =
        TextView(ctx, null, 0, R.style.Jarvis_Label).apply {
            this.text = text
            val d = ctx.resources.displayMetrics.density
            setPadding((16 * d).toInt(), (16 * d).toInt(), (16 * d).toInt(), (8 * d).toInt())
        }

    private fun hint(ctx: Context, text: String): TextView =
        TextView(ctx, null, 0, R.style.Jarvis_Hint).apply {
            this.text = text
            val d = ctx.resources.displayMetrics.density
            setPadding((16 * d).toInt(), (6 * d).toInt(), (16 * d).toInt(), (4 * d).toInt())
        }

    private fun divider(ctx: Context): View =
        View(ctx).apply {
            setBackgroundColor(ContextCompat.getColor(ctx, R.color.border))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1).apply {
                marginStart = (16 * ctx.resources.displayMetrics.density).toInt()
            }
        }

    /** Число без хвоста нулей: 1.000 → «1», 0.880 → «0.88». */
    private fun num(v: Float): String =
        String.format(Locale.US, "%.3f", v).trimEnd('0').trimEnd('.').ifEmpty { "0" }

    private fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}
