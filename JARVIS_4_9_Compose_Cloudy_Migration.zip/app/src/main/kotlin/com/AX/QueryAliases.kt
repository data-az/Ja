package com.AX

import java.util.Locale

/**
 * Предобработка фразы пользователя ПЕРЕД отправкой в ИИ: сокращения, сленг и опечатки
 * заменяются стандартными названиями («открой тг» → «открой Telegram»).
 * Маленькие модели (1B/3B) сокращений не понимают, а с готовым названием справляются.
 *
 * КАК РАСШИРЯТЬ: допишите пару `"как говорят" to "Стандартное название"` в [BUILTIN]
 * (ключ — строчными буквами, «ё» писать как «е»; можно из нескольких слов)
 * или вызовите [register] во время работы. Порядок записей не важен: длинные ключи
 * применяются раньше коротких.
 *
 * Если у пользователя на телефоне есть приложение, название которого содержит стандартное имя
 * («Telegram» → «Telegram X»), в запрос подставляется ТОЧНОЕ название из списка установленных.
 */
object QueryAliases {

    /** Результат: [text] — запрос для модели, [changes] — что заменили (для логов). */
    class Result(val text: String, val changes: List<String>)

    private val BUILTIN: Map<String, String> = linkedMapOf(
        // --- Мессенджеры и соцсети ---
        "тг" to "Telegram", "тлг" to "Telegram", "tg" to "Telegram", "телега" to "Telegram",
        "телеграм" to "Telegram", "телеграмм" to "Telegram", "телегу" to "Telegram",
        "вк" to "VK", "вконтакте" to "VK", "вконтакт" to "VK", "в контакте" to "VK", "ви кей" to "VK", "vk" to "VK",
        "вацап" to "WhatsApp", "вацапп" to "WhatsApp", "ватсап" to "WhatsApp", "ватсапп" to "WhatsApp",
        "вотсап" to "WhatsApp", "вотсапп" to "WhatsApp", "воцап" to "WhatsApp", "ватцап" to "WhatsApp",
        "whats app" to "WhatsApp",
        "инста" to "Instagram", "инстаграм" to "Instagram", "инстограм" to "Instagram", "insta" to "Instagram",
        "тикток" to "TikTok", "тик ток" to "TikTok", "tik tok" to "TikTok",
        "вайбер" to "Viber", "вайбр" to "Viber",
        "дискорд" to "Discord", "дс" to "Discord",
        "скайп" to "Skype", "зум" to "Zoom",
        "твиттер" to "Twitter", "твитер" to "Twitter",
        // --- ИИ ---
        "опенаи" to "ChatGPT", "опен аи" to "ChatGPT", "open ai" to "ChatGPT", "openai" to "ChatGPT",
        "чатгпт" to "ChatGPT", "чат гпт" to "ChatGPT", "чатжпт" to "ChatGPT", "чат жпт" to "ChatGPT",
        "чат джипити" to "ChatGPT", "чат джи пи ти" to "ChatGPT", "chat gpt" to "ChatGPT", "гпт" to "ChatGPT",
        "gpt" to "ChatGPT",
        // --- Google и видео ---
        "ютуб" to "YouTube", "ютьюб" to "YouTube", "юутуб" to "YouTube", "you tube" to "YouTube",
        "хром" to "Chrome", "гугл хром" to "Chrome",
        "гугл" to "Google",
        "гмейл" to "Gmail", "джимейл" to "Gmail", "гмаил" to "Gmail",
        "нетфликс" to "Netflix", "спотифай" to "Spotify", "спотик" to "Spotify",
        // --- Прочее ---
        "стим" to "Steam",
        "озон" to "Ozon", "вб" to "Wildberries", "вайлдберриз" to "Wildberries", "валберис" to "Wildberries"
    )

    private val custom = LinkedHashMap<String, String>()
    private var compiled: Compiled? = null

    private class Compiled(val regex: Regex, val map: Map<String, String>)

    /** Добавить свои замены во время работы: `QueryAliases.register("тг" to "Telegram")`. */
    @Synchronized
    fun register(vararg pairs: Pair<String, String>) {
        for ((k, v) in pairs) if (k.isNotBlank() && v.isNotBlank()) custom[key(k)] = v.trim()
        compiled = null
    }

    /**
     * Заменяет сокращения в [text]. [labels] — названия установленных приложений: если среди них есть
     * приложение с нужным именем, подставляется оно (точное написание с ярлыка).
     * Не бросает исключений: при любой ошибке возвращает исходный текст.
     */
    fun preprocess(text: String, labels: Collection<String> = emptyList()): Result {
        if (text.isBlank()) return Result(text, emptyList())
        return try {
            val c = compiledNow()
            val changes = ArrayList<String>()
            val src = text.replace('ё', 'е').replace('Ё', 'Е')
            val out = c.regex.replace(src) { m ->
                val std = c.map[key(m.value)] ?: return@replace m.value
                val real = pickLabel(std, labels) ?: std
                changes.add("${m.value} → $real")
                real
            }
            Result(out, changes)
        } catch (e: Exception) {
            Result(text, emptyList())
        }
    }

    /** Нормализованный ключ: нижний регистр, «е» вместо «ё», одиночные пробелы. */
    private fun key(s: String): String =
        s.lowercase(Locale.ROOT).replace('ё', 'е').trim().replace(Regex("\\s+"), " ")

    /** Точное совпадение, иначе самое короткое название, содержащее стандартное имя. */
    private fun pickLabel(std: String, labels: Collection<String>): String? {
        if (labels.isEmpty()) return null
        val s = std.lowercase(Locale.ROOT)
        labels.firstOrNull { it.trim().equals(std, ignoreCase = true) }?.let { return it.trim() }
        return labels.map { it.trim() }
            .filter { it.lowercase(Locale.ROOT).contains(s) }
            .minByOrNull { it.length }
    }

    @Synchronized
    private fun compiledNow(): Compiled {
        compiled?.let { return it }
        val map = LinkedHashMap<String, String>()
        for ((k, v) in BUILTIN) map[key(k)] = v
        map.putAll(custom)
        // Длинные ключи первыми: «чат гпт» должно сработать раньше, чем «гпт».
        val alt = map.keys.sortedByDescending { it.length }
            .joinToString("|") { k -> k.split(' ').joinToString("\\s+") { Regex.escape(it) } }
        val regex = Regex("(?<![\\p{L}\\p{N}])($alt)(?![\\p{L}\\p{N}])", RegexOption.IGNORE_CASE)
        return Compiled(regex, map).also { compiled = it }
    }
}
