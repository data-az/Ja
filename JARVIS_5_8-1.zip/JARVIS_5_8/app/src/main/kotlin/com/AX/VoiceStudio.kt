package com.AX

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import java.io.File
import kotlin.math.roundToInt

/** Свои записи голосов: по одному файлу m4a на каждый звук ассистента, в папке приложения. */
object CustomVoices {
    private const val DIR = "voices"

    /** Звуки ассистента в порядке, в котором мастер проходит по ним. */
    val SLOTS: List<String> = listOf("zaprosvipolnen", "zagrujay", "yes", "kakpojelayte", "daser")

    private fun dir(ctx: Context): File = File(ctx.filesDir, DIR).also { it.mkdirs() }

    fun file(ctx: Context, name: String): File = File(dir(ctx), "$name.m4a")

    fun tmpFile(ctx: Context, name: String): File = File(dir(ctx), "$name.tmp.m4a")

    fun has(ctx: Context, name: String): Boolean = file(ctx, name).let { it.exists() && it.length() > 0 }

    fun count(ctx: Context): Int = SLOTS.count { has(ctx, it) }

    fun clearAll(ctx: Context) {
        SLOTS.forEach { file(ctx, it).delete() }
    }
}

/**
 * Мастер «Своя озвучка»: по одной фразе на каждый голос. «Записать» — старт/стоп,
 * «Прослушать» — проверка, «Далее» — следующий голос. Не записанные голоса остаются встроенными.
 */
class VoiceWizard(
    private val act: MainActivity,
    private val requestMic: () -> Unit,
    private val onChanged: () -> Unit,
) {
    private val dp = act.resources.displayMetrics.density
    private fun px(v: Int) = (v * dp).roundToInt()

    private var index = 0
    private var recorder: MediaRecorder? = null
    private var tmp: File? = null
    private var player: MediaPlayer? = null
    private var dialog: AlertDialog? = null

    private lateinit var title: TextView
    private lateinit var status: TextView
    private lateinit var recBtn: TextView
    private lateinit var playBtn: TextView
    private lateinit var delBtn: TextView
    private lateinit var backBtn: TextView
    private lateinit var nextBtn: TextView

    fun show() {
        val root = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(8), px(20), px(4))
        }
        title = TextView(act).apply {
            textSize = 17f
            setTextColor(act.getColor(R.color.accent))
            setPadding(0, px(4), 0, px(6))
        }
        root.addView(title)

        root.addView(TextView(act).apply {
            text = "Нажмите «Записать», скажите фразу и нажмите «Стоп». «Далее» — следующий голос. " +
                "Голоса, которые не записаны, остаются встроенными."
            textSize = 13f
            setTextColor(act.getColor(R.color.dim))
            setPadding(0, 0, 0, px(10))
        })

        status = TextView(act).apply {
            textSize = 13f
            setTextColor(act.getColor(R.color.text))
            setPadding(0, 0, 0, px(12))
        }
        root.addView(status)

        recBtn = chip("● Записать") { toggleRecord() }
        playBtn = chip("▶ Прослушать") { play() }
        delBtn = chip("Удалить") { deleteCurrent() }
        root.addView(row(recBtn, playBtn, delBtn))

        backBtn = chip("‹ Назад") { move(-1) }
        nextBtn = chip("Далее ›") { next() }
        root.addView(row(backBtn, nextBtn), LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = px(8) })

        refresh()
        dialog = AlertDialog.Builder(act, R.style.Jarvis_AlertDialog)
            .setTitle("Своя озвучка")
            .setView(root)
            .setNegativeButton("Закрыть", null)
            .setOnDismissListener {
                stopRecording(save = false)
                stopPlayer()
            }
            .show()
    }

    private fun chip(label: String, onClick: () -> Unit): TextView = TextView(act).apply {
        text = label
        textSize = 13f
        gravity = Gravity.CENTER
        setTextColor(act.getColor(R.color.text))
        setBackgroundResource(R.drawable.chip)
        setPadding(px(8), px(10), px(8), px(10))
        isClickable = true
        setOnClickListener { onClick() }
    }

    private fun row(vararg views: View) = LinearLayout(act).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEachIndexed { i, v ->
            addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) marginStart = px(6)
            })
        }
    }

    private fun refresh() {
        val name = CustomVoices.SLOTS[index]
        val total = CustomVoices.SLOTS.size
        title.text = "Голос ${index + 1} из $total"
        val has = CustomVoices.has(act, name)
        status.text = "Звук: $name. " + if (has) "Записан, можно прослушать." else "Ещё не записан (стандартный)."
        val recording = recorder != null
        recBtn.text = if (recording) "■ Стоп" else "● Записать"
        setEnabled(playBtn, has && !recording)
        setEnabled(delBtn, has && !recording)
        setEnabled(backBtn, index > 0 && !recording)
        nextBtn.text = if (index == total - 1) "Готово" else "Далее ›"
    }

    private fun setEnabled(v: TextView, on: Boolean) {
        v.isEnabled = on
        v.alpha = if (on) 1f else 0.4f
    }

    private fun move(delta: Int) {
        stopRecording(save = true)
        index = (index + delta).coerceIn(0, CustomVoices.SLOTS.lastIndex)
        refresh()
    }

    private fun next() {
        stopRecording(save = true)
        if (index == CustomVoices.SLOTS.lastIndex) {
            dialog?.dismiss()
        } else {
            index++
            refresh()
        }
    }

    private fun toggleRecord() {
        if (recorder != null) stopRecording(save = true) else startRecording()
    }

    private fun startRecording() {
        if (ContextCompat.checkSelfPermission(act, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            toast("Сначала разрешите микрофон")
            requestMic()
            return
        }
        stopPlayer()
        val name = CustomVoices.SLOTS[index]
        val out = CustomVoices.tmpFile(act, name).also { it.delete() }
        val r = MediaRecorder()
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioSamplingRate(44100)
            r.setAudioChannels(1)
            r.setAudioEncodingBitRate(96_000)
            r.setOutputFile(out.absolutePath)
            r.prepare()
            r.start()
        } catch (e: Exception) {
            r.release()
            toast("Не удалось начать запись: ${e.message}")
            return
        }
        recorder = r
        tmp = out
        refresh()
    }

    private fun stopRecording(save: Boolean) {
        val r = recorder ?: return
        recorder = null
        var ok = false
        try {
            r.stop()
            ok = true
        } catch (e: RuntimeException) {
            // Слишком короткая запись: stop() на ней бросает исключение.
        }
        r.release()
        val out = tmp
        tmp = null
        if (out != null && save && ok) {
            val target = CustomVoices.file(act, CustomVoices.SLOTS[index])
            target.delete()
            if (out.renameTo(target)) {
                toast("Голос сохранён")
                onChanged()
            } else {
                out.delete()
                toast("Не удалось сохранить запись")
            }
        } else {
            out?.delete()
            if (save) toast("Запись слишком короткая, попробуйте ещё раз")
        }
        refresh()
    }

    private fun play() {
        val f = CustomVoices.file(act, CustomVoices.SLOTS[index])
        stopPlayer()
        try {
            player = MediaPlayer().apply {
                setDataSource(f.absolutePath)
                setOnCompletionListener { stopPlayer() }
                prepare()
                start()
            }
        } catch (e: Exception) {
            stopPlayer()
            toast("Не удалось проиграть: ${e.message}")
        }
    }

    private fun stopPlayer() {
        player?.let {
            try {
                it.stop()
            } catch (e: IllegalStateException) {
                // уже остановлен
            }
            it.release()
        }
        player = null
    }

    private fun deleteCurrent() {
        CustomVoices.file(act, CustomVoices.SLOTS[index]).delete()
        onChanged()
        refresh()
    }

    private fun toast(msg: String) = Toast.makeText(act, msg, Toast.LENGTH_SHORT).show()
}

/** Блок в Настройках → Звук и распознавание: вход в мастер и сброс к встроенным голосам. */
object VoiceBlock {

    fun build(act: MainActivity, requestMic: () -> Unit): LinearLayout {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()

        val root = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL }
        root.addView(TextView(act).apply {
            text = "СВОЯ ОЗВУЧКА"
            setTextColor(act.getColor(R.color.accent))
            textSize = 12f
            setPadding(px(4), px(24), px(4), px(8))
        })

        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(16), px(4), px(16), px(4))
        }
        val total = CustomVoices.SLOTS.size
        val subtitle = TextView(act).apply {
            textSize = 12f
            setTextColor(act.getColor(R.color.dim))
            setPadding(0, px(2), 0, px(12))
        }
        fun renderCount() {
            subtitle.text = "Записано: ${CustomVoices.count(act)} из $total. Не записанные голоса — встроенные."
        }

        val open = TextView(act).apply {
            text = "Записать свою озвучку"
            textSize = 14f
            setTextColor(act.getColor(R.color.text))
            setPadding(0, px(12), 0, px(2))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                VoiceWizard(act, requestMic) {
                    SoundPlayer.current?.reload()
                    renderCount()
                }.show()
            }
        }
        val reset = TextView(act).apply {
            text = "Вернуть встроенные голоса"
            textSize = 13f
            setTextColor(act.getColor(R.color.accent))
            setPadding(0, px(10), 0, px(12))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                CustomVoices.clearAll(act)
                SoundPlayer.current?.reload()
                renderCount()
            }
        }
        box.addView(open)
        box.addView(subtitle)
        box.addView(reset)
        renderCount()
        root.addView(box)
        return root
    }
}
