package com.AX

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import java.util.Collections

/**
 * Проигрывает звуки ассистента. Если пользователь записал свой голос ([CustomVoices]),
 * играет его файл, иначе — встроенный res/raw. Случайный звук выбирается так,
 * что один и тот же не идёт два раза подряд. Воспроизведение не блокирует поток.
 */
class SoundPlayer(private val context: Context) {

    private var pool: SoundPool = makePool()
    private val ids = mutableMapOf<String, Int>()
    private val loaded: MutableSet<Int> = Collections.synchronizedSet(HashSet<Int>())
    private val playing: MutableSet<Int> = Collections.synchronizedSet(HashSet<Int>())
    private var lastName: String? = null

    @Volatile
    private var released = false

    init {
        current = this
        loadAll()
    }

    private fun makePool(): SoundPool {
        val p = SoundPool.Builder()
            .setMaxStreams(2)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .build()
        p.setOnLoadCompleteListener { _, sampleId, status ->
            val name = ids.entries.firstOrNull { it.value == sampleId }?.key ?: "#$sampleId"
            if (status == 0) {
                loaded.add(sampleId)
                AppLog.sound("INFO", "Звук $name загружен (id $sampleId)", null)
            } else {
                AppLog.sound("ERR", "Звук $name не загрузился, статус $status", "звук $name не загрузился")
            }
        }
        return p
    }

    private fun loadAll() {
        for (name in CustomVoices.SLOTS) {
            val custom = CustomVoices.file(context, name)
            if (CustomVoices.has(context, name)) {
                ids[name] = pool.load(custom.absolutePath, 1)
                continue
            }
            val resId = context.resources.getIdentifier(name, "raw", context.packageName)
            if (resId != 0) {
                ids[name] = pool.load(context, resId, 1)
            } else {
                AppLog.sound("ERR", "Нет ресурса res/raw/$name.wav", "нет файла $name.wav")
            }
        }
    }

    /** Перезагружает звуки, например после записи или сброса своего голоса. */
    @Synchronized
    fun reload() {
        if (released) return
        pool.release()
        ids.clear()
        loaded.clear()
        synchronized(playing) { playing.clear() }
        lastName = null
        pool = makePool()
        loadAll()
    }

    /**
     * Запускает случайный звук и сразу возвращает id потока (0, если играть нечего).
     * Вызывается из рабочего потока команд, поэтому синхронизирован: [lastName] не должен гоняться.
     */
    @Synchronized
    fun playRandom(): Int {
        if (released) return 0
        val ready = ids.filterValues { it in loaded }.keys
        if (ready.isEmpty()) {
            AppLog.sound("ERR", "Готовые звуки не воспроизведены: ни один звук ещё не загружен (${ids.size} в очереди)", "звуки ещё не загружены")
            return 0
        }
        val candidates = ready.filter { it != lastName }.ifEmpty { ready.toList() }
        val name = candidates.random()
        lastName = name
        val v = Prefs.soundVolume
        val stream = pool.play(ids.getValue(name), v, v, 1, 0, 1f)
        if (stream != 0) playing.add(stream)
        val source = if (CustomVoices.has(context, name)) "свой голос" else "встроенный"
        AppLog.sound(
            if (stream == 0) "ERR" else "INFO",
            "Звук $name ($source): громкость ${"%.2f".format(java.util.Locale.US, v)}, поток $stream" +
                if (stream == 0) " — SoundPool отказался играть" else "",
            "звук $name" + if (stream == 0) " не сыграл" else ""
        )
        return stream
    }

    fun stop(streamId: Int) {
        if (!released && streamId != 0) pool.stop(streamId)
    }

    /** Обрывает все звуки, которые сейчас играют (перебивание голосом). */
    fun stopAll() {
        if (released) return
        synchronized(playing) {
            playing.forEach { pool.stop(it) }
            playing.clear()
        }
    }

    fun release() {
        released = true
        pool.release()
    }

    companion object {
        /** Последний созданный проигрыватель: нужен, чтобы перебивание работало из любого места. */
        @Volatile
        var current: SoundPlayer? = null

        fun stopCurrent() {
            current?.stopAll()
        }
    }
}
