// Copyright © 2026 AX. Все права защищены / All rights reserved.
// Копирование, распространение и извлечение кода без разрешения правообладателя запрещены.
package com.AX

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

/** Общее оформление настроек: заголовок раздела и карточка выглядят одинаково везде. */
object SettingsStyle {

    /** Подпись раздела: точка и заглавные буквы, как в page_settings.xml. */
    fun header(act: Activity, title: String, topDp: Int = 24): LinearLayout {
        val dp = act.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).roundToInt()
        val dot = View(act).apply {
            setBackgroundResource(R.drawable.dot)
            backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(act, R.color.accent))
        }
        val label = TextView(act).apply {
            text = title
            setTextColor(ContextCompat.getColor(act, R.color.dim))
            textSize = 11f
            letterSpacing = 0.14f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        return LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(4), px(topDp), px(4), px(8))
            addView(dot, LinearLayout.LayoutParams(px(6), px(6)))
            addView(label, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { marginStart = px(8) })
        }
    }

    /** Карточка с тем же фоном и скруглением, что у блоков настроек. */
    fun card(act: Activity): LinearLayout = LinearLayout(act).apply {
        orientation = LinearLayout.VERTICAL
        background = ContextCompat.getDrawable(act, R.drawable.card)
        clipToOutline = true
    }
}
