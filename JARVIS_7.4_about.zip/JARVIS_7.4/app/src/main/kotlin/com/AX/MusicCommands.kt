// Copyright © 2026 AX. Все права защищены / All rights reserved.
// Копирование, распространение и извлечение кода без разрешения правообладателя запрещены.
package com.AX

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.provider.MediaStore
import android.view.KeyEvent

/**
 * Музыка, видео и фото.
 *  - «включи <слово категории> [запрос]» открывает приложение, выбранное в Настройках → Команды.
 *    Для музыки с запросом приложению передаётся поиск («включи музыку Imagine»).
 *  - «включи музыку» без выбранного приложения нажимает «воспроизвести» у текущего плеера.
 *  - «пауза», «дальше», «предыдущий» — кнопки медиа.
 * «открой …» сюда не относится: такие фразы идут в поиск приложений.
 */
object MusicCommands {

    /** Категория → слова, которыми её можно назвать. */
    val CATEGORY_WORDS: Map<String, List<String>> = linkedMapOf(
        "music" to listOf("музыку", "музыка", "музло", "музон", "трек", "саунд", "звук", "песню", "песня", "альбом", "исполнителя"),
        "video" to listOf("видео", "видос", "ролик"),
        "photo" to listOf("фото", "фотки", "снимки", "картинки")
    )

    val CATEGORY_TITLES: Map<String, String> = mapOf("music" to "Музыка", "video" to "Видео", "photo" to "Фото")

    private const val YOUTUBE_PKG = "com.google.android.youtube"
    private const val YOUTUBE = "включи на ютубе"

    /** Старые фразы без слова категории: всегда музыка. */
    private val LEGACY_PLAY = listOf("включи избранное", "включи скачанное", "поставь музыку", "играй")

    /** Фраза → (код кнопки медиа, что ответить). */
    private val CONTROL: Map<String, Pair<Int, String>> = mapOf(
        "пауза" to (KeyEvent.KEYCODE_MEDIA_PAUSE to "Пауза"),
        "продолжить" to (KeyEvent.KEYCODE_MEDIA_PLAY to "Продолжаю"),
        "дальше" to (KeyEvent.KEYCODE_MEDIA_NEXT to "Следующий трек"),
        "следующий трек" to (KeyEvent.KEYCODE_MEDIA_NEXT to "Следующий трек"),
        "следующая песня" to (KeyEvent.KEYCODE_MEDIA_NEXT to "Следующий трек"),
        "предыдущий трек" to (KeyEvent.KEYCODE_MEDIA_PREVIOUS to "Предыдущий трек"),
        "предыдущая песня" to (KeyEvent.KEYCODE_MEDIA_PREVIOUS to "Предыдущий трек")
    )

    /** «включи <слово> [запрос]» или «поставь <слово>» → (категория, запрос). */
    private fun parse(c: String): Pair<String, String>? {
        val rest = when {
            c.startsWith("включи ") -> c.removePrefix("включи ")
            c.startsWith("поставь ") -> c.removePrefix("поставь ")
            else -> return null
        }
        val words = rest.trim().split(' ').filter { it.isNotEmpty() }
        val first = words.firstOrNull() ?: return null
        val cat = CATEGORY_WORDS.entries.firstOrNull { first in it.value }?.key ?: return null
        return cat to words.drop(1).joinToString(" ")
    }

    fun matches(c: String): Boolean =
        CONTROL.containsKey(c) ||
            c.startsWith(YOUTUBE) ||
            LEGACY_PLAY.any { c.startsWith(it) } ||
            parse(c) != null

    fun run(ctx: Context, c: String): Reply {
        CONTROL[c]?.let { (code, label) -> return press(ctx, code, label) }
        if (c.startsWith(YOUTUBE)) {
            return play(ctx, c.removePrefix(YOUTUBE).trim(), YOUTUBE_PKG)
        }
        parse(c)?.let { (cat, query) -> return playCategory(ctx, cat, query) }
        val legacy = LEGACY_PLAY.first { c.startsWith(it) }
        val query = c.removePrefix(legacy).trim()
        if (query.isEmpty()) return press(ctx, KeyEvent.KEYCODE_MEDIA_PLAY, "Продолжаю музыку")
        return play(ctx, query, null)
    }

    private fun playCategory(ctx: Context, cat: String, query: String): Reply {
        val pkg = Prefs.categoryPkg(cat)
        val label = Prefs.categoryLabel(cat)
        if (pkg.isEmpty()) {
            if (cat != "music") {
                return Reply(false, "Выберите приложение для «${CATEGORY_TITLES[cat]}» в Настройках → Команды")
            }
            // Музыка без выбранного приложения: поиск у системного плеера или кнопка «воспроизвести».
            return if (query.isEmpty()) press(ctx, KeyEvent.KEYCODE_MEDIA_PLAY, "Продолжаю музыку")
            else play(ctx, query, null)
        }
        if (cat == "music" && query.isNotEmpty()) {
            val r = play(ctx, query, pkg)
            if (r.ok) return r
        }
        return openPackage(ctx, pkg, label)
    }

    /** Открывает приложение по имени пакета (то, что выбрано в настройках). */
    fun openPackage(ctx: Context, pkg: String, label: String): Reply {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg)
            ?: return Reply(false, "«$label» не открывается: приложение удалено или у него нет экрана запуска")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent)
            Reply(true, "Открываю $label")
        } catch (e: Exception) {
            Reply(false, "Не удалось открыть «$label»")
        }
    }

    private fun press(ctx: Context, code: Int, label: String): Reply {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return Reply(true, label)
    }

    /** Поиск в плеере. [pkg] = null — любой плеер, который ответит на запрос системы. */
    private fun play(ctx: Context, query: String, pkg: String?): Reply {
        val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            // SearchManager.QUERY — правильный ключ для строки поиска (значение "query")
            putExtra(SearchManager.QUERY, query)
            if (pkg != null) setPackage(pkg)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            ctx.startActivity(intent)
            Reply(true, "Включаю: $query")
        } catch (e: Exception) {
            Reply(false, "Нет музыкального приложения для «$query»")
        }
    }
}
