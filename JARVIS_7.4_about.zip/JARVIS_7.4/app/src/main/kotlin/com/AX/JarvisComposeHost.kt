// Copyright © 2026 AX. Все права защищены / All rights reserved.
// Копирование, распространение и извлечение кода без разрешения правообладателя запрещены.
package com.AX

import android.view.LayoutInflater
import android.view.View
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

@Composable
fun JarvisComposeHost(
    currentPage: Int,
    showDock: Boolean,
    onPageSelected: (Int) -> Unit,
    onLegacyRootReady: (View) -> Unit,
) {
    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            factory = { context ->
                LayoutInflater.from(context)
                    .inflate(R.layout.activity_main, null, false)
                    .also { legacyRoot -> onLegacyRootReady(legacyRoot) }
            },
            modifier = Modifier.fillMaxSize(),
            update = { },
        )

        AnimatedVisibility(
            visible = showDock,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = fadeIn(tween(300, easing = FastOutSlowInEasing)) +
                slideInVertically(tween(320, easing = FastOutSlowInEasing)) { it / 2 },
            exit = fadeOut(tween(200, easing = FastOutSlowInEasing)) +
                slideOutVertically(tween(220, easing = FastOutSlowInEasing)) { it / 2 },
        ) {
            BottomDock(
                selectedPage = currentPage,
                onPageSelected = onPageSelected,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(
                        bottom = 12.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
                    ),
            )
        }
    }
}

/**
 * Нижнее меню из трёх вкладок. Стеклянный вид: полупрозрачная заливка, светлая кромка,
 * верхний блик. Пилюля выбранной вкладки едет пружиной (с лёгким перелётом), а не прыгает.
 */
@Composable
private fun BottomDock(
    selectedPage: Int,
    onPageSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(34.dp)
    val pillShape = RoundedCornerShape(27.dp)

    BoxWithConstraints(
        modifier = modifier
            .height(70.dp)
            .clip(shape)
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    listOf(Color(0xB3FFFFFF), Color(0x1AFFFFFF), Color(0x66A9DFFF), Color(0x14FFFFFF))
                ),
                shape = shape,
            ),
    ) {
        val slotWidth = maxWidth / 3
        val density = LocalDensity.current
        val slotPx = with(density) { slotWidth.toPx() }
        val insetPx = with(density) { 5.dp.toPx() }

        // Пилюля выбранной вкладки. Позицию читаем только в graphicsLayer, поэтому анимация не перерисовывает меню.
        val position = remember { Animatable(selectedPage.toFloat()) }
        LaunchedEffect(selectedPage) {
            position.animateTo(
                targetValue = selectedPage.toFloat(),
                animationSpec = spring(dampingRatio = 0.72f, stiffness = 300f),
            )
        }

        Box(
            modifier = Modifier
                .width(slotWidth - 10.dp)
                .height(60.dp)
                .align(Alignment.CenterStart)
                .graphicsLayer { translationX = position.value * slotPx + insetPx }
                .clip(pillShape)
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0x4DFFFFFF), Color(0x1AC7E8FF), Color(0x0FFFFFFF))
                    ),
                    pillShape,
                )
                .border(
                    width = 1.dp,
                    brush = Brush.linearGradient(listOf(Color(0xA6FFFFFF), Color(0x33FFFFFF))),
                    shape = pillShape,
                ),
        )

        // Верхний блик: вся панель будто из стекла.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(30.dp)
                .clip(RoundedCornerShape(topStart = 34.dp, topEnd = 34.dp))
                .background(Brush.verticalGradient(listOf(Color(0x3DFFFFFF), Color(0x00FFFFFF)))),
        )

        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = 3.dp, vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            DockItem(0, selectedPage, "Главная", R.drawable.ic_nav_home, onPageSelected, Modifier.weight(1f))
            DockItem(1, selectedPage, "Логи", R.drawable.ic_nav_logs, onPageSelected, Modifier.weight(1f))
            DockItem(2, selectedPage, "Настройки", R.drawable.ic_nav_settings, onPageSelected, Modifier.weight(1f))
        }
    }
}

@Composable
private fun DockItem(
    page: Int,
    selectedPage: Int,
    label: String,
    iconRes: Int,
    onPageSelected: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val selected = page == selectedPage
    val scale by animateFloatAsState(
        targetValue = if (selected) 1.08f else 0.96f,
        animationSpec = spring(dampingRatio = 0.9f, stiffness = 300f),
        label = "dock-icon-scale-$page",
    )
    val alpha by animateFloatAsState(
        targetValue = if (selected) 1f else 0.62f,
        animationSpec = tween(320, easing = FastOutSlowInEasing),
        label = "dock-item-alpha-$page",
    )
    val haptics = LocalHapticFeedback.current
    val interaction = remember { MutableInteractionSource() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(28.dp))
            .clickable(
                interactionSource = interaction,
                indication = null,
            ) {
                if (!selected) {
                    haptics.performHapticFeedback(HapticFeedbackType.Confirm)
                    onPageSelected(page)
                }
            },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Icon(
            painter = painterResource(iconRes),
            contentDescription = label,
            tint = Color.White.copy(alpha = alpha),
            modifier = Modifier
                .size(23.dp)
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                },
        )
        Text(
            text = label,
            color = Color.White.copy(alpha = alpha),
            fontSize = 10.sp,
            lineHeight = 12.sp,
            modifier = Modifier.padding(top = 3.dp),
        )
    }
}
