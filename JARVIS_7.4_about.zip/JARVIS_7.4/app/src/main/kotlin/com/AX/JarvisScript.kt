// Copyright © 2026 AX. Все права защищены / All rights reserved.
// Копирование, распространение и извлечение кода без разрешения правообладателя запрещены.
package com.AX

import android.content.Context

/**
 * JarvisScript — маленький свой язык для сценариев. Слова языка русские.
 *
 *   # комментарий
 *   пусть имя = "Тони"
 *   сказать "Привет, " + имя
 *   повторить 3 раз { выполнить "включи фонарик" }
 *   если громкость > 50 { сказать "громко" } иначе { сказать "тихо" }
 *   функция квадрат(x) { вернуть x * x }
 *   сказать квадрат(7)
 *
 * Инструкции: пусть, сказать, выполнить, ждать, если/иначе, пока, повторить N раз,
 * функция/вернуть, стоп. Значения: числа, строки, да/нет. Операторы: + - * / % == != < > <= >= и или не.
 */
class JarvisScript(private val host: Host) {

    /** Что умеет делать окружение: приложение подставляет свои действия. */
    interface Host {
        /** Показать/озвучить текст. */
        fun say(text: String)

        /** Выполнить обычную голосовую команду («открой браузер»). Вернуть ответ. */
        fun command(text: String): String

        /** Пауза в миллисекундах. */
        fun sleep(ms: Long)

        /** Нужно ли остановиться (пользователь нажал «Стоп»). */
        fun cancelled(): Boolean
    }

    class ScriptError(message: String, val line: Int) : Exception("строка $line: $message")

    private class ReturnSignal(val value: Any?) : RuntimeException(null, null, false, false)
    private class StopSignal : RuntimeException(null, null, false, false)

    // ---------------- Лексер ----------------

    private enum class T { NUM, STR, ID, OP, LBRACE, RBRACE, LPAREN, RPAREN, COMMA, NL, EOF }

    private class Tok(val type: T, val text: String, val line: Int)

    private fun lex(src: String): List<Tok> {
        val out = ArrayList<Tok>()
        var i = 0
        var line = 1
        while (i < src.length) {
            val c = src[i]
            when {
                c == '\n' -> { out.add(Tok(T.NL, "\n", line)); line++; i++ }
                c == ' ' || c == '\t' || c == '\r' || c == ';' -> i++
                c == '#' -> while (i < src.length && src[i] != '\n') i++
                c.isDigit() -> {
                    val st = i
                    while (i < src.length && (src[i].isDigit() || src[i] == '.')) i++
                    out.add(Tok(T.NUM, src.substring(st, i), line))
                }
                c == '"' || c == '«' -> {
                    val close = if (c == '«') '»' else '"'
                    val sb = StringBuilder()
                    i++
                    while (i < src.length && src[i] != close) {
                        if (src[i] == '\\' && i + 1 < src.length) {
                            i++
                            sb.append(when (src[i]) { 'n' -> '\n'; 't' -> '\t'; else -> src[i] })
                        } else {
                            if (src[i] == '\n') line++
                            sb.append(src[i])
                        }
                        i++
                    }
                    if (i >= src.length) throw ScriptError("строка не закрыта кавычкой", line)
                    i++
                    out.add(Tok(T.STR, sb.toString(), line))
                }
                c.isLetter() || c == '_' -> {
                    val st = i
                    while (i < src.length && (src[i].isLetterOrDigit() || src[i] == '_')) i++
                    out.add(Tok(T.ID, src.substring(st, i), line))
                }
                c == '{' -> { out.add(Tok(T.LBRACE, "{", line)); i++ }
                c == '}' -> { out.add(Tok(T.RBRACE, "}", line)); i++ }
                c == '(' -> { out.add(Tok(T.LPAREN, "(", line)); i++ }
                c == ')' -> { out.add(Tok(T.RPAREN, ")", line)); i++ }
                c == ',' -> { out.add(Tok(T.COMMA, ",", line)); i++ }
                else -> {
                    val two = if (i + 1 < src.length) src.substring(i, i + 2) else ""
                    if (two in setOf("==", "!=", "<=", ">=")) {
                        out.add(Tok(T.OP, two, line)); i += 2
                    } else if (c in "+-*/%<>=") {
                        out.add(Tok(T.OP, c.toString(), line)); i++
                    } else {
                        throw ScriptError("неизвестный символ «$c»", line)
                    }
                }
            }
        }
        out.add(Tok(T.EOF, "", line))
        return out
    }

    // ---------------- Дерево ----------------

    private sealed class Expr(val line: Int)
    private class Lit(val v: Any?, line: Int) : Expr(line)
    private class Var(val name: String, line: Int) : Expr(line)
    private class Bin(val op: String, val a: Expr, val b: Expr, line: Int) : Expr(line)
    private class Un(val op: String, val a: Expr, line: Int) : Expr(line)
    private class Call(val name: String, val args: List<Expr>, line: Int) : Expr(line)

    private sealed class Stmt(val line: Int)
    private class Let(val name: String, val e: Expr, line: Int) : Stmt(line)
    private class Say(val e: Expr, line: Int) : Stmt(line)
    private class Run(val e: Expr, line: Int) : Stmt(line)
    private class Wait(val e: Expr, line: Int) : Stmt(line)
    private class If(val c: Expr, val a: List<Stmt>, val b: List<Stmt>, line: Int) : Stmt(line)
    private class While(val c: Expr, val body: List<Stmt>, line: Int) : Stmt(line)
    private class Repeat(val n: Expr, val body: List<Stmt>, line: Int) : Stmt(line)
    private class Func(val name: String, val params: List<String>, val body: List<Stmt>, line: Int) : Stmt(line)
    private class Ret(val e: Expr?, line: Int) : Stmt(line)
    private class ExprStmt(val e: Expr, line: Int) : Stmt(line)
    private class Halt(line: Int) : Stmt(line)

    // ---------------- Разбор ----------------

    private inner class Parser(val toks: List<Tok>) {
        var p = 0
        val cur: Tok get() = toks[p]

        fun skipNl() { while (cur.type == T.NL) p++ }

        fun isWord(w: String) = cur.type == T.ID && cur.text.lowercase() == w

        fun expect(t: T, what: String): Tok {
            if (cur.type != t) throw ScriptError("ожидалось $what", cur.line)
            return toks[p++]
        }

        fun program(): List<Stmt> {
            val out = ArrayList<Stmt>()
            skipNl()
            while (cur.type != T.EOF) {
                out.add(statement())
                skipNl()
            }
            return out
        }

        fun block(): List<Stmt> {
            skipNl()
            expect(T.LBRACE, "«{»")
            val out = ArrayList<Stmt>()
            skipNl()
            while (cur.type != T.RBRACE) {
                if (cur.type == T.EOF) throw ScriptError("не хватает «}»", cur.line)
                out.add(statement())
                skipNl()
            }
            p++
            return out
        }

        fun statement(): Stmt {
            val t = cur
            val line = t.line
            if (t.type == T.ID) {
                when (t.text.lowercase()) {
                    "пусть" -> {
                        p++
                        val name = expect(T.ID, "имя переменной").text
                        val op = expect(T.OP, "«=»")
                        if (op.text != "=") throw ScriptError("ожидалось «=»", op.line)
                        return Let(name, expr(), line)
                    }
                    "сказать" -> { p++; return Say(expr(), line) }
                    "выполнить" -> { p++; return Run(expr(), line) }
                    "ждать" -> { p++; return Wait(expr(), line) }
                    "стоп" -> { p++; return Halt(line) }
                    "вернуть" -> {
                        p++
                        val e = if (cur.type == T.NL || cur.type == T.RBRACE || cur.type == T.EOF) null else expr()
                        return Ret(e, line)
                    }
                    "если" -> {
                        p++
                        val c = expr()
                        val a = block()
                        var b: List<Stmt> = emptyList()
                        val save = p
                        skipNl()
                        if (isWord("иначе")) { p++; b = block() } else p = save
                        return If(c, a, b, line)
                    }
                    "пока" -> { p++; val c = expr(); return While(c, block(), line) }
                    "повторить" -> {
                        p++
                        val n = expr()
                        if (isWord("раз") || isWord("раза")) p++
                        return Repeat(n, block(), line)
                    }
                    "функция" -> {
                        p++
                        val name = expect(T.ID, "имя функции").text
                        expect(T.LPAREN, "«(»")
                        val params = ArrayList<String>()
                        while (cur.type != T.RPAREN) {
                            params.add(expect(T.ID, "имя параметра").text)
                            if (cur.type == T.COMMA) p++ else break
                        }
                        expect(T.RPAREN, "«)»")
                        return Func(name, params, block(), line)
                    }
                }
                // Присваивание без «пусть»: x = 5
                if (toks[p + 1].type == T.OP && toks[p + 1].text == "=") {
                    p += 2
                    return Let(t.text, expr(), line)
                }
            }
            return ExprStmt(expr(), line)
        }

        fun expr(): Expr = orExpr()

        fun orExpr(): Expr {
            var l = andExpr()
            while (isWord("или")) { val ln = cur.line; p++; l = Bin("или", l, andExpr(), ln) }
            return l
        }

        fun andExpr(): Expr {
            var l = cmpExpr()
            while (isWord("и")) { val ln = cur.line; p++; l = Bin("и", l, cmpExpr(), ln) }
            return l
        }

        fun cmpExpr(): Expr {
            var l = addExpr()
            while (cur.type == T.OP && cur.text in setOf("==", "!=", "<", ">", "<=", ">=")) {
                val op = cur.text; val ln = cur.line; p++
                l = Bin(op, l, addExpr(), ln)
            }
            return l
        }

        fun addExpr(): Expr {
            var l = mulExpr()
            while (cur.type == T.OP && (cur.text == "+" || cur.text == "-")) {
                val op = cur.text; val ln = cur.line; p++
                l = Bin(op, l, mulExpr(), ln)
            }
            return l
        }

        fun mulExpr(): Expr {
            var l = unary()
            while (cur.type == T.OP && (cur.text == "*" || cur.text == "/" || cur.text == "%")) {
                val op = cur.text; val ln = cur.line; p++
                l = Bin(op, l, unary(), ln)
            }
            return l
        }

        fun unary(): Expr {
            if (cur.type == T.OP && cur.text == "-") { val ln = cur.line; p++; return Un("-", unary(), ln) }
            if (isWord("не")) { val ln = cur.line; p++; return Un("не", unary(), ln) }
            return primary()
        }

        fun primary(): Expr {
            val t = cur
            when (t.type) {
                T.NUM -> { p++; return Lit(t.text.toDoubleOrNull() ?: throw ScriptError("плохое число «${t.text}»", t.line), t.line) }
                T.STR -> { p++; return Lit(t.text, t.line) }
                T.LPAREN -> {
                    p++
                    val e = expr()
                    expect(T.RPAREN, "«)»")
                    return e
                }
                T.ID -> {
                    p++
                    when (t.text.lowercase()) {
                        "да" -> return Lit(true, t.line)
                        "нет" -> return Lit(false, t.line)
                    }
                    if (cur.type == T.LPAREN) {
                        p++
                        val args = ArrayList<Expr>()
                        while (cur.type != T.RPAREN) {
                            args.add(expr())
                            if (cur.type == T.COMMA) p++ else break
                        }
                        expect(T.RPAREN, "«)»")
                        return Call(t.text, args, t.line)
                    }
                    return Var(t.text, t.line)
                }
                else -> throw ScriptError("не понял «${t.text.ifEmpty { "конец" }}»", t.line)
            }
        }
    }

    // ---------------- Выполнение ----------------

    private class Scope(val parent: Scope?) {
        val vars = HashMap<String, Any?>()

        fun find(name: String): Scope? {
            var s: Scope? = this
            while (s != null) { if (s.vars.containsKey(name)) return s; s = s.parent }
            return null
        }

        fun set(name: String, v: Any?) { (find(name) ?: this).vars[name] = v }
    }

    private val funcs = HashMap<String, Func>()
    private var steps = 0

    /** Выполняет сценарий. Возвращает null, если всё хорошо, или текст ошибки. */
    fun run(source: String): String? {
        funcs.clear()
        steps = 0
        depth = 0
        return try {
            val prog = Parser(lex(source)).program()
            val global = Scope(null)
            // Функции доступны ещё до места, где объявлены.
            prog.filterIsInstance<Func>().forEach { funcs[it.name.lowercase()] = it }
            execBlock(prog, global)
            null
        } catch (e: ScriptError) {
            e.message
        } catch (e: StopSignal) {
            null
        } catch (e: ReturnSignal) {
            null
        } catch (e: StackOverflowError) {
            "слишком глубокая рекурсия"
        } catch (e: Exception) {
            "ошибка: ${e.message}"
        }
    }

    private fun tick(line: Int) {
        if (host.cancelled()) throw StopSignal()
        if (++steps > MAX_STEPS) throw ScriptError("слишком много шагов (бесконечный цикл?)", line)
    }

    private fun execBlock(list: List<Stmt>, scope: Scope) {
        for (s in list) exec(s, scope)
    }

    private fun exec(s: Stmt, scope: Scope) {
        tick(s.line)
        when (s) {
            is Let -> scope.set(s.name, eval(s.e, scope))
            is Say -> host.say(str(eval(s.e, scope)))
            is Run -> {
                val r = host.command(str(eval(s.e, scope)))
                if (r.isNotBlank()) host.say(r)
            }
            is Wait -> {
                val sec = num(eval(s.e, scope), s.line)
                var left = (sec * 1000).toLong().coerceIn(0, 60_000)
                while (left > 0) {
                    if (host.cancelled()) throw StopSignal()
                    val step = minOf(left, 200L)
                    host.sleep(step)
                    left -= step
                }
            }
            is If -> if (truthy(eval(s.c, scope))) execBlock(s.a, Scope(scope)) else execBlock(s.b, Scope(scope))
            is While -> while (truthy(eval(s.c, scope))) { tick(s.line); execBlock(s.body, Scope(scope)) }
            is Repeat -> {
                val n = num(eval(s.n, scope), s.line).toInt().coerceIn(0, 10_000)
                repeat(n) { tick(s.line); execBlock(s.body, Scope(scope)) }
            }
            is Func -> funcs[s.name.lowercase()] = s
            is Ret -> throw ReturnSignal(s.e?.let { eval(it, scope) })
            is Halt -> throw StopSignal()
            is ExprStmt -> eval(s.e, scope)
        }
    }

    private var depth = 0

    private fun eval(e: Expr, scope: Scope): Any? = when (e) {
        is Lit -> e.v
        is Var -> {
            val holder = scope.find(e.name)
            if (holder != null) holder.vars[e.name] else builtinVar(e.name, e.line)
        }
        is Un -> {
            val v = eval(e.a, scope)
            if (e.op == "не") !truthy(v) else -num(v, e.line)
        }
        is Bin -> binary(e, scope)
        is Call -> call(e, scope)
    }

    private fun builtinVar(name: String, line: Int): Any? = when (name.lowercase()) {
        "громкость" -> (Prefs.soundVolume * 100).toInt().toDouble()
        "время" -> java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
        "час" -> java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY).toDouble()
        "минута" -> java.util.Calendar.getInstance().get(java.util.Calendar.MINUTE).toDouble()
        else -> throw ScriptError("переменная «$name» не задана", line)
    }

    private fun binary(e: Bin, scope: Scope): Any? {
        if (e.op == "и") return truthy(eval(e.a, scope)) && truthy(eval(e.b, scope))
        if (e.op == "или") return truthy(eval(e.a, scope)) || truthy(eval(e.b, scope))
        val a = eval(e.a, scope)
        val b = eval(e.b, scope)
        return when (e.op) {
            "+" -> if (a is Double && b is Double) a + b else str(a) + str(b)
            "-" -> num(a, e.line) - num(b, e.line)
            "*" -> num(a, e.line) * num(b, e.line)
            "/" -> {
                val d = num(b, e.line)
                if (d == 0.0) throw ScriptError("деление на ноль", e.line)
                num(a, e.line) / d
            }
            "%" -> {
                val d = num(b, e.line)
                if (d == 0.0) throw ScriptError("деление на ноль", e.line)
                num(a, e.line) % d
            }
            "==" -> same(a, b)
            "!=" -> !same(a, b)
            "<" -> num(a, e.line) < num(b, e.line)
            ">" -> num(a, e.line) > num(b, e.line)
            "<=" -> num(a, e.line) <= num(b, e.line)
            ">=" -> num(a, e.line) >= num(b, e.line)
            else -> throw ScriptError("неизвестный оператор ${e.op}", e.line)
        }
    }

    private fun call(e: Call, scope: Scope): Any? {
        val args = e.args.map { eval(it, scope) }
        val user = funcs[e.name.lowercase()]
        if (user != null) {
            if (args.size != user.params.size) {
                throw ScriptError("«${user.name}» ждёт аргументов: ${user.params.size}", e.line)
            }
            if (++depth > MAX_DEPTH) { depth = 0; throw ScriptError("слишком глубокая рекурсия", e.line) }
            val local = Scope(null)
            user.params.forEachIndexed { i, n -> local.vars[n] = args[i] }
            try {
                execBlock(user.body, local)
                return null
            } catch (r: ReturnSignal) {
                return r.value
            } finally {
                if (depth > 0) depth--
            }
        }
        return when (e.name.lowercase()) {
            "длина" -> str(args.getOrNull(0)).length.toDouble()
            "число" -> str(args.getOrNull(0)).replace(',', '.').toDoubleOrNull()
                ?: throw ScriptError("«${str(args.getOrNull(0))}» — не число", e.line)
            "текст" -> str(args.getOrNull(0))
            "округлить" -> Math.round(num(args.getOrNull(0), e.line)).toDouble()
            "случайное" -> {
                val lo = num(args.getOrNull(0), e.line).toInt()
                val hi = num(args.getOrNull(1), e.line).toInt()
                if (hi < lo) throw ScriptError("случайное(от, до): до меньше от", e.line)
                (lo + kotlin.random.Random.nextInt(hi - lo + 1)).toDouble()
            }
            "верхний" -> str(args.getOrNull(0)).uppercase()
            "нижний" -> str(args.getOrNull(0)).lowercase()
            "содержит" -> str(args.getOrNull(0)).lowercase().contains(str(args.getOrNull(1)).lowercase())
            else -> throw ScriptError("функция «${e.name}» неизвестна", e.line)
        }
    }

    private fun truthy(v: Any?): Boolean = when (v) {
        null -> false
        is Boolean -> v
        is Double -> v != 0.0
        is String -> v.isNotEmpty()
        else -> true
    }

    private fun same(a: Any?, b: Any?): Boolean =
        if (a is Double && b is Double) a == b else str(a) == str(b)

    private fun num(v: Any?, line: Int): Double = when (v) {
        is Double -> v
        is Boolean -> if (v) 1.0 else 0.0
        is String -> v.replace(',', '.').toDoubleOrNull() ?: throw ScriptError("«$v» — не число", line)
        else -> throw ScriptError("ожидалось число", line)
    }

    private fun str(v: Any?): String = when (v) {
        null -> ""
        is Boolean -> if (v) "да" else "нет"
        is Double -> if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString() else v.toString()
        else -> v.toString()
    }

    companion object {
        private const val MAX_STEPS = 200_000
        private const val MAX_DEPTH = 200

        const val EXAMPLE = "# Пример на JarvisScript\n" +
            "пусть имя = \"Тони\"\n" +
            "сказать \"Привет, \" + имя\n" +
            "\n" +
            "функция квадрат(x) {\n" +
            "    вернуть x * x\n" +
            "}\n" +
            "\n" +
            "повторить 3 раз {\n" +
            "    сказать \"Квадрат 4 = \" + квадрат(4)\n" +
            "}\n" +
            "\n" +
            "если час < 12 {\n" +
            "    сказать \"Доброе утро\"\n" +
            "} иначе {\n" +
            "    сказать \"Добрый день\"\n" +
            "}\n"
    }
}

/** Запуск сценариев: из редактора и голосом («запусти сценарий»). Одновременно идёт только один. */
object ScriptRunner {
    @Volatile
    var running = false
        private set

    @Volatile
    private var cancel = false

    fun stop() {
        cancel = true
    }

    /** Выполняет текст сценария в текущем потоке (вызывать НЕ из главного). Возвращает ошибку или null. */
    fun runSource(ctx: Context, src: String, onSay: (String) -> Unit): String? {
        synchronized(this) {
            if (running) return "сценарий уже выполняется"
            running = true
            cancel = false
        }
        try {
            val host = object : JarvisScript.Host {
                override fun say(text: String) = onSay(text)
                override fun command(text: String): String =
                    try {
                        Commands.run(ctx.applicationContext, text, useAi = false).text
                    } catch (e: Throwable) {
                        "Ошибка: ${e.message}"
                    }
                override fun sleep(ms: Long) = Thread.sleep(ms)
                override fun cancelled(): Boolean = cancel
            }
            val err = JarvisScript(host).run(src)
            if (err != null) AppLog.cmd("ERR", "Сценарий: $err")
            return err
        } finally {
            running = false
        }
    }

    /** Сохранённый сценарий, как команда «запусти сценарий». */
    fun runSaved(ctx: Context): Reply {
        val src = Prefs.scriptText
        if (src.isBlank()) return Reply(false, "Сценарий пуст: напишите его в Настройки → Звук и распознавание")
        val said = ArrayList<String>()
        val err = runSource(ctx, src) { said.add(it) }
        return when {
            err != null -> Reply(false, "Сценарий: $err")
            said.isNotEmpty() -> Reply(true, said.last())
            else -> Reply(true, "Сценарий выполнен")
        }
    }
}
