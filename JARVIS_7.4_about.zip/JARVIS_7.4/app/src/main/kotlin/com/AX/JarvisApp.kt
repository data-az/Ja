// Copyright © 2026 AX. Все права защищены / All rights reserved.
// Копирование, распространение и извлечение кода без разрешения правообладателя запрещены.
package com.AX

import android.app.Application

/**
 * Инициализация защиты до всех компонентов: голос может стартовать из сервиса или BootReceiver,
 * когда MainActivity ещё не создана.
 */
class JarvisApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NativeSecurity.init(this)
    }
}
