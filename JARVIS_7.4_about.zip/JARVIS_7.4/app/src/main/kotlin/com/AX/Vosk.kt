// Copyright © 2026 AX. Все права защищены / All rights reserved.
// Копирование, распространение и извлечение кода без разрешения правообладателя запрещены.
package com.AX

import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream

/**
 * Файлы офлайн-модели Vosk: поиск архива на телефоне, распаковка и скачивание с Яндекс Диска.
 * Модель лежит в filesDir/vosk/<папка модели>/{am, graph, conf, ivector}.
 */
object VoskModel {
    /** Имя архива модели, на Яндекс Диске и на телефоне. */
    const val ZIP_NAME = "vosk-model-small-ru-0.22.zip"

    /** Публичная ссылка на Яндекс Диске. */
    private const val PUBLIC_LINK = "https://disk.yandex.ru/d/n_5tW7W052qa_Q"
    private const val API = "https://cloud-api.yandex.net/v1/disk/public/resources"

    /** Папка с распакованной моделью: внутри должны быть am и graph. Если нет — null. */
    fun installedDir(ctx: Context): File? {
        val root = File(ctx.filesDir, "vosk")
        if (!root.isDirectory) return null
        return root.walkTopDown().maxDepth(2)
            .firstOrNull { File(it, "am").isDirectory && File(it, "graph").isDirectory }
    }

    /** Распаковывает архив в filesDir/vosk. true — если модель теперь на месте. */
    fun unpack(ctx: Context, zip: File): Boolean {
        val target = File(ctx.filesDir, "vosk").apply { mkdirs() }
        val base = target.canonicalPath + File.separator
        return try {
            ZipInputStream(zip.inputStream().buffered()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val out = File(target, entry.name)
                    // Защита от архивов с путями вида ../
                    if (!out.canonicalPath.startsWith(base)) throw IOException("Плохой путь в архиве")
                    if (entry.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { zis.copyTo(it) }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            installedDir(ctx) != null
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Скачивает архив с публичной ссылки Яндекс Диска. Работает без VPN.
     * Ссылка может вести на папку или на файл: проверяем оба случая.
     * [progress] вызывается из фонового потока.
     */
    fun download(ctx: Context, progress: (String) -> Unit): File {
        val key = URLEncoder.encode(PUBLIC_LINK, "UTF-8")
        val listing = getJson("$API?public_key=$key&limit=200")
        val pathPart = if (listing.has("_embedded")) {
            val items = listing.getJSONObject("_embedded").getJSONArray("items")
            val found = (0 until items.length()).any { items.getJSONObject(it).optString("name") == ZIP_NAME }
            if (!found) throw IOException("В папке на Диске нет файла $ZIP_NAME")
            "&path=" + URLEncoder.encode("/$ZIP_NAME", "UTF-8")
        } else {
            ""
        }
        val href = getJson("$API/download?public_key=$key$pathPart").optString("href")
        if (href.isEmpty()) throw IOException("Яндекс Диск не отдал ссылку на скачивание")

        val dir = File(ctx.filesDir, "vosk").apply { mkdirs() }
        val out = File(dir, ZIP_NAME)
        val c = (URL(href).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
            instanceFollowRedirects = true
        }
        try {
            val total = c.contentLengthLong
            c.inputStream.use { input ->
                out.outputStream().use { output ->
                    val buf = ByteArray(64 * 1024)
                    var done = 0L
                    var last = -5
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct - last >= 5) {
                                last = pct
                                progress("Скачиваю… $pct%")
                            }
                        }
                    }
                }
            }
        } finally {
            c.disconnect()
        }
        return out
    }

    private fun getJson(url: String): JSONObject {
        val c = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 30_000
        }
        try {
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)
                ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IOException("Яндекс Диск ответил кодом $code")
            return JSONObject(body)
        } finally {
            c.disconnect()
        }
    }
}

/**
 * Распознавание через Vosk: модель грузится в память один раз, слушает без интернета.
 * Все вызовы делаются с главного потока; колбэки приходят на главном потоке.
 */
object VoskEngine {
    private const val RATE = 16000f
    private val main = Handler(Looper.getMainLooper())

    @Volatile private var model: Model? = null
    @Volatile private var generation = 0
    private var service: SpeechService? = null

    /** Модель загружена в память. */
    val ready: Boolean get() = model != null

    /** Сейчас идёт прослушивание. */
    val running: Boolean get() = service != null

    /** Загружает модель с диска в фоновом потоке. */
    fun load(ctx: Context, onDone: (Boolean, String) -> Unit) {
        if (model != null) {
            main.post { onDone(true, "Модель уже в памяти") }
            return
        }
        val dir = VoskModel.installedDir(ctx)
        if (dir == null) {
            main.post { onDone(false, "Модели нет на телефоне") }
            return
        }
        Thread {
            try {
                model = Model(dir.absolutePath)
                main.post { onDone(true, "Офлайн-модель загружена") }
            } catch (e: Exception) {
                main.post { onDone(false, "Не удалось загрузить модель: ${e.message}") }
            }
        }.start()
    }

    /**
     * Начинает слушать. [oneShot] = true: отдаёт одну фразу и останавливается.
     * Иначе слушает непрерывно и отдаёт каждую фразу в [onText].
     */
    fun start(
        oneShot: Boolean,
        onText: (String) -> Unit,
        onPartial: ((String) -> Unit)? = null,
        onFail: ((String) -> Unit)? = null,
    ): Boolean {
        val m = model ?: return false
        shutdownNow()
        val gen = generation + 1
        generation = gen
        val single = oneShot
        val svc = SpeechService(Recognizer(m, RATE), RATE)
        service = svc
        val delivered = AtomicBoolean(false)

        fun finishOnce(text: String) {
            if (!delivered.compareAndSet(false, true)) return
            main.post {
                if (gen != generation) return@post
                shutdownNow()
                onText(text)
            }
        }

        svc.startListening(object : org.vosk.android.RecognitionListener {
            override fun onPartialResult(hypothesis: String?) {
                val p = field(hypothesis, "partial")
                if (p.isNotEmpty()) main.post { if (gen == generation) onPartial?.invoke(p) }
            }

            override fun onResult(hypothesis: String?) {
                val t = field(hypothesis, "text")
                if (t.isEmpty()) return
                if (single) {
                    finishOnce(t)
                } else {
                    main.post { if (gen == generation) onText(t) }
                }
            }

            override fun onFinalResult(hypothesis: String?) {
                if (single) finishOnce(field(hypothesis, "text"))
            }

            override fun onError(exception: Exception?) {
                val msg = "Ошибка Vosk: ${exception?.message ?: "неизвестная"}"
                main.post {
                    if (gen != generation) return@post
                    shutdownNow()
                    if (onFail != null) onFail.invoke(msg) else AppLog.add("ERR", msg)
                }
            }

            override fun onTimeout() {
                if (single) finishOnce("")
            }
        })
        return true
    }

    /** Остановить и отпустить микрофон. Текст не отдаётся. */
    fun stop() {
        generation = generation + 1
        shutdownNow()
    }

    /** Закончить текущую фразу: Vosk отдаст то, что успел распознать. */
    fun finish() {
        service?.stop()
    }

    private fun shutdownNow() {
        service?.shutdown()
        service = null
    }

    private fun field(json: String?, key: String): String =
        try {
            JSONObject(json.orEmpty()).optString(key).trim()
        } catch (e: Exception) {
            ""
        }
}
