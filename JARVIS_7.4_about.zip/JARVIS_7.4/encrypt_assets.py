#!/usr/bin/env python3
"""Шифрует голосовые фразы (папка core_data) и index.json перед сборкой APK.

Запускается в CI до ./gradlew assembleRelease. Ключ берётся из BASE_KEY в
app/src/main/cpp/native-lib.cpp, чтобы ключ хранился только в одном месте.
Оригиналы (.mp3 и index.json) удаляются из рабочей копии: в APK попадают только .jdat.
Повторный запуск безопасен: уже зашифрованное пропускается.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CORE_DATA = ROOT / "app/src/main/assets/core_data"
FILES = CORE_DATA / "files"
INDEX = CORE_DATA / "index.json"
NATIVE = ROOT / "app/src/main/cpp/native-lib.cpp"


def load_base_key() -> bytes:
    text = NATIVE.read_text(encoding="utf-8")
    m = re.search(r"BASE_KEY\[32\]\s*=\s*\{([^}]*)\}", text)
    if not m:
        sys.exit("BASE_KEY не найден в native-lib.cpp")
    values = [int(v, 16) for v in re.findall(r"0x[0-9a-fA-F]{2}", m.group(1))]
    if len(values) != 32:
        sys.exit(f"BASE_KEY должен быть из 32 байт, найдено {len(values)}")
    return bytes(values)


def xor_stream(data: bytes, key: bytes) -> bytes:
    """Тот же алгоритм, что xor_stream() в native-lib.cpp: зависит от позиции байта."""
    out = bytearray(len(data))
    klen = len(key)
    for i, b in enumerate(data):
        out[i] = b ^ (key[i % klen] ^ ((i * 31) & 0xFF))
    return bytes(out)


def encrypt_file(src: Path, dst: Path, key: bytes) -> None:
    raw = src.read_bytes()
    enc = xor_stream(raw, key)
    # Проверка обратимости до удаления оригинала
    if xor_stream(enc, key) != raw:
        sys.exit(f"Ошибка проверки шифрования: {src.name}")
    dst.write_bytes(enc)
    src.unlink()


def main() -> None:
    key = load_base_key()
    done = 0

    if INDEX.exists():
        encrypt_file(INDEX, CORE_DATA / "index.jdat", key)
        done += 1
    elif (CORE_DATA / "index.jdat").exists():
        print("index.json уже зашифрован, пропуск")

    if FILES.is_dir():
        for src in sorted(FILES.iterdir()):
            if not src.is_file() or src.suffix == ".jdat":
                continue
            dst = src.with_suffix(".jdat")
            if dst.exists():
                sys.exit(f"Конфликт: {dst.name} уже есть, а {src.name} не удалён. Проверьте папку.")
            encrypt_file(src, dst, key)
            done += 1

    print(f"Зашифровано файлов: {done}")


if __name__ == "__main__":
    main()
